extends Node
## Autoload "GameState": selections that survive scene changes.

var car_id := ""        # "" = built-in car, otherwise a saved custom car id
var biome := 0
var speed_kmh := 0.0     # telemetry for the phone page / HUD
var gear_text := ""


func goto(path: String) -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file(path)
