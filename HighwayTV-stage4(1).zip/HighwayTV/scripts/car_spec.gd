class_name CarSpec
extends RefCounted
## Saved car configuration (plain Dictionary so it round-trips through JSON).
## Stored at user://cars/<id>/spec.json next to the staged model files.

const ROOT := "user://cars"


static func defaults() -> Dictionary:
	return {
		"name": "Custom Car", "mass": 1350.0, "radius": 0.34, "wheelbase": 2.7, "track": 1.6,
		"susp_rest": 0.25, "susp_stiffness": 28.0, "damp_comp": 0.45, "damp_rel": 0.65,
		"max_steer": 30.0, "peak_torque": 340.0, "redline": 6800.0, "brake_per_kg": 0.03,
		"automatic": true, "gears": 6.0, "final_drive": 3.9,
		"grip_front": 1.3, "grip_rear": 1.2, "drag_cd_a": 0.7,
	}


## Geometric gear ratios from 3.5 (1st) down to 0.65 (top).
static func ratios(n: int) -> Array[float]:
	var out: Array[float] = []
	n = clampi(n, 3, 8)
	for i in n:
		out.append(3.5 * pow(0.65 / 3.5, float(i) / float(n - 1)))
	return out


static func v3(a: Variant) -> Vector3:
	if a is Vector3:
		return a
	if a is Array and a.size() >= 3:
		return Vector3(float(a[0]), float(a[1]), float(a[2]))
	return Vector3.ZERO


static func a3(v: Vector3) -> Array:
	return [v.x, v.y, v.z]


static func save(spec: Dictionary) -> bool:
	var dir := "%s/%s" % [ROOT, spec["id"]]
	DirAccess.make_dir_recursive_absolute(dir)
	var f := FileAccess.open(dir + "/spec.json", FileAccess.WRITE)
	if f == null:
		return false
	f.store_string(JSON.stringify(spec, "\t"))
	return true


static func load_spec(id: String) -> Dictionary:
	var p := "%s/%s/spec.json" % [ROOT, id]
	if not FileAccess.file_exists(p):
		return {}
	var data: Variant = JSON.parse_string(FileAccess.get_file_as_string(p))
	if data is Dictionary:
		return data
	return {}


static func list_ids() -> Array[String]:
	var out: Array[String] = []
	for d in DirAccess.get_directories_at(ROOT):
		if FileAccess.file_exists("%s/%s/spec.json" % [ROOT, d]):
			out.append(d)
	out.sort()
	return out


static func remove_dir(path: String) -> void:
	for f in DirAccess.get_files_at(path):
		DirAccess.remove_absolute(path + "/" + f)
	DirAccess.remove_absolute(path)


static func delete(id: String) -> void:
	remove_dir("%s/%s" % [ROOT, id])
