extends Node
## Central input hub (autoload "GameInput").
## Merges TV remote (D-pad), keyboard, gamepad and - from Stage 4 - the phone
## controller into one set of normalised values the car reads:
##   steer -1..1, throttle 0..1, brake 0..1, handbrake 0..1

signal back_pressed
signal accept_pressed
signal pause_pressed
signal camera_pressed
signal gear_up_pressed
signal gear_down_pressed
signal gearbox_toggle_pressed
signal reset_pressed
signal horn_changed(on: bool)

var steer := 0.0
var throttle := 0.0
var brake := 0.0
var handbrake := 0.0

# --- Phone controller hook (Stage 4 calls these) ---
var remote_active := false
var _r_steer := 0.0
var _r_throttle := 0.0
var _r_brake := 0.0
var _r_handbrake := 0.0

const STEER_RATE := 2.6     # how fast digital steering ramps to full lock
const STEER_RETURN := 4.0   # how fast it self-centres


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS   # keep working while paused
	get_tree().set_auto_accept_quit(false)
	_register_actions()


func set_remote(s: float, t: float, b: float, h: float) -> void:
	remote_active = true
	_r_steer = clampf(s, -1.0, 1.0)
	_r_throttle = clampf(t, 0.0, 1.0)
	_r_brake = clampf(b, 0.0, 1.0)
	_r_handbrake = clampf(h, 0.0, 1.0)


## Called when the phone disconnects: controls neutralise immediately.
func clear_remote() -> void:
	remote_active = false
	_r_steer = 0.0
	_r_throttle = 0.0
	_r_brake = 0.0
	_r_handbrake = 0.0
	steer = 0.0
	throttle = 0.0
	brake = 0.0
	handbrake = 0.0


func _process(delta: float) -> void:
	if remote_active:
		steer = _r_steer
		throttle = _r_throttle
		brake = _r_brake
		handbrake = _r_handbrake
		return
	var st := Input.get_axis("steer_left", "steer_right")
	if absf(st) > 0.01:
		steer = move_toward(steer, st, STEER_RATE * delta)
	else:
		steer = move_toward(steer, 0.0, STEER_RETURN * delta)
	throttle = _approach(throttle, Input.get_action_strength("throttle"), 4.0, 9.0, delta)
	brake = _approach(brake, Input.get_action_strength("brake"), 6.0, 12.0, delta)
	handbrake = _approach(handbrake, Input.get_action_strength("handbrake"), 12.0, 12.0, delta)


func _approach(cur: float, target: float, up: float, down: float, delta: float) -> float:
	return move_toward(cur, target, (up if target > cur else down) * delta)


func _input(event: InputEvent) -> void:
	if event.is_action_pressed("back"): back_pressed.emit()
	if event.is_action_pressed("accept"): accept_pressed.emit()
	if event.is_action_pressed("pause"): pause_pressed.emit()
	if event.is_action_pressed("camera"): camera_pressed.emit()
	if event.is_action_pressed("gear_up"): gear_up_pressed.emit()
	if event.is_action_pressed("gear_down"): gear_down_pressed.emit()
	if event.is_action_pressed("toggle_gearbox"): gearbox_toggle_pressed.emit()
	if event.is_action_pressed("reset"): reset_pressed.emit()
	if event.is_action_pressed("horn"): horn_changed.emit(true)
	elif event.is_action_released("horn"): horn_changed.emit(false)
	# Gamepad A doubles as throttle while driving and as OK in the pause menu.
	if event is InputEventJoypadButton and event.pressed \
			and event.button_index == JOY_BUTTON_A and get_tree().paused:
		accept_pressed.emit()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:   # Android TV remote BACK
		back_pressed.emit()
	elif what == NOTIFICATION_WM_CLOSE_REQUEST:
		get_tree().quit()


# ---------------------------------------------------------------- input map
func _register_actions() -> void:
	_key("steer_left", [KEY_LEFT, KEY_A])
	_key("steer_right", [KEY_RIGHT, KEY_D])
	_key("throttle", [KEY_UP, KEY_W])
	_key("brake", [KEY_DOWN, KEY_S])
	_key("handbrake", [KEY_SPACE])
	_key("camera", [KEY_C])
	_key("gear_up", [KEY_E])
	_key("gear_down", [KEY_Q])
	_key("toggle_gearbox", [KEY_T])
	_key("reset", [KEY_R])
	_key("pause", [KEY_P])
	_key("back", [KEY_ESCAPE, KEY_BACKSPACE])
	_key("accept", [KEY_ENTER, KEY_KP_ENTER])   # TV remote OK / D-pad centre
	_key("horn", [KEY_H])

	_axis("steer_left", JOY_AXIS_LEFT_X, -1.0)
	_axis("steer_right", JOY_AXIS_LEFT_X, 1.0)
	_btn("steer_left", JOY_BUTTON_DPAD_LEFT)
	_btn("steer_right", JOY_BUTTON_DPAD_RIGHT)
	_axis("throttle", JOY_AXIS_TRIGGER_RIGHT, 1.0)
	_btn("throttle", JOY_BUTTON_A)
	_axis("brake", JOY_AXIS_TRIGGER_LEFT, 1.0)
	_btn("brake", JOY_BUTTON_B)
	_btn("handbrake", JOY_BUTTON_X)
	_btn("camera", JOY_BUTTON_Y)
	_btn("gear_up", JOY_BUTTON_RIGHT_SHOULDER)
	_btn("gear_down", JOY_BUTTON_LEFT_SHOULDER)
	_btn("toggle_gearbox", JOY_BUTTON_RIGHT_STICK)
	_btn("reset", JOY_BUTTON_BACK)
	_btn("pause", JOY_BUTTON_START)


func _ensure(action: String) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action, 0.2)

func _key(action: String, keys: Array) -> void:
	_ensure(action)
	for k in keys:
		var e := InputEventKey.new()
		e.keycode = k
		InputMap.action_add_event(action, e)

func _btn(action: String, button: int) -> void:
	_ensure(action)
	var e := InputEventJoypadButton.new()
	e.button_index = button
	InputMap.action_add_event(action, e)

func _axis(action: String, axis: int, value: float) -> void:
	_ensure(action)
	var e := InputEventJoypadMotion.new()
	e.axis = axis
	e.axis_value = value
	InputMap.action_add_event(action, e)
