class_name ObjLoader
extends RefCounted
## Minimal Wavefront OBJ/MTL loader (runtime). Each o/g/usemtl block becomes its
## own MeshInstance3D named after the group, so wheel meshes can be detected.
## Supports v/vt/vn/f (n-gons fan-triangulated), negative indices, Kd, map_Kd.


static func load_obj(path: String) -> Node3D:
	var text := FileAccess.get_file_as_string(path)
	if text.is_empty():
		return null
	var base := path.get_base_dir()
	var V := PackedVector3Array()
	var N := PackedVector3Array()
	var T := PackedVector2Array()
	var mats: Dictionary = {}
	var groups: Array = []
	var gname := "mesh"
	var gmat := ""
	var cur := _new_group(gname, gmat)
	for raw in text.split("\n"):
		var line := raw.strip_edges()
		if line.is_empty() or line.begins_with("#"):
			continue
		var p := line.split(" ", false)
		if p.size() < 2:
			continue
		match p[0]:
			"v":
				if p.size() >= 4:
					V.append(Vector3(float(p[1]), float(p[2]), float(p[3])))
			"vn":
				if p.size() >= 4:
					N.append(Vector3(float(p[1]), float(p[2]), float(p[3])))
			"vt":
				T.append(Vector2(float(p[1]), 1.0 - float(p[2])))
			"o", "g":
				_finish(groups, cur)
				gname = p[1]
				cur = _new_group(gname, gmat)
			"usemtl":
				_finish(groups, cur)
				gmat = p[1]
				cur = _new_group(gname, gmat)
			"mtllib":
				_parse_mtl(base.path_join(line.substr(7).strip_edges()), mats, base)
			"f":
				_face(p, V, N, T, cur)
	_finish(groups, cur)
	if groups.is_empty():
		return null
	var root := Node3D.new()
	root.name = "ObjRoot"
	for g in groups:
		var arr := []
		arr.resize(Mesh.ARRAY_MAX)
		arr[Mesh.ARRAY_VERTEX] = g["v"]
		arr[Mesh.ARRAY_NORMAL] = g["n"]
		if (g["uv"] as PackedVector2Array).size() == (g["v"] as PackedVector3Array).size():
			arr[Mesh.ARRAY_TEX_UV] = g["uv"]
		var am := ArrayMesh.new()
		am.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
		var mi := MeshInstance3D.new()
		mi.name = str(g["name"]).replace("/", "_").replace(":", "_")
		mi.mesh = am
		var mat: StandardMaterial3D = mats.get(g["mat"], null)
		if mat == null:
			mat = StandardMaterial3D.new()
			mat.albedo_color = Color(0.6, 0.6, 0.62)
			mat.roughness = 0.6
		mi.material_override = mat
		root.add_child(mi)
	return root


static func _new_group(n: String, m: String) -> Dictionary:
	return {"name": n, "mat": m, "v": PackedVector3Array(), "n": PackedVector3Array(), "uv": PackedVector2Array()}


static func _finish(groups: Array, g: Dictionary) -> void:
	if (g["v"] as PackedVector3Array).size() >= 3:
		groups.append(g)


static func _idx(s: String, count: int) -> int:
	if s.is_empty():
		return -1
	var i := int(s)
	return count + i if i < 0 else i - 1


static func _face(p: PackedStringArray, V: PackedVector3Array, N: PackedVector3Array,
		T: PackedVector2Array, g: Dictionary) -> void:
	var corners: Array = []
	for k in range(1, p.size()):
		var t := p[k].split("/")
		var vi := _idx(t[0], V.size())
		if vi < 0 or vi >= V.size():
			return
		var ti := _idx(t[1], T.size()) if t.size() > 1 else -1
		var ni := _idx(t[2], N.size()) if t.size() > 2 else -1
		corners.append([vi, ti, ni])
	for k in range(1, corners.size() - 1):
		# OBJ is counter-clockwise, Godot front faces are clockwise -> emit (a, c, b)
		var tri := [corners[0], corners[k + 1], corners[k]]
		var a: Vector3 = V[tri[0][0]]
		var b: Vector3 = V[tri[1][0]]
		var c: Vector3 = V[tri[2][0]]
		var fn := (c - a).cross(b - a)   # note: matches the swapped winding
		fn = fn.normalized() if fn.length() > 0.000001 else Vector3.UP
		for cc in tri:
			(g["v"] as PackedVector3Array).append(V[cc[0]])
			(g["n"] as PackedVector3Array).append(N[cc[2]] if cc[2] >= 0 and cc[2] < N.size() else -fn)
			(g["uv"] as PackedVector2Array).append(T[cc[1]] if cc[1] >= 0 and cc[1] < T.size() else Vector2.ZERO)


static func _parse_mtl(path: String, mats: Dictionary, base: String) -> void:
	if not FileAccess.file_exists(path):
		return
	var cur: StandardMaterial3D = null
	for raw in FileAccess.get_file_as_string(path).split("\n"):
		var line := raw.strip_edges()
		var p := line.split(" ", false)
		if p.size() < 2:
			continue
		if p[0] == "newmtl":
			cur = StandardMaterial3D.new()
			cur.roughness = 0.6
			mats[p[1]] = cur
		elif cur != null and p[0] == "Kd" and p.size() >= 4:
			cur.albedo_color = Color(float(p[1]), float(p[2]), float(p[3]))
		elif cur != null and p[0] == "map_Kd":
			var tex_path := base.path_join(line.substr(6).strip_edges().get_file())
			if FileAccess.file_exists(tex_path):
				var img := Image.load_from_file(tex_path)
				if img != null:
					img.generate_mipmaps()
					cur.albedo_texture = ImageTexture.create_from_image(img)
					cur.albedo_color = Color.WHITE
