extends Control
## PHONE CONTROLLER screen: server status, TV address, port, pairing code, QR code,
## connection status and connected phone name.

var _info: Label
var _qr: TextureRect
var _hint: Label
var _btn_toggle: Button
var _shown_url := ""
var _t := 0.0


func _ready() -> void:
	var bg := ColorRect.new()
	bg.color = Color(0.04, 0.05, 0.07)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var title := Label.new()
	title.text = "PHONE CONTROLLER"
	title.add_theme_font_size_override("font_size", 56)
	title.position = Vector2(100, 60)
	add_child(title)

	_info = Label.new()
	_info.position = Vector2(100, 170)
	_info.add_theme_font_size_override("font_size", 34)
	add_child(_info)

	_hint = Label.new()
	_hint.position = Vector2(100, 640)
	_hint.size = Vector2(900, 300)
	_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_hint.add_theme_font_size_override("font_size", 26)
	_hint.modulate = Color(1, 1, 1, 0.75)
	_hint.text = "1. Connect your phone to the same Wi-Fi as this TV.\n2. Scan the QR code with the phone camera and open the link.\n"\
		+ "3. Steer with the on-screen wheel (or tilt), use the pedals and buttons.\n(No app needed. Phone settings has car upload and tilt steering.)"
	add_child(_hint)

	_qr = TextureRect.new()
	_qr.position = Vector2(1140, 120)
	_qr.custom_minimum_size = Vector2(620, 620)
	_qr.size = Vector2(620, 620)
	_qr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_qr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	_qr.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	add_child(_qr)

	var box := VBoxContainer.new()
	box.position = Vector2(100, 880)
	box.add_theme_constant_override("separation", 10)
	add_child(box)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 20)
	box.add_child(row)
	var b1 := _button("NEW PAIRING CODE", _new_code)
	_btn_toggle = _button("", _toggle)
	var b3 := _button("BACK", _back)
	row.add_child(b1)
	row.add_child(_btn_toggle)
	row.add_child(b3)
	b1.grab_focus()
	PhoneServer.changed.connect(_update)
	GameInput.back_pressed.connect(_back)
	_update()


func _exit_tree() -> void:
	if PhoneServer.changed.is_connected(_update):
		PhoneServer.changed.disconnect(_update)
	if GameInput.back_pressed.is_connected(_back):
		GameInput.back_pressed.disconnect(_back)


func _button(text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(380, 80)
	b.add_theme_font_size_override("font_size", 30)
	b.pressed.connect(cb)
	return b


func _process(delta: float) -> void:
	_t += delta
	if _t > 0.5:
		_t = 0.0
		_update()


func _update() -> void:
	var s := PhoneServer
	var running := s.status != PhoneServer.Status.STOPPED
	var conn := "NOT CONNECTED"
	if s.status == PhoneServer.Status.CONNECTED:
		conn = "CONNECTED  -  " + s.phone_name
	elif running:
		conn = "WAITING FOR PHONE"
	_info.text = "SERVER:        %s\nTV ADDRESS:   %s\nPORT:             %s\nPAIRING CODE:  %s\nCONNECTION:  %s\n\n%s" % [
		"RUNNING" if running else "STOPPED", s.ip if running else "-",
		str(s.http_port) if running else "-", s.token if running else "-", conn, s.last_message]
	_btn_toggle.text = "STOP SERVER" if running else "START SERVER"
	if running and s.ip != "unknown":
		if s.url() != _shown_url:
			_shown_url = s.url()
			var img := QrCode.make_image(_shown_url, 10, 3)
			_qr.texture = ImageTexture.create_from_image(img) if img != null else null
	else:
		_shown_url = ""
		_qr.texture = null
		if running:
			_info.text += "\nNo Wi-Fi/LAN address found. Connect the TV to your network."


func _new_code() -> void:
	PhoneServer.new_pairing_code()


func _toggle() -> void:
	if PhoneServer.status == PhoneServer.Status.STOPPED:
		PhoneServer.start()
	else:
		PhoneServer.stop()


func _back() -> void:
	GameState.goto("res://scenes/menu.tscn")
