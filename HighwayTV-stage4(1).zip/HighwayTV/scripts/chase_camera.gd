class_name ChaseCamera
extends Camera3D
## Chase / close-rear / hood cameras with speed-dependent FOV, shake and
## wall collision avoidance.

enum Mode { CHASE, CLOSE, HOOD }
const MODE_NAMES := ["CHASE", "CLOSE REAR", "HOOD"]

var target: HighwayCar
var mode: int = Mode.CHASE
var distance_scale := 1.0     # adjustable camera distance
var _yaw := 0.0
var _snap := true
var _y := 0.0


func _ready() -> void:
	near = 0.1
	far = 1500.0


func next_mode() -> void:
	mode = (mode + 1) % 3
	_snap = true


func snap() -> void:
	_snap = true


func _physics_process(delta: float) -> void:
	if target == null:
		return
	var t := target.global_transform
	var f := -t.basis.z
	f.y = 0.0
	var heading := _yaw
	if f.length() > 0.01:
		f = f.normalized()
		heading = atan2(-f.x, -f.z)
	if _snap:
		_yaw = heading
	else:
		_yaw = lerp_angle(_yaw, heading, 1.0 - exp(-4.0 * delta))

	var speed := target.speed_kmh
	var k := clampf(speed / 200.0, 0.0, 1.0)
	var look_dir := Vector3(-sin(_yaw), 0.0, -cos(_yaw))

	if mode == Mode.HOOD:
		global_transform = t * Transform3D(Basis(), target.hood_cam_pos)
		fov = lerpf(72.0, 90.0, k)
		h_offset = 0.0
		v_offset = 0.0
		_snap = false
		return

	var dist := (7.5 if mode == Mode.CHASE else 4.6) * distance_scale
	var height := 2.5 if mode == Mode.CHASE else 1.6
	if _snap:
		_y = t.origin.y
	else:
		_y = lerpf(_y, t.origin.y, 1.0 - exp(-6.0 * delta))
	var focus := Vector3(t.origin.x, _y, t.origin.z) + Vector3.UP * 1.0 + look_dir * 3.0
	var desired := Vector3(t.origin.x, _y, t.origin.z) - look_dir * dist + Vector3.UP * height

	# Collision avoidance: pull camera in if geometry is between car and camera
	var space := get_world_3d().direct_space_state
	var q := PhysicsRayQueryParameters3D.create(t.origin + Vector3.UP * 1.0, desired)
	q.exclude = [target.get_rid()]
	var hit := space.intersect_ray(q)
	if not hit.is_empty():
		desired = hit.position + hit.normal * 0.3

	look_at_from_position(desired, focus, Vector3.UP)
	fov = lerpf(62.0, 88.0, k)
	var shake := 0.02 * k
	h_offset = randf_range(-shake, shake)
	v_offset = randf_range(-shake, shake)
	_snap = false
