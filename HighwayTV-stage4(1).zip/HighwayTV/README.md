# HIGHWAY TV — Stage 4

Godot 4.6 (GDScript, Compatibility renderer) driving simulator for Android TV 9+.

**Stage 2 adds:** an endless procedural highway with curves and hills, bridges (valley + deck + piers) and tunnels (mound + lit concrete tube),
7 environments (Indian highway, mountain, modern city, countryside, desert, forest, coastal), pooled segments with per-quality view distance,
and floating-origin rebase. **Stage 1:** one drivable car,
raycast-vehicle physics with engine/gearbox, ABS, traction control, aero, surface grip, 3 cameras, TV HUD,
pause menu, quality presets, and a GitHub Actions APK build.

## Build the APK on GitHub
1. Create a repo, push this folder (the workflow is in `.github/workflows/build-apk.yml`).
2. Open **Actions → Build Highway TV APK** (runs on push, or press *Run workflow*).
3. Download the `HighwayTV-apk` artifact → sideload `HighwayTV-debug.apk` (e.g. `adb install`).

The workflow installs Godot 4.3 + templates + Android SDK/NDK, installs the Gradle build template, patches the
manifest for Android TV (LEANBACK launcher + banner), and exports an arm64 debug APK (min SDK 28 = Android 9).

## Run locally
Open in Godot 4.6+, press F5.

## Controls
| Action | TV remote | Keyboard | Gamepad |
|---|---|---|---|
| Steer | D-pad L/R | ←/→ A/D | Left stick / D-pad |
| Accelerate | D-pad Up | ↑ W | RT / A |
| Brake / reverse | D-pad Down | ↓ S | LT / B |
| Handbrake | – | Space | X |
| Camera | OK | C | Y |
| Pause / quit | BACK (then BACK = quit, OK = resume) | P / Esc | Start |
| Gear up/down (manual) | – | E / Q | RB / LB |
| Auto/Manual | – | T | R-stick click |
| Reset car | – | R | Back |
| Quality preset | – | F1 | – |
| Environment | – | F2 | – |

## IMPORTANT — device compatibility
Godot 4 needs **OpenGL ES 3.0**. Some very low-end TVs (e.g. Mi TV 4A models with Mali-450 GPUs, GLES 2.0 only)
**cannot run Godot 4 at all**. If your target is such a TV, the engine choice must change (Godot 3.x GLES2).
Check with a GPU-info app before investing further.

## Tuning (not yet tested on a device!)
This code was written without a Godot runtime available, so physics feel is uncalibrated.
Start with `scripts/vehicle.gd` exports:
- `force_unit_scale` — Godot's `engine_force` units aren't plain Newtons. The HUD shows your 0–100 km/h time; aim ~7–9 s.
- `grip_front/grip_rear`, `susp_stiffness`, `damp_*`, `steer_speed_ref`, `brake_per_kg`.

## Roadmap
- Stage 2: curves/hills/bridges/tunnels, biomes · Stage 3: GLB importer (SAF file picker, wheel detection)
- Stage 4: Wi-Fi phone controller (hook already exists: `GameInput.set_remote()` / `clear_remote()`)
- Stage 5: traffic, weather, day/night · Stage 6: menus, perf screen, release signing

## Stage 2 notes / known limits
- Environment switching is F2 (keyboard) for now; the menu entry arrives in Stage 6. Switching keeps the road under the car and regenerates everything ahead.
- Tunnel interiors are lit by emissive strips only (no real lights yet); coastal has no water yet; roads have no banking.
- Road geometry/collision are built in GDScript per segment (trimesh). If hitches appear on weak TVs, lower quality (F1) or raise `SEG_LEN` cost tradeoffs in `world.gd`.
- Untested in the Godot editor — expect to fix small script errors on first run (check the Output panel).

## Stage 3: custom car importer
Menu -> **IMPORT CUSTOM CAR**. D-pad up/down = rows, left/right = change a value, OK = press, BACK = cancel.
- **Engine requirement:** the Android file picker (Storage Access Framework) only exists from **Godot 4.6**, so the project and CI now use 4.6
  (SDK 35, build-tools 35.0.1, NDK 28.1, JDK 17). Picked files come back as `content://` URIs; they are copied into `user://cars/<id>/`.
- **Formats:** GLB (best, self-contained), GLTF (select the .gltf plus its .bin/textures together), OBJ (+ .mtl and textures).
  Limit 64 MB total; invalid/unsupported files give an on-screen error and nothing is saved.
- **Auto-detection:** up axis, length axis, scale (cars outside 2.5-8 m are scaled to 4.5 m), front/rear (part names like headlight/taillight, else roof position),
  four wheels (by mesh name, else by round/low shape), wheel radius, wheelbase, track, body bounds, mass estimate.
- **Manual fixes:** ROTATE / TILT / FLIP FRONT, per-wheel mesh pickers (selected mesh glows pink in the preview), then radius, wheelbase, track, mass,
  suspension (stiffness, damping, travel), steering angle, torque/power, redline, braking, gearbox (auto/manual), gear count, final drive.
- **Saved cars** appear in the menu under CAR (left/right); DELETE removes them.
- **If your TV has no document picker app** (common on Android TV): copy the model to
  `/storage/emulated/0/Android/data/com.highwaytv.game/files/` (adb push / USB) and use **APP FOLDER FILE**. Stage 4's phone page will add upload from the phone.
- Wheel meshes must be separate objects in the model to spin/steer. If the wheels are fused into the body, the car still drives but its wheels will not turn visually.
- Current drivetrain is rear-wheel drive for imported cars.

## Stage 4: phone controller (no app needed)
Menu -> **PHONE CONTROLLER** shows server status, TV IP, port, pairing code, QR code, connection status and the connected phone's name.
1. Phone and TV on the same Wi-Fi. Scan the QR code, the TV-hosted page opens in the phone browser (turn the phone to landscape).
2. Page: steering wheel, GAS and BRAKE pedals (slide up/down inside a pedal for partial pressure), handbrake, gear +/-, horn, camera, pause,
   a MENU pad (navigate TV menus), and SETTINGS (steering sensitivity, tilt steering, auto/manual gearbox, reset car, upload car files to the TV).
3. Network: HTTP on port 8080 (page + upload) and WebSocket on 8081 (controls, ~30 Hz); if busy it moves up in steps of 2. Local network only, no internet.
4. Security/robustness: random 6-character pairing code in the QR link (needed for the first WebSocket message and for uploads); only one phone at a time
   (a second phone gets "already connected"); the same phone reconnects automatically; if no data arrives for 1.5 s, or the socket closes,
   the TV neutralises steering/throttle/brake/handbrake immediately. NEW PAIRING CODE disconnects the current phone.
5. Car upload: Phone page -> SETTINGS -> choose .glb/.gltf/.obj (and companions). On the TV: IMPORT CUSTOM CAR -> row "APP / PHONE UPLOAD FILE".
- **Tilt steering caveat:** Chrome/Android only exposes motion sensors on secure (https) pages, and the TV serves plain http, so tilt often shows
  "No tilt data". The touch wheel always works. (Workaround for advanced users: enable Chrome flag `unsafely-treat-insecure-origin-as-secure` for the TV address.)
- The QR encoder (`qr_code.gd`, versions 1-6) was cross-checked by porting it to Python and decoding with OpenCV; the pairing URL needs version 2-3.
