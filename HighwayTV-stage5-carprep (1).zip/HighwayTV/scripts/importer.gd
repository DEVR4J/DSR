extends Control
## IMPORT CUSTOM CAR screen (TV-navigable: D-pad up/down = rows, left/right = change, OK = press).
## Flow: pick file(s) -> auto analysis -> optional manual fixes -> SAVE & DRIVE.

const APP_PKG := "com.highwaytv.game"
const CORNER_NAMES := {"fl": "FRONT LEFT", "fr": "FRONT RIGHT", "rl": "REAR LEFT", "rr": "REAR RIGHT"}

var spec: Dictionary = {}
var rep: Dictionary = {}
var model_root: Node3D
var staged_id := ""
var staged_model := ""
var mesh_paths: Array[String] = []
var app_files: Array[String] = []
var app_idx := 0

var _rows: Array[Button] = []
var _status: Label
var _list: VBoxContainer
var _pivot: Node3D
var _ground: MeshInstance3D
var _hl_mat: StandardMaterial3D
var _fd: FileDialog


func _ready() -> void:
	var bg := ColorRect.new()
	bg.color = Color(0.05, 0.06, 0.08)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	_build_preview()

	var title := Label.new()
	title.text = "IMPORT CUSTOM CAR"
	title.add_theme_font_size_override("font_size", 44)
	title.position = Vector2(60, 24)
	add_child(title)

	var scroll := ScrollContainer.new()
	scroll.position = Vector2(1090, 40)
	scroll.size = Vector2(790, 880)
	scroll.follow_focus = true
	add_child(scroll)
	_list = VBoxContainer.new()
	_list.custom_minimum_size = Vector2(760, 0)
	_list.add_theme_constant_override("separation", 6)
	scroll.add_child(_list)

	_status = Label.new()
	_status.position = Vector2(60, 830)
	_status.size = Vector2(1000, 200)
	_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_status.add_theme_font_size_override("font_size", 24)
	add_child(_status)

	_hl_mat = StandardMaterial3D.new()
	_hl_mat.albedo_color = Color(1.0, 0.1, 0.6, 0.55)
	_hl_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_hl_mat.emission_enabled = true
	_hl_mat.emission = Color(1.0, 0.1, 0.6)

	spec = CarSpec.defaults()
	_build_rows()
	_scan_app_folder()
	_refresh()
	_rows[0].grab_focus()
	_set_status("Press OK on BROWSE FILES and pick a .zip (with the model + textures inside), or a .glb / .gltf / .obj file.\n"
		+ "If no picker opens on your TV: copy the file into the app folder and use APP FOLDER FILE.")
	GameInput.back_pressed.connect(_cancel)


func _exit_tree() -> void:
	if GameInput.back_pressed.is_connected(_cancel):
		GameInput.back_pressed.disconnect(_cancel)


func _process(delta: float) -> void:
	_pivot.rotation.y += delta * 0.5


func _set_status(t: String) -> void:
	_status.text = t


# ------------------------------------------------------------------ preview
func _build_preview() -> void:
	var svc := SubViewportContainer.new()
	svc.stretch = true
	svc.position = Vector2(50, 90)
	svc.size = Vector2(1000, 720)
	add_child(svc)
	var vp := SubViewport.new()
	vp.own_world_3d = true
	vp.size = Vector2i(1000, 720)
	svc.add_child(vp)
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.10, 0.11, 0.14)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.6, 0.62, 0.7)
	env.ambient_light_energy = 0.8
	var we := WorldEnvironment.new()
	we.environment = env
	vp.add_child(we)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-45, 35, 0)
	vp.add_child(sun)
	_pivot = Node3D.new()
	vp.add_child(_pivot)
	_ground = MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(14, 14)
	_ground.mesh = pm
	var gm := StandardMaterial3D.new()
	gm.albedo_color = Color(0.18, 0.19, 0.22)
	_ground.material_override = gm
	vp.add_child(_ground)
	var cam := Camera3D.new()
	vp.add_child(cam)
	cam.look_at_from_position(Vector3(4.6, 1.9, 6.6), Vector3(0, 0.1, 0))
	cam.current = true


# --------------------------------------------------------------------- rows
func _row(text_fn: Callable, adjust_fn: Callable = Callable(), press_fn: Callable = Callable(),
		focus_key := "") -> void:
	var b := Button.new()
	b.custom_minimum_size = Vector2(0, 56)
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.add_theme_font_size_override("font_size", 26)
	b.set_meta("text_fn", text_fn)
	b.set_meta("adjust", adjust_fn)
	b.set_meta("press", press_fn)
	b.set_meta("hl", focus_key)
	b.pressed.connect(_on_row_pressed.bind(b))
	b.gui_input.connect(_on_row_input.bind(b))
	b.focus_entered.connect(_on_row_focus.bind(b))
	_list.add_child(b)
	_rows.append(b)


func _on_row_pressed(b: Button) -> void:
	var f: Callable = b.get_meta("press")
	if f.is_valid():
		f.call()
	_refresh()


func _on_row_input(ev: InputEvent, b: Button) -> void:
	var d := 0
	if ev.is_action_pressed("ui_left", true):
		d = -1
	elif ev.is_action_pressed("ui_right", true):
		d = 1
	if d == 0:
		return
	var f: Callable = b.get_meta("adjust")
	if f.is_valid():
		f.call(d)
		b.accept_event()
		_refresh()


func _on_row_focus(b: Button) -> void:
	_highlight(str(b.get_meta("hl")))


func _refresh() -> void:
	for b in _rows:
		b.text = (b.get_meta("text_fn") as Callable).call()
	_ground.position.y = -float(spec.get("radius", 0.34))


func _build_rows() -> void:
	_row(_t_const.bind("BROWSE FILES...   [OK]"), Callable(), _browse)
	_row(_t_app, _adj_app, _load_app)
	_row(_t_const.bind("ROTATE MODEL 90 DEG   [OK]"), Callable(), _turn.bind("y", 90.0))
	_row(_t_const.bind("TILT MODEL 90 DEG (Z-up fix)   [OK]"), Callable(), _turn.bind("x", 90.0))
	_row(_t_const.bind("FLIP FRONT / REAR   [OK]"), Callable(), _turn.bind("y", 180.0))
	for k in CarImporter.CORNERS:
		_row(_t_wheel.bind(k), _adj_wheel.bind(k), Callable(), k)
	_num("WHEEL RADIUS (m)", "radius", 0.01, 0.15, 0.8, 2)
	_num("WHEELBASE (m)", "wheelbase", 0.05, 1.5, 4.5, 2)
	_num("TRACK WIDTH (m)", "track", 0.02, 1.0, 2.4, 2)
	_num("MASS (kg)", "mass", 25.0, 500.0, 4000.0, 0)
	_num("SUSPENSION STIFFNESS", "susp_stiffness", 2.0, 8.0, 80.0, 0)
	_num("SUSPENSION DAMPING", "damp_comp", 0.05, 0.1, 0.9, 2)
	_num("SUSPENSION TRAVEL (m)", "susp_rest", 0.01, 0.12, 0.5, 2)
	_num("MAX STEERING ANGLE (deg)", "max_steer", 1.0, 15.0, 45.0, 0)
	_num("ENGINE TORQUE (Nm)", "peak_torque", 10.0, 80.0, 1200.0, 0)
	_row(_t_power, _adj_power)
	_num("REDLINE (rpm)", "redline", 100.0, 4500.0, 9500.0, 0)
	_num("BRAKING FORCE", "brake_per_kg", 0.002, 0.01, 0.06, 3)
	_row(_t_gearbox, _adj_gearbox, _adj_gearbox.bind(1))
	_num("GEARS", "gears", 1.0, 4.0, 8.0, 0)
	_num("FINAL DRIVE", "final_drive", 0.1, 2.0, 6.0, 1)
	_row(_t_const.bind("SAVE & DRIVE   [OK]"), Callable(), _save_drive)
	_row(_t_const.bind("CANCEL   [OK]"), Callable(), _cancel)


func _num(label: String, key: String, step: float, lo: float, hi: float, decimals: int) -> void:
	_row(_t_num.bind(label, key, decimals), _adj_num.bind(key, step, lo, hi))


func _t_const(s: String) -> String:
	return s


func _t_num(label: String, key: String, decimals: int) -> String:
	return "%s     <  %s  >" % [label, String.num(float(spec.get(key, 0.0)), decimals)]


func _adj_num(d: int, key: String, step: float, lo: float, hi: float) -> void:
	spec[key] = clampf(float(spec.get(key, 0.0)) + d * step, lo, hi)


func _t_power() -> String:
	var kw := float(spec["peak_torque"]) * 5500.0 / 9549.0
	return "ENGINE POWER (kW)     <  %d  >" % int(kw)


func _adj_power(d: int) -> void:
	spec["peak_torque"] = clampf(float(spec["peak_torque"]) + d * 10.0 * 9549.0 / 5500.0, 80.0, 1200.0)


func _t_gearbox() -> String:
	return "GEARBOX     <  %s  >" % ("AUTOMATIC" if bool(spec["automatic"]) else "MANUAL")


func _adj_gearbox(_d: int) -> void:
	spec["automatic"] = not bool(spec["automatic"])


func _t_wheel(k: String) -> String:
	var g: Array = rep.get("wheels", {}).get(k, [])
	var nm := "(none - will be estimated)"
	if g.size() > 0:
		nm = str(g[0]).get_file()
		if g.size() > 1:
			nm += " +%d" % (g.size() - 1)
	return "%s WHEEL:  %s" % [CORNER_NAMES[k], nm]


func _adj_wheel(d: int, k: String) -> void:
	if mesh_paths.is_empty() or model_root == null:
		return
	var g: Array = rep["wheels"].get(k, [])
	var cur := mesh_paths.find(str(g[0])) if g.size() > 0 else -1
	cur = wrapi(cur + d, 0, mesh_paths.size())
	rep["wheels"][k] = [mesh_paths[cur]]
	_refit()
	_highlight(k)


func _t_app() -> String:
	if app_files.is_empty():
		return "APP / PHONE UPLOAD FILE:  (none found)"
	return "APP / PHONE UPLOAD FILE:  <  %s  >   [OK = load]" % app_files[app_idx].get_file()


func _adj_app(d: int) -> void:
	if not app_files.is_empty():
		app_idx = wrapi(app_idx + d, 0, app_files.size())


# ---------------------------------------------------------------- file input
func _browse() -> void:
	if DisplayServer.has_feature(DisplayServer.FEATURE_NATIVE_DIALOG_FILE):
		DisplayServer.file_dialog_show("Select car model", "", "", false,
				DisplayServer.FILE_DIALOG_MODE_OPEN_FILES, PackedStringArray(), _on_native_files)
		_set_status("Pick your model. For glTF with separate .bin/texture files, select them all together.")
	else:
		if _fd == null:
			_fd = FileDialog.new()
			_fd.access = FileDialog.ACCESS_FILESYSTEM
			_fd.file_mode = FileDialog.FILE_MODE_OPEN_FILES
			_fd.use_native_dialog = false
			_fd.filters = PackedStringArray(["*.glb,*.gltf,*.obj,*.bin,*.png,*.jpg,*.jpeg,*.mtl ; 3D model files"])
			_fd.files_selected.connect(_load_paths)
			add_child(_fd)
		_fd.popup_centered_ratio(0.8)


func _on_native_files(ok: bool, paths: PackedStringArray, _filter: int) -> void:
	if ok and paths.size() > 0:
		_load_paths.call_deferred(paths)


func _app_dir() -> String:
	if OS.get_name() == "Android":
		return "/storage/emulated/0/Android/data/%s/files" % APP_PKG
	return OS.get_system_dir(OS.SYSTEM_DIR_DOWNLOADS)


func _scan_app_folder() -> void:
	app_files.clear()
	var dir := _app_dir()
	if OS.get_name() == "Android" and not DirAccess.dir_exists_absolute(dir):
		DirAccess.make_dir_recursive_absolute(dir)
	for f in DirAccess.get_files_at(dir):
		if f.get_extension().to_lower() in CarImporter.MODEL_EXT or f.get_extension().to_lower() == "zip":
			app_files.append(dir + "/" + f)
	for f in DirAccess.get_files_at(PhoneServer.UPLOAD_DIR):
		if f.get_extension().to_lower() in CarImporter.MODEL_EXT or f.get_extension().to_lower() == "zip":
			app_files.append(PhoneServer.UPLOAD_DIR + "/" + f)
	app_idx = 0


func _load_app() -> void:
	if app_files.is_empty():
		_scan_app_folder()
		_set_status("Looked in:\n%s\nNo .zip/.glb/.gltf/.obj found. Copy your file there (e.g. over USB/adb) and try again." % _app_dir())
		return
	var chosen := app_files[app_idx]
	var paths := PackedStringArray([chosen])
	if chosen.get_extension().to_lower() == "zip":
		_load_paths(paths)
		return
	for f in DirAccess.get_files_at(chosen.get_base_dir()):    # companions: .bin, textures, .mtl
		var full := chosen.get_base_dir() + "/" + f
		if full != chosen and f.get_extension().to_lower() in CarImporter.AUX_EXT:
			paths.append(full)
	_load_paths(paths)


func _load_paths(paths: PackedStringArray) -> void:
	_set_status("Importing...")
	await get_tree().process_frame
	_discard_staged()
	var st := CarImporter.stage_files(paths)
	if not st["ok"]:
		_set_status("Import failed: " + str(st["error"]))
		return
	staged_id = st["id"]
	staged_model = st["model"]
	var node := CarImporter.load_model(staged_model)
	if node == null:
		_set_status("Import failed: " + CarImporter.last_error)
		_discard_staged()
		return
	if model_root != null:
		model_root.queue_free()
	model_root = node
	_pivot.add_child(model_root)
	var prep := _read_prep(staged_model.get_base_dir())
	rep = CarImporter.analyze(model_root, Vector3.ZERO if bool(prep.get("oriented", false)) else null)
	if not rep["ok"]:
		_set_status("Import failed: " + str(rep["error"]))
		_discard_staged()
		model_root.queue_free()
		model_root = null
		return
	mesh_paths.clear()
	for p in rep["mesh_paths"]:
		mesh_paths.append(str(p))
	spec = CarSpec.defaults()
	spec["name"] = staged_model.get_file().get_basename()
	spec["mass"] = rep["mass"]
	_merge_rep()
	var balanced := ""
	if prep.has("params"):
		for k in prep["params"]:
			spec[k] = prep["params"][k]
		balanced = "Balanced by Car Prep (%s). " % prep.get("class", "?")
	_set_status(balanced + "Loaded %s: %d/4 wheels auto-detected, front found by %s (%.1f m long).\n"
		% [spec["name"], rep["wheels_found"], rep["method"], rep["length"]]
		+ "Check the model faces away from the camera's left in the preview (use FLIP FRONT if not), "
		+ "fix wheels if needed, tune numbers, then SAVE & DRIVE.")
	_refresh()


func _read_prep(dir: String) -> Dictionary:
	var path := ObjLoader._search(dir, "carprep.json", 0)
	if path == "":
		return {}
	var d: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
	return d if d is Dictionary else {}


func _merge_rep() -> void:
	for k in ["rot", "scale", "offset", "wheels", "wheel_vis_pos", "radius", "wheel_width",
			"wheelbase", "track", "body_pos", "body_size"]:
		spec[k] = rep[k]


func _refit() -> void:
	CarImporter.finalize(rep, model_root)
	_merge_rep()


func _turn(axis: String, deg: float) -> void:
	if model_root == null:
		return
	var rot := CarSpec.v3(rep["rot"])
	if axis == "x":
		rot.x = fposmod(rot.x + deg, 360.0)
	else:
		rot.y = fposmod(rot.y + deg, 360.0)
	var wheels_old: Dictionary = rep["wheels"]
	rep = CarImporter.analyze(model_root, rot)
	if not rep["ok"]:
		_set_status(str(rep["error"]))
		return
	_merge_rep()


func _highlight(key: String) -> void:
	if model_root == null:
		return
	for mi in CarImporter.mesh_nodes(model_root):
		mi.material_overlay = null
	if key == "" or not rep.has("wheels"):
		return
	for pth in rep["wheels"].get(key, []):
		var nd := model_root.get_node_or_null(NodePath(str(pth)))
		if nd != null:
			for mi in CarImporter.mesh_nodes(nd):
				mi.material_overlay = _hl_mat


# ------------------------------------------------------------ save / cancel
func _save_drive() -> void:
	if model_root == null or staged_id == "":
		_set_status("Load a model first (BROWSE FILES).")
		return
	spec["id"] = staged_id
	spec["model_file"] = staged_model
	if not CarSpec.save(spec):
		_set_status("Could not save the car (storage error).")
		return
	staged_id = ""       # saved: keep files
	GameState.car_id = str(spec["id"])
	GameState.goto("res://scenes/main.tscn")


func _discard_staged() -> void:
	if staged_id != "":
		CarSpec.remove_dir("%s/%s" % [CarSpec.ROOT, staged_id])
		staged_id = ""


func _cancel() -> void:
	_discard_staged()
	GameState.goto("res://scenes/menu.tscn")
