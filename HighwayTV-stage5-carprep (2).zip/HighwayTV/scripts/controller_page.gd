class_name ControllerPage
extends RefCounted
## Controller web page served by PhoneServer (embedded so it needs no extra files).
## __WSPORT__ is replaced with the WebSocket port when served.

const HTML := """<!DOCTYPE html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
<title>Highway TV Controller</title>
<style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent;user-select:none;-webkit-user-select:none}
html,body{margin:0;height:100%;background:#0b0d12;color:#fff;font-family:system-ui,sans-serif;overflow:hidden;touch-action:none}
#bar{position:absolute;top:0;left:0;right:0;height:44px;display:flex;align-items:center;gap:10px;padding:0 12px;background:#141821;z-index:5}
#stat{flex:1;font-size:15px}#stat.ok{color:#5ef08a}#stat.bad{color:#ff6b6b}#spd{font-weight:700;color:#4dd2ff}
button,.pedal{font:inherit;color:#fff;border:0;border-radius:14px;background:#262c3a}
#bar button{height:32px;padding:0 12px;font-size:13px}
#drive{position:absolute;top:44px;bottom:0;left:0;right:0;display:flex;padding:10px;gap:10px}
#left{flex:1.3;display:flex;align-items:center;justify-content:center}
#wheelbox{height:min(100%,440px);aspect-ratio:1;touch-action:none}
#wheel{width:100%;height:100%}
#mid{width:21%;display:flex;flex-direction:column;gap:8px;justify-content:center}
#mid button{flex:1;font-size:15px;font-weight:600}
#mid button:active,#mid button.on{background:#e8202a}
#right{flex:1.1;display:flex;gap:10px}
.pedal{flex:1;display:flex;align-items:flex-end;justify-content:center;padding-bottom:14px;font-weight:700;letter-spacing:1px;position:relative;overflow:hidden;touch-action:none}
.pedal::before{content:"";position:absolute;left:0;right:0;bottom:0;height:calc(var(--v,0)*100%);background:var(--c);opacity:.55}
#brake{--c:#e8202a}#gas{--c:#22c55e}
.pedal span{position:relative}
.panel{position:absolute;top:44px;bottom:0;left:0;right:0;background:#0b0d12;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;padding:14px;z-index:4;overflow:auto;touch-action:pan-y}
.panel[hidden]{display:none}
#dpad{display:grid;grid-template-columns:repeat(3,88px);grid-template-rows:repeat(3,88px);gap:8px}
#dpad button{font-size:22px}
#dpad .ok{background:#e8202a}
.row{display:flex;align-items:center;gap:10px;font-size:15px}
.row button{padding:10px 16px}
.row button.on{background:#22c55e}
#rot{display:none;position:absolute;inset:0;background:#0b0d12;z-index:9;align-items:center;justify-content:center;font-size:20px;text-align:center;padding:30px}
@media (orientation:portrait){#rot{display:flex}}
</style></head><body>
<div id="rot">Rotate your phone to landscape</div>
<div id="bar"><span id="stat">Connecting...</span><span id="spd"></span><button id="bmenu">MENU</button><button id="bset">SETTINGS</button></div>
<div id="drive">
 <div id="left"><div id="wheelbox"><svg id="wheel" viewBox="-100 -100 200 200">
  <circle r="92" fill="none" stroke="#2b3345" stroke-width="16"/>
  <circle r="92" fill="none" stroke="#3b455e" stroke-width="3"/>
  <rect x="-88" y="-7" width="176" height="14" rx="7" fill="#2b3345"/>
  <rect x="-7" y="0" width="14" height="88" rx="7" fill="#2b3345"/>
  <circle r="22" fill="#e8202a"/>
  <rect x="-5" y="-96" width="10" height="22" rx="4" fill="#fff"/>
 </svg></div></div>
 <div id="mid">
  <button data-b="gear_up">GEAR +</button><button data-b="gear_down">GEAR -</button>
  <button id="hb">HANDBRAKE</button><button id="horn">HORN</button>
  <button data-b="camera">CAMERA</button><button data-b="pause">PAUSE</button>
 </div>
 <div id="right"><div class="pedal" id="brake"><span>BRAKE</span></div><div class="pedal" id="gas"><span>GAS</span></div></div>
</div>
<div class="panel" id="menu" hidden>
 <div id="dpad">
  <span></span><button data-n="up">&#9650;</button><span></span>
  <button data-n="left">&#9664;</button><button data-n="ok" class="ok">OK</button><button data-n="right">&#9654;</button>
  <span></span><button data-n="down">&#9660;</button><button data-n="back">BACK</button>
 </div>
 <div class="row">Navigate the TV menus with this pad</div>
</div>
<div class="panel" id="set" hidden>
 <div class="row">Steering sensitivity <input type="range" id="sens" min="0.5" max="2" step="0.05"> <span id="sensv"></span></div>
 <div class="row"><button id="tilt">Tilt steering: OFF</button><button id="inv">Invert tilt: OFF</button></div>
 <div class="row" id="tiltmsg" style="color:#ffb454"></div>
 <div class="row">Camera distance <input type="range" id="cd" min="0.5" max="2.5" step="0.05" value="1"></div>
 <div class="row">Camera angle <input type="range" id="cp" min="-20" max="70" step="1" value="0"></div>
 <div class="row">Rotate 360 <input type="range" id="cy" min="-180" max="180" step="1" value="0"></div>
 <div class="row"><button data-b="gearbox">Auto / Manual gearbox</button><button data-b="reset">Reset car</button></div>
 <div class="row">Send a car model to the TV: <input type="file" id="up" multiple></div>
 <div class="row" id="upmsg"></div>
</div>
<script>
(function(){
var Q=new URLSearchParams(location.search),TOKEN=(Q.get('t')||'').toUpperCase(),WS_PORT=__WSPORT__;
if(!TOKEN){TOKEN=(prompt('Enter the pairing code shown on the TV')||'').toUpperCase().trim();}
var cid=localStorage.getItem('cid');if(!cid){cid=Math.random().toString(36).slice(2,10);localStorage.setItem('cid',cid);}
var sens=parseFloat(localStorage.getItem('sens')||'1'),invert=localStorage.getItem('inv')==='1';
var st={th:0,b:0,h:0},ws=null,open=false,paired=false,denied=false,busy=false;
var tilt=false,tilt0=null,tiltVal=0,tiltSeen=false,wAng=0,dragId=null,lastA=0,MAXA=135;
var $=function(i){return document.getElementById(i)};
function stat(t,c){var e=$('stat');e.textContent=t;e.className=c||'';}
function pname(){var m=/; ([^;)]+) Build/.exec(navigator.userAgent);return(m?m[1]:(/iPhone/.test(navigator.userAgent)?'iPhone':'Phone')).slice(0,24);}
function send(o){if(open&&paired)ws.send(JSON.stringify(o));}
function connect(){
 busy=false;
 try{ws=new WebSocket('ws://'+location.hostname+':'+WS_PORT+'/');}catch(e){setTimeout(connect,1000);return;}
 ws.onopen=function(){open=true;ws.send(JSON.stringify({t:'hello',token:TOKEN,cid:cid,name:pname()}));stat('Pairing...');};
 ws.onmessage=function(e){var d;try{d=JSON.parse(e.data);}catch(x){return;}
  if(d.t==='ok'){paired=true;stat('Connected to TV','ok');}
  else if(d.t==='busy'){busy=true;stat('Another phone is already connected','bad');}
  else if(d.t==='denied'){denied=true;stat('Wrong code - scan the QR code again','bad');}
  else if(d.t==='st'){$('spd').textContent=d.k+' km/h  '+d.g;}};
 ws.onclose=function(){open=false;paired=false;if(!denied&&!busy)stat('Reconnecting...');setTimeout(connect,busy?3000:1000);};
}
connect();
setInterval(function(){send({t:'i',s:steer(),th:st.th,b:st.b,h:st.h});},33);
function steer(){return Math.max(-1,Math.min(1,wAng/MAXA*sens));}
var box=$('wheelbox'),wheel=$('wheel');
function ang(e){var r=box.getBoundingClientRect();return Math.atan2(e.clientY-(r.top+r.height/2),e.clientX-(r.left+r.width/2))*180/Math.PI;}
box.addEventListener('pointerdown',function(e){if(tilt)return;dragId=e.pointerId;box.setPointerCapture(e.pointerId);lastA=ang(e);e.preventDefault();});
box.addEventListener('pointermove',function(e){if(e.pointerId!==dragId)return;var a=ang(e),d=a-lastA;if(d>180)d-=360;if(d<-180)d+=360;lastA=a;wAng=Math.max(-MAXA,Math.min(MAXA,wAng+d));});
function endDrag(e){if(e.pointerId===dragId)dragId=null;}
box.addEventListener('pointerup',endDrag);box.addEventListener('pointercancel',endDrag);
(function loop(){if(tilt)wAng=tiltVal*MAXA;else if(dragId===null)wAng*=0.85;
 wheel.style.transform='rotate('+wAng+'deg)';requestAnimationFrame(loop);})();
function pedal(id,key){var el=$(id),pid=null;
 function upd(e){var r=el.getBoundingClientRect(),v=1-(e.clientY-r.top)/r.height;v=Math.max(0.2,Math.min(1,v*1.25+0.05));st[key]=v;el.style.setProperty('--v',v);}
 el.addEventListener('pointerdown',function(e){pid=e.pointerId;el.setPointerCapture(pid);upd(e);e.preventDefault();});
 el.addEventListener('pointermove',function(e){if(e.pointerId===pid)upd(e);});
 function up(e){if(e.pointerId===pid){pid=null;st[key]=0;el.style.setProperty('--v',0);}}
 el.addEventListener('pointerup',up);el.addEventListener('pointercancel',up);}
pedal('gas','th');pedal('brake','b');
function hold(id,on,off){var el=$(id);
 el.addEventListener('pointerdown',function(e){el.setPointerCapture(e.pointerId);el.classList.add('on');on();e.preventDefault();});
 function up(){el.classList.remove('on');off();}
 el.addEventListener('pointerup',up);el.addEventListener('pointercancel',up);}
hold('hb',function(){st.h=1;},function(){st.h=0;});
hold('horn',function(){send({t:'b',n:'horn',v:true});},function(){send({t:'b',n:'horn',v:false});});
Array.prototype.forEach.call(document.querySelectorAll('[data-b]'),function(b){b.addEventListener('pointerdown',function(e){send({t:'b',n:b.getAttribute('data-b')});e.preventDefault();});});
Array.prototype.forEach.call(document.querySelectorAll('[data-n]'),function(b){b.addEventListener('pointerdown',function(e){send({t:'nav',n:b.getAttribute('data-n')});e.preventDefault();});});
function panel(id){var p=$(id),show=p.hidden;$('menu').hidden=true;$('set').hidden=true;p.hidden=!show;}
$('bmenu').onclick=function(){panel('menu');};$('bset').onclick=function(){panel('set');};
$('stat').onclick=function(){try{document.documentElement.requestFullscreen();}catch(e){}try{navigator.wakeLock.request('screen');}catch(e){}};
var sl=$('sens');sl.value=sens;$('sensv').textContent=sens.toFixed(2);
sl.oninput=function(){sens=parseFloat(sl.value);localStorage.setItem('sens',sens);$('sensv').textContent=sens.toFixed(2);};
function sendCam(){send({t:'cam',d:parseFloat($('cd').value),p:parseFloat($('cp').value),y:parseFloat($('cy').value)});}
['cd','cp','cy'].forEach(function(i){$(i).oninput=sendCam;});
function onTilt(e){tiltSeen=true;var a=(screen.orientation&&screen.orientation.angle!==undefined)?screen.orientation.angle:(window.orientation||0),v;
 if(a===90)v=e.beta;else if(a===270||a===-90)v=-e.beta;else v=e.gamma;if(v==null)return;
 if(tilt0===null)tilt0=v;var x=Math.max(-1,Math.min(1,(v-tilt0)/40));tiltVal=invert?-x:x;}
function tiltOn(){window.addEventListener('deviceorientation',onTilt);tilt=true;tilt0=null;tiltSeen=false;$('tilt').textContent='Tilt steering: ON';$('tilt').className='on';
 setTimeout(function(){if(tilt&&!tiltSeen)$('tiltmsg').textContent='No tilt data: this browser blocks motion sensors on plain http. Use the touch wheel.';},1500);}
function tiltOff(){window.removeEventListener('deviceorientation',onTilt);tilt=false;tiltVal=0;$('tilt').textContent='Tilt steering: OFF';$('tilt').className='';$('tiltmsg').textContent='';}
$('tilt').onclick=function(){if(tilt){tiltOff();return;}
 if(typeof DeviceOrientationEvent!=='undefined'&&typeof DeviceOrientationEvent.requestPermission==='function'){DeviceOrientationEvent.requestPermission().then(function(r){if(r==='granted')tiltOn();});}else tiltOn();};
$('inv').onclick=function(){invert=!invert;localStorage.setItem('inv',invert?'1':'0');$('inv').textContent='Invert tilt: '+(invert?'ON':'OFF');$('inv').className=invert?'on':'';};
$('inv').textContent='Invert tilt: '+(invert?'ON':'OFF');$('inv').className=invert?'on':'';
$('up').onchange=function(){var fs=Array.prototype.slice.call($('up').files),n=0,m=$('upmsg');
 (function next(){if(!fs.length){m.textContent='Done: '+n+' file(s) sent. On the TV use IMPORT CUSTOM CAR > APP FOLDER FILE.';return;}
  var f=fs.shift();m.textContent='Sending '+f.name+'...';
  fetch('/upload?t='+encodeURIComponent(TOKEN)+'&name='+encodeURIComponent(f.name),{method:'POST',body:f}).then(function(r){if(r.ok)n++;else m.textContent='Rejected '+f.name+' ('+r.status+')';next();}).catch(function(){m.textContent='Upload failed';});})();};
})();
</script></body></html>"""
