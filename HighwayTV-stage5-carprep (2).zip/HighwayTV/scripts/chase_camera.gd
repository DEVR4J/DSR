class_name ChaseCamera
extends Camera3D
## Chase / close-rear / hood cameras plus a 360 degree FREE VIEW orbit camera.
## Distance, angle and rotation sliders (GameState.cam_*) apply to every mode:
## distance scales the orbit radius, angle tilts it up/down, rotation swings it
## all the way around the car (in HOOD mode they turn the head instead).
## FREE VIEW also answers to the right stick / J L I K keys / phone sliders.

enum Mode { CHASE, CLOSE, HOOD, FREE }
const MODE_NAMES := ["CHASE", "CLOSE REAR", "HOOD", "FREE VIEW 360"]
const BASE_DIST := [7.5, 4.6, 0.0, 8.0]
const BASE_PITCH := [12.0, 10.0, 0.0, 22.0]

var target: HighwayCar
var mode: int = Mode.CHASE
var distance_scale := 1.0     # set from the car's length
var _yaw := 0.0
var _snap := true
var _y := 0.0


func _ready() -> void:
	near = 0.1
	far = 1500.0
	process_mode = Node.PROCESS_MODE_ALWAYS    # keeps updating while paused (live slider preview)


func next_mode() -> void:
	mode = (mode + 1) % MODE_NAMES.size()
	_snap = true


func reset_view() -> void:
	GameState.cam_dist = 1.0
	GameState.cam_pitch = 0.0
	GameState.cam_yaw = 0.0


func snap() -> void:
	_snap = true


func _physics_process(delta: float) -> void:
	if not get_tree().paused:
		_update(delta)


func _process(delta: float) -> void:
	if get_tree().paused:
		_update(delta)


func _update(delta: float) -> void:
	if target == null:
		return
	if not get_tree().paused:
		var yaw_in := Input.get_axis("cam_left", "cam_right")
		var pitch_in := Input.get_axis("cam_down", "cam_up")
		var zoom_in := Input.get_axis("cam_in", "cam_out")
		if mode == Mode.FREE or absf(yaw_in) + absf(pitch_in) + absf(zoom_in) > 0.0:
			GameState.cam_yaw = wrapf(GameState.cam_yaw + yaw_in * 120.0 * delta, -180.0, 180.0)
			GameState.cam_pitch = clampf(GameState.cam_pitch + pitch_in * 60.0 * delta, -20.0, 70.0)
			GameState.cam_dist = clampf(GameState.cam_dist * (1.0 + zoom_in * 0.8 * delta), 0.5, 2.5)

	var t := target.global_transform
	var f := -t.basis.z
	f.y = 0.0
	var heading := _yaw
	if f.length() > 0.01:
		f = f.normalized()
		heading = atan2(-f.x, -f.z)
	if _snap:
		_yaw = heading
	else:
		_yaw = lerp_angle(_yaw, heading, 1.0 - exp(-4.0 * delta))

	var k := clampf(target.speed_kmh / 200.0, 0.0, 1.0)
	var yaw_off := deg_to_rad(GameState.cam_yaw)

	if mode == Mode.HOOD:
		var look := Basis(Vector3.UP, -yaw_off) * Basis(Vector3.RIGHT, deg_to_rad(-GameState.cam_pitch * 0.5))
		global_transform = t * Transform3D(look, target.hood_cam_pos)
		fov = lerpf(72.0, 90.0, k)
		h_offset = 0.0
		v_offset = 0.0
		_snap = false
		return

	var base_d: float = BASE_DIST[mode]
	var base_p: float = BASE_PITCH[mode]
	var dist := base_d * distance_scale * GameState.cam_dist
	var pitch := deg_to_rad(clampf(base_p + GameState.cam_pitch, -20.0, 85.0))
	var yaw := _yaw + yaw_off
	var back := Vector3(sin(yaw), 0.0, cos(yaw))        # direction from car to camera (flat)
	if _snap:
		_y = t.origin.y
	else:
		_y = lerpf(_y, t.origin.y, 1.0 - exp(-6.0 * delta))
	var center := Vector3(t.origin.x, _y, t.origin.z) + Vector3.UP * 1.0
	var desired := center + (back * cos(pitch) + Vector3.UP * sin(pitch)) * dist
	var focus := center
	if mode != Mode.FREE:
		focus = center - back * 3.0                       # look a little ahead of the car

	# Collision avoidance: pull the camera in if geometry is between car and camera
	var space := get_world_3d().direct_space_state
	var q := PhysicsRayQueryParameters3D.create(t.origin + Vector3.UP * 1.0, desired)
	q.exclude = [target.get_rid()]
	var hit := space.intersect_ray(q)
	if not hit.is_empty():
		desired = hit.position + hit.normal * 0.3

	look_at_from_position(desired, focus, Vector3.UP)
	fov = lerpf(62.0, 88.0, k)
	var shake := 0.02 * k
	h_offset = randf_range(-shake, shake)
	v_offset = randf_range(-shake, shake)
	_snap = false
