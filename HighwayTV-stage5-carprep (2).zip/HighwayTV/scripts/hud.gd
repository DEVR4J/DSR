class_name HUD
extends CanvasLayer
## TV-safe HUD: speed/RPM gauge, gear, distance, time, camera, pause overlay.

class Gauge extends Control:
	var frac := 0.0
	func _draw() -> void:
		var c := size * 0.5
		var r := minf(size.x, size.y) * 0.44
		draw_arc(c, r, deg_to_rad(135), deg_to_rad(405), 72, Color(1, 1, 1, 0.14), 16.0, true)
		if frac > 0.005:
			var col := Color(0.25, 0.85, 1.0) if frac < 0.82 else Color(1.0, 0.25, 0.15)
			draw_arc(c, r, deg_to_rad(135), deg_to_rad(135 + 270.0 * frac), 72, col, 16.0, true)

var car: HighwayCar
var cam: ChaseCamera
var extra_text := ""
var distance_m := 0.0
var elapsed := 0.0

var _gauge: Gauge
var _speed: Label
var _gear: Label
var _tl: Label
var _tr: Label
var _hint: Label
signal resume_requested
signal menu_requested

var _pause: ColorRect
var _resume_btn: Button
var _view_btn: Button
var _sliders: Dictionary = {}
var _hint_t := 14.0


func _label(size: int, align: int = HORIZONTAL_ALIGNMENT_LEFT) -> Label:
	var l := Label.new()
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", Color(1, 1, 1))
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
	l.add_theme_constant_override("outline_size", 6)
	l.horizontal_alignment = align as HorizontalAlignment
	return l


func _ready() -> void:
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)

	_gauge = Gauge.new()
	_gauge.anchor_left = 1.0
	_gauge.anchor_right = 1.0
	_gauge.anchor_top = 1.0
	_gauge.anchor_bottom = 1.0
	_gauge.offset_left = -440.0
	_gauge.offset_top = -440.0
	_gauge.offset_right = -60.0
	_gauge.offset_bottom = -60.0
	root.add_child(_gauge)
	var vb := VBoxContainer.new()
	vb.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	vb.alignment = BoxContainer.ALIGNMENT_CENTER
	_gauge.add_child(vb)
	_speed = _label(112, HORIZONTAL_ALIGNMENT_CENTER)
	vb.add_child(_speed)
	var unit := _label(28, HORIZONTAL_ALIGNMENT_CENTER)
	unit.text = "KM/H"
	vb.add_child(unit)
	_gear = _label(48, HORIZONTAL_ALIGNMENT_CENTER)
	vb.add_child(_gear)

	_tl = _label(30)
	_tl.position = Vector2(60, 40)
	root.add_child(_tl)

	_tr = _label(26, HORIZONTAL_ALIGNMENT_RIGHT)
	_tr.anchor_left = 1.0
	_tr.anchor_right = 1.0
	_tr.offset_left = -620.0
	_tr.offset_right = -60.0
	_tr.offset_top = 40.0
	root.add_child(_tr)

	_hint = _label(24)
	_hint.anchor_top = 1.0
	_hint.anchor_bottom = 1.0
	_hint.offset_left = 60.0
	_hint.offset_top = -140.0
	_hint.offset_bottom = -50.0
	_hint.text = "LEFT/RIGHT steer   UP accelerate   DOWN brake/reverse\nOK camera   BACK pause   (keyboard: F1 quality, F2 environment)"
	root.add_child(_hint)

	_pause = ColorRect.new()
	_pause.color = Color(0, 0, 0, 0.3)
	_pause.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_pause.visible = false
	root.add_child(_pause)
	var title := _label(64)
	title.text = "PAUSED"
	title.position = Vector2(100, 90)
	_pause.add_child(title)
	var panel := PanelContainer.new()
	panel.position = Vector2(1130, 90)
	panel.custom_minimum_size = Vector2(700, 0)
	_pause.add_child(panel)
	var vb2 := VBoxContainer.new()
	vb2.add_theme_constant_override("separation", 14)
	panel.add_child(vb2)
	_resume_btn = _button("RESUME", resume_requested.emit)
	vb2.add_child(_resume_btn)
	_view_btn = _button("", _cycle_view)
	vb2.add_child(_view_btn)
	_add_slider(vb2, "dist", "CAMERA DISTANCE", 0.5, 2.5, 0.05)
	_add_slider(vb2, "pitch", "CAMERA ANGLE (up/down)", -20.0, 70.0, 1.0)
	_add_slider(vb2, "yaw", "ROTATE AROUND CAR (360)", -180.0, 180.0, 1.0)
	vb2.add_child(_button("RESET CAMERA", _reset_cam))
	vb2.add_child(_button("MAIN MENU", menu_requested.emit))


func _button(text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 66)
	b.add_theme_font_size_override("font_size", 30)
	b.pressed.connect(cb)
	return b


func _add_slider(parent: Control, key: String, text: String, lo: float, hi: float, step: float) -> void:
	var lab := Label.new()
	lab.add_theme_font_size_override("font_size", 26)
	parent.add_child(lab)
	var sl := HSlider.new()
	sl.min_value = lo
	sl.max_value = hi
	sl.step = step
	sl.custom_minimum_size = Vector2(0, 44)
	sl.focus_mode = Control.FOCUS_ALL
	sl.value_changed.connect(_on_slider.bind(key))
	parent.add_child(sl)
	_sliders[key] = {"slider": sl, "label": lab, "text": text}


func _on_slider(v: float, key: String) -> void:
	match key:
		"dist": GameState.cam_dist = v
		"pitch": GameState.cam_pitch = v
		"yaw": GameState.cam_yaw = v
	_refresh_sliders()


func _refresh_sliders() -> void:
	var vals := {"dist": GameState.cam_dist, "pitch": GameState.cam_pitch, "yaw": GameState.cam_yaw}
	for key in _sliders:
		var e: Dictionary = _sliders[key]
		var sl: HSlider = e["slider"]
		if not is_equal_approx(sl.value, float(vals[key])):
			sl.set_value_no_signal(float(vals[key]))
		(e["label"] as Label).text = "%s:  %.2f" % [e["text"], float(vals[key])] if key == "dist" \
				else "%s:  %d" % [e["text"], int(vals[key])]
	_view_btn.text = "VIEW MODE:  %s   (OK = next)" % ChaseCamera.MODE_NAMES[cam.mode]


func _cycle_view() -> void:
	cam.next_mode()
	_refresh_sliders()


func _reset_cam() -> void:
	cam.reset_view()
	_refresh_sliders()


func set_paused(p: bool) -> void:
	_pause.visible = p
	if p:
		_refresh_sliders()
		_resume_btn.grab_focus()


func _process(delta: float) -> void:
	if car == null:
		return
	if not get_tree().paused:
		distance_m += absf(car.speed_ms) * delta
		elapsed += delta
		_hint_t -= delta
		_hint.modulate.a = clampf(_hint_t, 0.0, 1.0)
	_gauge.frac = clampf(car.engine_rpm / (car.redline_rpm * 1.05), 0.0, 1.0)
	_gauge.queue_redraw()
	_speed.text = str(int(round(car.speed_kmh)))
	if car.gear == -1:
		_gear.text = "R"
	elif car.gear == 0:
		_gear.text = "N"
	else:
		_gear.text = ("D" if car.automatic else "M") + str(car.gear)
	GameState.speed_kmh = car.speed_kmh
	GameState.gear_text = _gear.text
	var mins := int(elapsed) / 60
	var secs := int(elapsed) % 60
	_tl.text = "DIST  %.2f km\nTIME  %02d:%02d" % [distance_m / 1000.0, mins, secs]
	var t := "%s CAM   %d FPS" % [ChaseCamera.MODE_NAMES[cam.mode], Engine.get_frames_per_second()]
	if PhoneServer.status == PhoneServer.Status.CONNECTED:
		t += "\nPHONE: " + PhoneServer.phone_name
	elif PhoneServer.status == PhoneServer.Status.WAITING:
		t += "\nPHONE: not connected"
	if extra_text != "":
		t += "\n" + extra_text
	if car.last_0_100 > 0.0:
		t += "\n0-100: %.1f s" % car.last_0_100
	_tr.text = t
