extends Node
## Autoload "PhoneServer": local Wi-Fi phone controller.
##  - HTTP server (port P) serves the controller web page and accepts car uploads.
##  - WebSocket server (port P+1) carries controls from the phone browser.
## Pairing: the QR code contains http://<tv-ip>:P/?t=<token>; the page sends the token
## in its first message. One active phone at a time. If it goes silent for TIMEOUT
## seconds (or disconnects) all controls are neutralised immediately.

signal changed

enum Status { STOPPED, WAITING, CONNECTED }
const BASE_PORT := 8080
const TIMEOUT := 1.5
const UPLOAD_DIR := "user://phone_uploads"
const TOKEN_CHARS := "ABCDEFGHJKMNPQRSTUVWXYZ23456789"
const REASONS := {200: "OK", 204: "No Content", 403: "Forbidden", 404: "Not Found",
		413: "Payload Too Large", 415: "Unsupported Media Type", 500: "Server Error"}

var status := Status.STOPPED
var token := ""
var ip := ""
var http_port := 0
var ws_port := 0
var phone_name := ""
var last_message := ""

var _http := TCPServer.new()
var _ws := TCPServer.new()
var _conns: Array[HttpConn] = []
var _clients: Array[Client] = []
var _active: Client = null
var _tele_t := 0.0


class HttpConn:
	var stream: StreamPeerTCP
	var buf := PackedByteArray()
	var born := 0.0
	var header_done := false
	var file: FileAccess = null
	var body_left := 0
	var close_at := 0.0


class Client:
	var peer: WebSocketPeer
	var born := 0.0
	var last_seen := 0.0
	var authed := false
	var cid := ""
	var pname := ""


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	start()


func _now() -> float:
	return Time.get_ticks_msec() / 1000.0


func url() -> String:
	return "http://%s:%d/?t=%s" % [ip, http_port, token]


# ------------------------------------------------------------------ control
func start() -> void:
	if status != Status.STOPPED:
		return
	token = _new_token()
	ip = _find_ip()
	http_port = 0
	for p in range(BASE_PORT, BASE_PORT + 40, 2):
		if _http.listen(p) == OK:
			if _ws.listen(p + 1) == OK:
				http_port = p
				ws_port = p + 1
				break
			_http.stop()
	if http_port == 0:
		last_message = "Could not open a network port"
		changed.emit()
		return
	status = Status.WAITING
	last_message = "Waiting for phone"
	changed.emit()


func stop() -> void:
	_deactivate("Server stopped")
	for c in _clients:
		c.peer.close()
	_clients.clear()
	for c in _conns:
		c.stream.disconnect_from_host()
	_conns.clear()
	_http.stop()
	_ws.stop()
	http_port = 0
	ws_port = 0
	status = Status.STOPPED
	changed.emit()


func new_pairing_code() -> void:
	token = _new_token()
	if _active != null:
		_active.peer.close()
	_deactivate("New pairing code created")
	for c in _clients:
		c.authed = false
	changed.emit()


func _new_token() -> String:
	var b := Crypto.new().generate_random_bytes(6)
	var t := ""
	for x in b:
		t += TOKEN_CHARS[x % TOKEN_CHARS.length()]
	return t


func _find_ip() -> String:
	var best := ""
	var rank := 99
	for a in IP.get_local_addresses():
		if a.contains(":") or not a.contains("."):
			continue
		var r := 99
		if a.begins_with("192.168."):
			r = 0
		elif a.begins_with("10."):
			r = 1
		elif a.begins_with("172."):
			var second := int(a.split(".")[1])
			if second >= 16 and second <= 31:
				r = 2
		if r < rank:
			rank = r
			best = a
	return best if best != "" else "unknown"


# --------------------------------------------------------------------- loop
func _process(delta: float) -> void:
	if status == Status.STOPPED:
		return
	var now := _now()
	_poll_http(now)
	_poll_ws(now)
	if _active != null and now - _active.last_seen > TIMEOUT:
		_deactivate("Phone timed out")
	_tele_t += delta
	if _tele_t > 0.2 and _active != null:
		_tele_t = 0.0
		_send(_active, {"t": "st", "k": int(GameState.speed_kmh), "g": GameState.gear_text})


# ---------------------------------------------------------------- websocket
func _poll_ws(now: float) -> void:
	while _ws.is_connection_available():
		var s := _ws.take_connection()
		var cl := Client.new()
		cl.peer = WebSocketPeer.new()
		if cl.peer.accept_stream(s) != OK:
			continue
		cl.born = now
		cl.last_seen = now
		_clients.append(cl)
	for cl in _clients.duplicate():
		cl.peer.poll()
		match cl.peer.get_ready_state():
			WebSocketPeer.STATE_OPEN:
				while cl.peer.get_available_packet_count() > 0:
					_on_message(cl, cl.peer.get_packet().get_string_from_utf8(), now)
				if not cl.authed and now - cl.born > 5.0:
					cl.peer.close()
			WebSocketPeer.STATE_CLOSED:
				_clients.erase(cl)
				if cl == _active:
					_deactivate("Phone disconnected")


func _send(cl: Client, d: Dictionary) -> void:
	if cl.peer.get_ready_state() == WebSocketPeer.STATE_OPEN:
		cl.peer.send_text(JSON.stringify(d))


func _f(v: Variant) -> float:
	var x := float(v)
	return 0.0 if is_nan(x) or is_inf(x) else x


func _on_message(cl: Client, txt: String, now: float) -> void:
	var d: Variant = JSON.parse_string(txt)
	if not (d is Dictionary):
		return
	cl.last_seen = now
	var t := str(d.get("t", ""))
	if t == "hello":
		_hello(cl, d, now)
		return
	if not cl.authed:
		return
	match t:
		"i":
			if _active == null:
				_activate(cl)
			if cl == _active:
				GameInput.set_remote(_f(d.get("s", 0)), _f(d.get("th", 0)), _f(d.get("b", 0)), _f(d.get("h", 0)))
		"b":
			if cl == _active or _active == null:
				_button(str(d.get("n", "")), bool(d.get("v", true)))
		"nav":
			if cl == _active or _active == null:
				_nav(str(d.get("n", "")))


func _hello(cl: Client, d: Dictionary, now: float) -> void:
	if str(d.get("token", "")).to_upper().strip_edges() != token:
		_send(cl, {"t": "denied"})
		cl.peer.close()
		return
	var cid := str(d.get("cid", "")).substr(0, 24)
	if _active != null and _active != cl:
		if _active.cid != cid and now - _active.last_seen <= TIMEOUT:
			_send(cl, {"t": "busy"})          # multiple-device protection
			cl.peer.close()
			return
		_active.peer.close()                   # same phone reconnecting
		_clients.erase(_active)
		_active = null
	cl.cid = cid
	cl.pname = _clean(str(d.get("name", "Phone")))
	cl.authed = true
	_activate(cl)
	_send(cl, {"t": "ok", "name": cl.pname})


func _clean(s: String) -> String:
	var out := ""
	for ch in s.substr(0, 24):
		if ch.unicode_at(0) >= 32:
			out += ch
	return out if out != "" else "Phone"


func _activate(cl: Client) -> void:
	_active = cl
	phone_name = cl.pname
	status = Status.CONNECTED
	last_message = "Connected"
	changed.emit()


func _deactivate(reason: String) -> void:
	GameInput.clear_remote()                   # input neutralisation
	_active = null
	phone_name = ""
	if status == Status.CONNECTED:
		status = Status.WAITING
	last_message = reason
	changed.emit()


func _button(n: String, v: bool) -> void:
	match n:
		"gear_up": GameInput.gear_up_pressed.emit()
		"gear_down": GameInput.gear_down_pressed.emit()
		"camera": GameInput.camera_pressed.emit()
		"pause": GameInput.pause_pressed.emit()
		"reset": GameInput.reset_pressed.emit()
		"gearbox": GameInput.gearbox_toggle_pressed.emit()
		"horn": GameInput.horn_changed.emit(v)


func _nav(n: String) -> void:
	match n:
		"up": _press_action("ui_up")
		"down": _press_action("ui_down")
		"left": _press_action("ui_left")
		"right": _press_action("ui_right")
		"ok":
			_press_action("ui_accept")
			GameInput.accept_pressed.emit()
		"back": GameInput.back_pressed.emit()


func _press_action(act: String) -> void:
	var ev := InputEventAction.new()
	ev.action = act
	ev.pressed = true
	Input.parse_input_event(ev)
	await get_tree().create_timer(0.05, true).timeout
	var up := InputEventAction.new()
	up.action = act
	up.pressed = false
	Input.parse_input_event(up)


# --------------------------------------------------------------------- http
func _poll_http(now: float) -> void:
	while _http.is_connection_available():
		var c := HttpConn.new()
		c.stream = _http.take_connection()
		c.born = now
		_conns.append(c)
	for c in _conns.duplicate():
		c.stream.poll()
		var st := c.stream.get_status()
		if st == StreamPeerTCP.STATUS_ERROR or st == StreamPeerTCP.STATUS_NONE:
			_drop(c)
			continue
		if c.close_at > 0.0:
			if now > c.close_at:
				_drop(c)
			continue
		if st == StreamPeerTCP.STATUS_CONNECTED:
			var n := c.stream.get_available_bytes()
			if n > 0:
				var res := c.stream.get_data(n)
				if res[0] == OK:
					_http_feed(c, res[1])
		if now - c.born > 20.0:
			_drop(c)


func _drop(c: HttpConn) -> void:
	if c.file != null:
		c.file.close()
		c.file = null
	c.stream.disconnect_from_host()
	_conns.erase(c)


func _find_end(b: PackedByteArray) -> int:
	for i in range(0, b.size() - 3):
		if b[i] == 13 and b[i + 1] == 10 and b[i + 2] == 13 and b[i + 3] == 10:
			return i
	return -1


func _http_feed(c: HttpConn, data: PackedByteArray) -> void:
	if c.header_done:
		_upload_chunk(c, data)
		return
	c.buf.append_array(data)
	var end := _find_end(c.buf)
	if end < 0:
		if c.buf.size() > 16384:
			_drop(c)
		return
	c.header_done = true
	var head := c.buf.slice(0, end).get_string_from_utf8()
	var rest := c.buf.slice(end + 4)
	c.buf = PackedByteArray()
	var lines := head.split("\r\n")
	var parts := lines[0].split(" ")
	if parts.size() < 2:
		_drop(c)
		return
	var headers := {}
	for i in range(1, lines.size()):
		var kv := lines[i].split(":", true, 1)
		if kv.size() == 2:
			headers[kv[0].strip_edges().to_lower()] = kv[1].strip_edges()
	var target := parts[1]
	var path := target.get_slice("?", 0)
	var query := _parse_query(target.get_slice("?", 1) if target.contains("?") else "")
	if parts[0] == "GET" and (path == "/" or path == "/index.html"):
		_respond(c, 200, "text/html; charset=utf-8", ControllerPage.HTML.replace("__WSPORT__", str(ws_port)).to_utf8_buffer())
	elif parts[0] == "GET" and path == "/favicon.ico":
		_respond(c, 204, "text/plain", PackedByteArray())
	elif parts[0] == "POST" and path == "/upload":
		_start_upload(c, headers, query, rest)
	else:
		_respond(c, 404, "text/plain", "Not found".to_utf8_buffer())


func _parse_query(q: String) -> Dictionary:
	var out := {}
	for pair in q.split("&", false):
		var kv := pair.split("=", true, 1)
		out[kv[0].uri_decode()] = kv[1].uri_decode() if kv.size() > 1 else ""
	return out


func _start_upload(c: HttpConn, headers: Dictionary, query: Dictionary, rest: PackedByteArray) -> void:
	if str(query.get("t", "")).to_upper() != token:
		_respond(c, 403, "text/plain", "Bad code".to_utf8_buffer())
		return
	var nm := str(query.get("name", "")).get_file().replace(" ", "_")
	var clean := ""
	for ch in nm:
		if ch.is_valid_identifier() or ch == "." or ch == "-" or ch.unicode_at(0) > 47 and ch.unicode_at(0) < 58:
			clean += ch
	nm = clean
	var ext := nm.get_extension().to_lower()
	if nm == "" or not (ext in CarImporter.MODEL_EXT or ext in CarImporter.AUX_EXT):
		_respond(c, 415, "text/plain", "Unsupported file type".to_utf8_buffer())
		return
	var length := int(headers.get("content-length", "0"))
	if length <= 0 or length > CarImporter.MAX_BYTES:
		_respond(c, 413, "text/plain", "File too large or empty".to_utf8_buffer())
		return
	DirAccess.make_dir_recursive_absolute(UPLOAD_DIR)
	c.file = FileAccess.open(UPLOAD_DIR + "/" + nm, FileAccess.WRITE)
	if c.file == null:
		_respond(c, 500, "text/plain", "Cannot write".to_utf8_buffer())
		return
	c.body_left = length
	last_message = "Receiving %s from phone..." % nm
	changed.emit()
	_upload_chunk(c, rest)


func _upload_chunk(c: HttpConn, data: PackedByteArray) -> void:
	if c.file == null:
		return
	var n := mini(data.size(), c.body_left)
	if n > 0:
		c.file.store_buffer(data.slice(0, n))
		c.body_left -= n
	c.born = _now()
	if c.body_left <= 0:
		c.file.close()
		c.file = null
		last_message = "File received from phone (use IMPORT CUSTOM CAR > APP FOLDER FILE)"
		changed.emit()
		_respond(c, 200, "text/plain", "OK".to_utf8_buffer())


func _respond(c: HttpConn, code: int, ctype: String, body: PackedByteArray) -> void:
	var hdr := "HTTP/1.1 %d %s\r\nContent-Type: %s\r\nContent-Length: %d\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n" \
			% [code, REASONS.get(code, "OK"), ctype, body.size()]
	c.stream.put_data(hdr.to_utf8_buffer())
	if body.size() > 0:
		c.stream.put_data(body)
	c.close_at = _now() + 0.5
