# HIGHWAY TV — Stage 4 + Car Prep

Godot 4.6 (GDScript, Compatibility renderer) driving simulator for Android TV 9+.

**Stage 2 adds:** an endless procedural highway with curves and hills, bridges (valley + deck + piers) and tunnels (mound + lit concrete tube),
7 environments (Indian highway, mountain, modern city, countryside, desert, forest, coastal), pooled segments with per-quality view distance,
and floating-origin rebase. **Stage 1:** one drivable car,
raycast-vehicle physics with engine/gearbox, ABS, traction control, aero, surface grip, 3 cameras, TV HUD,
pause menu, quality presets, and a GitHub Actions APK build.

## Build the APK on GitHub
1. Create a repo, push this folder (the workflow is in `.github/workflows/build-apk.yml`).
2. Open **Actions → Build Highway TV APK** (runs on push, or press *Run workflow*).
3. Download the `HighwayTV-apk` artifact → sideload `HighwayTV-debug.apk` (e.g. `adb install`).

The workflow installs Godot 4.3 + templates + Android SDK/NDK, installs the Gradle build template, patches the
manifest for Android TV (LEANBACK launcher + banner), and exports an arm64 debug APK (min SDK 28 = Android 9).

## Run locally
Open in Godot 4.6+, press F5.

## Controls
| Action | TV remote | Keyboard | Gamepad |
|---|---|---|---|
| Steer | D-pad L/R | ←/→ A/D | Left stick / D-pad |
| Accelerate | D-pad Up | ↑ W | RT / A |
| Brake / reverse | D-pad Down | ↓ S | LT / B |
| Handbrake | – | Space | X |
| Camera | OK | C | Y |
| Pause / quit | BACK (then BACK = quit, OK = resume) | P / Esc | Start |
| Gear up/down (manual) | – | E / Q | RB / LB |
| Auto/Manual | – | T | R-stick click |
| Reset car | – | R | Back |
| Quality preset | – | F1 | – |
| Environment | – | F2 | – |

## IMPORTANT — device compatibility
Godot 4 needs **OpenGL ES 3.0**. Some very low-end TVs (e.g. Mi TV 4A models with Mali-450 GPUs, GLES 2.0 only)
**cannot run Godot 4 at all**. If your target is such a TV, the engine choice must change (Godot 3.x GLES2).
Check with a GPU-info app before investing further.

## Tuning (not yet tested on a device!)
This code was written without a Godot runtime available, so physics feel is uncalibrated.
Start with `scripts/vehicle.gd` exports:
- Engine drive is now applied as real Newtons along the car's forward axis (not Godot's `engine_force`), capped by rear-tyre grip. The HUD shows your 0–100 km/h time; adjust `peak_torque`, ratios or `grip_rear`.
- `grip_front/grip_rear`, `susp_stiffness`, `damp_*`, `steer_speed_ref`, `brake_per_kg`.

## Roadmap
- Stage 2: curves/hills/bridges/tunnels, biomes · Stage 3: GLB importer (SAF file picker, wheel detection)
- Stage 4: Wi-Fi phone controller (hook already exists: `GameInput.set_remote()` / `clear_remote()`)
- Stage 5: traffic, weather, day/night · Stage 6: menus, perf screen, release signing

## Stage 2 notes / known limits
- Environment switching is F2 (keyboard) for now; the menu entry arrives in Stage 6. Switching keeps the road under the car and regenerates everything ahead.
- Tunnel interiors are lit by emissive strips only (no real lights yet); coastal has no water yet; roads have no banking.
- Road geometry/collision are built in GDScript per segment (trimesh). If hitches appear on weak TVs, lower quality (F1) or raise `SEG_LEN` cost tradeoffs in `world.gd`.
- Untested in the Godot editor — expect to fix small script errors on first run (check the Output panel).

## Stage 3: custom car importer
Menu -> **IMPORT CUSTOM CAR**. D-pad up/down = rows, left/right = change a value, OK = press, BACK = cancel.
- **Engine requirement:** the Android file picker (Storage Access Framework) only exists from **Godot 4.6**, so the project and CI now use 4.6
  (SDK 35, build-tools 35.0.1, NDK 28.1, JDK 17). Picked files come back as `content://` URIs; they are copied into `user://cars/<id>/`.
- **ZIP upload:** pick a single `.zip` containing the model and its textures (any folder layout). It is unpacked into the app, the best model inside is used
  (GLB, else GLTF, else OBJ; the largest if several), and texture/.bin/.mtl paths keep working. Also works from the phone upload and the app folder. Limit 192 MB unpacked.
- **Formats:** GLB (best, self-contained), GLTF (select the .gltf plus its .bin/textures together), OBJ (+ .mtl and textures).
  Limit 64 MB total; invalid/unsupported files give an on-screen error and nothing is saved.
- **Auto-detection:** up axis, length axis, scale (cars outside 2.5-8 m are scaled to 4.5 m), front/rear (part names like headlight/taillight, else roof position),
  four wheels (by mesh name, else by round/low shape), wheel radius, wheelbase, track, body bounds, mass estimate.
- **Manual fixes:** ROTATE / TILT / FLIP FRONT, per-wheel mesh pickers (selected mesh glows pink in the preview), then radius, wheelbase, track, mass,
  suspension (stiffness, damping, travel), steering angle, torque/power, redline, braking, gearbox (auto/manual), gear count, final drive.
- **Saved cars** appear in the menu under CAR (left/right); DELETE removes them.
- **If your TV has no document picker app** (common on Android TV): copy the model to
  `/storage/emulated/0/Android/data/com.highwaytv.game/files/` (adb push / USB) and use **APP FOLDER FILE**. Stage 4's phone page will add upload from the phone.
- Wheel meshes must be separate objects in the model to spin/steer. If the wheels are fused into the body, the car still drives but its wheels will not turn visually.
- Current drivetrain is rear-wheel drive for imported cars.

## Stage 4: phone controller (no app needed)
Menu -> **PHONE CONTROLLER** shows server status, TV IP, port, pairing code, QR code, connection status and the connected phone's name.
1. Phone and TV on the same Wi-Fi. Scan the QR code, the TV-hosted page opens in the phone browser (turn the phone to landscape).
2. Page: steering wheel, GAS and BRAKE pedals (slide up/down inside a pedal for partial pressure), handbrake, gear +/-, horn, camera, pause,
   a MENU pad (navigate TV menus), and SETTINGS (steering sensitivity, tilt steering, auto/manual gearbox, reset car, upload car files to the TV).
3. Network: HTTP on port 8080 (page + upload) and WebSocket on 8081 (controls, ~30 Hz); if busy it moves up in steps of 2. Local network only, no internet.
4. Security/robustness: random 6-character pairing code in the QR link (needed for the first WebSocket message and for uploads); only one phone at a time
   (a second phone gets "already connected"); the same phone reconnects automatically; if no data arrives for 1.5 s, or the socket closes,
   the TV neutralises steering/throttle/brake/handbrake immediately. NEW PAIRING CODE disconnects the current phone.
5. Car upload: Phone page -> SETTINGS -> choose .glb/.gltf/.obj (and companions). On the TV: IMPORT CUSTOM CAR -> row "APP / PHONE UPLOAD FILE".
- **Tilt steering caveat:** Chrome/Android only exposes motion sensors on secure (https) pages, and the TV serves plain http, so tilt often shows
  "No tilt data". The touch wheel always works. (Workaround for advanced users: enable Chrome flag `unsafely-treat-insecure-origin-as-secure` for the TV address.)
- The QR encoder (`qr_code.gd`, versions 1-6) was cross-checked by porting it to Python and decoding with OpenCV; the pairing URL needs version 2-3.

## CAR PREP (optimize + balance a car model on your phone)
The same APK also installs on a phone (arm64, Android 9+). Menu -> **CAR PREP**:
1. PICK MODEL: a `.zip` (or .glb/.gltf/.obj) downloaded from anywhere.
2. QUALITY: LOW (30k triangles, 512 px textures) / BALANCED (70k, 1024) / HIGH (140k, 2048, keeps normal maps). OPTIMIZE then:
   removes cameras/lights/hidden parts, reduces triangles (own vertex-clustering simplifier: Godot export builds have no mesh simplifier; wheels keep extra detail and stay
   separate meshes so they still spin), shrinks textures, bakes the correct orientation/scale, writes `model.glb` (WebP textures, PNG fallback) + `carprep.json`.
3. BALANCE HANDLING picks a preset from the model's size: COMPACT / SEDAN / SUV / SPORTS / TRUCK-VAN (mass, torque, redline, suspension, steering, brakes, gears, final drive, grip, drag).
4. SEND TO TV: type the TV address and pairing code shown on the TV's PHONE CONTROLLER screen (same Wi-Fi). On the TV: IMPORT CUSTOM CAR -> APP / PHONE UPLOAD FILE.
   The importer detects `carprep.json`, skips auto-orientation and applies the balanced values (you can still edit everything). SAVE A COPY writes the zip via the system save dialog.
Limits: clustering is crude (sharp edges soften; fine for TV, not for close-ups), textures are downsized but not GPU-compressed (not possible at runtime in export builds),
skinned/animated meshes are left unsimplified, extremely large models (>64 MB zip) are refused. Untested on real devices: check results visually on the TV.

## Camera (free view + sliders)
Camera button / OK cycles CHASE, CLOSE REAR, HOOD and **FREE VIEW 360**. The pause screen (BACK or Start) has sliders for **distance**, **angle** and **rotate 360**
(D-pad up/down selects, left/right adjusts, camera updates live), VIEW MODE and RESET CAMERA. The sliders apply to every mode (in HOOD they turn your head).
In FREE VIEW the gamepad right stick / keys J L I K orbit the car (U/O zoom). The phone page (SETTINGS) has the same three sliders and works while driving.
BACK now pauses/resumes; leave to the menu with the MAIN MENU button in the pause screen.

## Importer fixes + cockpit view (Wagon R report)
- Wheel detection now matches whole words only ("primary"/"trim" no longer count as "rim"), and rejects wide/tall/high parts (bumpers, panels, underbody).
  On the test model this fixed the sideways wheel offset (left side sinking) and body parts spinning with the wheels. **Re-import cars that were imported before.**
- The importer finds the steering wheel and places a **COCKPIT (driver)** camera behind it (left- or right-hand drive). Rows DRIVER SEAT SIDE / EYE HEIGHT / EYE FORWARD-BACK adjust it.
- Camera modes: CHASE, CLOSE REAR, HOOD, COCKPIT (driver), FREE VIEW 360. New **ZOOM** slider (field of view) and CAMERA DISTANCE now goes down to 0:
  in FREE VIEW, distance 0 puts the camera at the driver's seat so you can turn 360 degrees and look at the dashboard, seats and doors.

## Lights, horn, steering wheel, instruments, phone joystick
- **Headlights:** LIGHTS cycles OFF -> LOW BEAM -> HIGH BEAM -> LOW + HIGH (real spot lights + glowing lamp parts). Keys: N lights, V hazard, `,` left indicator,
  `.` right indicator, M cabin light, H horn. Gamepad: D-pad up lights, D-pad down hazard, left-stick click horn. Phone: LIGHTS tab.
- **Lamp glow on imported cars** is found by part name (headlight/headlamp/foglight, taillight/brakelight/breaklight, reverse, indicator + l/lf/lr/left or r/rf/rr/right).
  Brake lights follow braking, reverse lights follow reverse gear, indicators/hazards blink. Cars whose lamps are not separate named parts just won't glow (the spot lights still work).
- **Cabin light:** a warm interior light at the driver's position; toggle with M or the phone.
- **Horn:** hold H / the phone HORN button / left-stick click. The sound is a generated placeholder tone until real audio is supplied.
- **Steering sync:** the car's steering wheel mesh turns with the steering (about 14:1, found by name `steer*`, rotation axis from its shape). The built-in car has a simple wheel.
- **Instruments:** pause screen -> INSTRUMENTS (or F3, or phone SETTINGS) cycles STANDARD GAUGE / INSTRUMENT CLUSTER (speedometer + tachometer dials, gear, indicator,
  beam and brake lamps, bottom centre of the screen) / OFF. A model's own painted dashboard gauges cannot move (they are just textures); the cluster overlay replaces them.
- **Phone controller:** tabs DRIVE / VIEW / LIGHTS. VIEW has a **joystick** for the 360 degree camera (left/right orbits, up/down tilts), a **ZOOM** slider and a DISTANCE slider.

## Two players, no pairing code, importer upgrades
- **No pairing code.** Open the address shown on the TV's PHONE CONTROLLER screen (or scan the QR code). Anyone on the same Wi-Fi can connect, so use a network you trust.
  Car uploads from a phone are only accepted while a controller is connected or the PHONE CONTROLLER screen is open on the TV.
- **Two phones max.** Phone 1 drives your car. Phone 2 spawns its own (blue, tagged "P2") car beside yours on the same screen; the camera follows player 1.
  Each phone picks its car in its SETTINGS ("My car"; saved cars from the garage). A third phone is told two are connected.
  If a phone disconnects/times out its controls neutralise at once; phone 2's car is removed. If car 2 is more than 150 m from car 1 it is brought back next to it.
  Player 2 has its own lights, horn, hazards, gears and reset; the camera sliders/joystick/instrument cluster belong to player 1.
- **Importer:** PREVIEW ROTATION on/off; each wheel can have several parts (tire, rim, caliper...): pick a part with < >, press OK, then use the "+" button beside it to add
  another part to the same wheel ("x" removes one); parts are listed nearest-first. DRIVER SEAT SIDE = AUTO / LEFT / RIGHT. CAR NAME field (shown in the garage/phone list).

## Game modes (start page: MODE)
- **1 PLAYER:** one controller only (TV controls or one phone). The game works as before; saving an imported car starts the game.
- **2 PLAYERS (race):** two controllers (first phone = P1, second = P2). Pick **CAR PLAYER 1** and **CAR PLAYER 2** from the saved cars (built-in coupe included) in the menu;
  IMPORT CUSTOM CAR only saves the car in this mode. DRIVE NOW puts P1 in lane 1 (left) and P2 in lane 3 (right) with a 3-2-1 countdown.
  The camera sits on the road centre line (lane 2) behind the pair and backs off/rises as the gap grows so both cars stay in view.
  Only CHASE and CLOSE REAR are available and only DISTANCE, ZOOM and HEIGHT can be adjusted (pause screen, or the phone sliders). Each car's speed/RPM gauge is on its own side of the screen
  (P1 left, P2 right). If one car gets more than **6 street lights (6 x 30 m = 180 m)** ahead of the other, it is declared the winner; REMATCH or MAIN MENU follow.

## Terrain & scenery from the supplied model packs
- `assets/props/forest.glb`, `mountain.glb`, `desert.glb` (1.3 MB total, 58 props, 20-850 triangles each) were cut out of the packs you supplied by `tools/build_props.py`
  (needs the original zips; not needed to run the game). Each prop was re-based to bottom-centre, scaled to real-world size and given only the textures it needs (shrunk to 512 px).
  Pines, rocks, bushes, logs (forest/nature packs); cliffs, hills, mountains and rock spires (modular terrain + environment packs); saguaro/prickly-pear cacti, desert rocks,
  mesas, palms, adobe house, red-dirt hills (desert packs).
- Biomes now use them (`BIOME_PROPS` in `world.gd`): FOREST (pine forest, boulders, bushes, logs, far green hills), MOUNTAIN HIGHWAY (pines, cliffs, rock spires, big mountains),
  DESERT (mesas, boulders, saguaro and prickly-pear cacti, dry grass, skull, far buttes), COUNTRYSIDE, INDIAN HIGHWAY and COASTAL (palms, rocks, houses, hills) and a new **RED CANYON**.
- Prop amounts follow the quality setting (LOW 50 % ... ULTRA 130 %); props do not cast shadows (TV performance). SCRIPT CHECK shows how many props loaded.
- Packs not used yet: road, bridge, fence, farm, city-items, retro, pond, Vietnam and desert-city/house packs (several are huge dioramas or scaled for other engines).
