class_name RoadWorld
extends Node3D
## Stage 2: endless procedural highway.
## - Centre-line is integrated from a deterministic curvature function (curves)
##   and an elevation function (hills). Segment start states are cached so any
##   segment can be rebuilt identically.
## - Every 4 segments (240 m) form a "block": normal, BRIDGE (valley + deck + piers)
##   or TUNNEL (hill mound + concrete tube + lights).
## - Segments are pooled: generated ahead of the car, recycled behind it.
## - Floating-origin rebase keeps coordinates small on endless drives.
## - 7 biomes re-colour materials and change decor/curvature/hilliness.

const SEG_LEN := 60.0
const LIGHT_SPACING := 30.0     # street lights stand every 30 m
const DS := 5.0
const SLICES := 12
const ROAD_HALF := 7.0
const BLOCK_SEGS := 4
const BLOCK_LEN := 240.0
const REBASE_LIMIT := 3000.0
const SEGS_BEHIND := 3
const MAX_TREES := 24
const MAX_BUILD := 10

const BIOMES := [
	{"name": "INDIAN HIGHWAY", "ground": Color(0.45, 0.47, 0.24), "crown": Color(0.2, 0.4, 0.12),
	 "trunk": Color(0.33, 0.23, 0.14), "hills": Color(0.5, 0.55, 0.42),
	 "sky_top": Color(0.35, 0.55, 0.85), "sky_hor": Color(0.85, 0.82, 0.7), "fog": Color(0.8, 0.78, 0.68),
	 "fog_d": 0.0020, "trees": 0.7, "tree_s": 1.1, "build": 3, "b_h": Vector2(4, 9),
	 "curve": 0.8, "elev": 0.5, "hill": 0.6},
	{"name": "MOUNTAIN HIGHWAY", "ground": Color(0.34, 0.4, 0.3), "crown": Color(0.08, 0.24, 0.14),
	 "trunk": Color(0.25, 0.18, 0.12), "hills": Color(0.45, 0.47, 0.5),
	 "sky_top": Color(0.2, 0.4, 0.8), "sky_hor": Color(0.72, 0.82, 0.92), "fog": Color(0.72, 0.8, 0.9),
	 "fog_d": 0.0013, "trees": 0.6, "tree_s": 1.4, "build": 0, "b_h": Vector2(4, 8),
	 "curve": 2.0, "elev": 1.6, "hill": 1.8},
	{"name": "MODERN CITY", "ground": Color(0.32, 0.33, 0.34), "crown": Color(0.2, 0.35, 0.18),
	 "trunk": Color(0.3, 0.22, 0.15), "hills": Color(0.5, 0.55, 0.62),
	 "sky_top": Color(0.3, 0.5, 0.8), "sky_hor": Color(0.75, 0.82, 0.9), "fog": Color(0.7, 0.76, 0.84),
	 "fog_d": 0.0015, "trees": 0.15, "tree_s": 0.8, "build": 10, "b_h": Vector2(20, 70),
	 "curve": 0.5, "elev": 0.3, "hill": 0.4},
	{"name": "COUNTRYSIDE", "ground": Color(0.3, 0.52, 0.2), "crown": Color(0.18, 0.45, 0.15),
	 "trunk": Color(0.33, 0.23, 0.14), "hills": Color(0.4, 0.55, 0.35),
	 "sky_top": Color(0.25, 0.45, 0.8), "sky_hor": Color(0.7, 0.8, 0.9), "fog": Color(0.72, 0.8, 0.9),
	 "fog_d": 0.0011, "trees": 0.5, "tree_s": 1.0, "build": 2, "b_h": Vector2(5, 8),
	 "curve": 1.0, "elev": 0.8, "hill": 0.7},
	{"name": "DESERT", "ground": Color(0.8, 0.67, 0.44), "crown": Color(0.45, 0.45, 0.2),
	 "trunk": Color(0.4, 0.3, 0.2), "hills": Color(0.75, 0.52, 0.33),
	 "sky_top": Color(0.4, 0.6, 0.88), "sky_hor": Color(0.92, 0.82, 0.66), "fog": Color(0.88, 0.78, 0.62),
	 "fog_d": 0.0014, "trees": 0.12, "tree_s": 0.55, "build": 0, "b_h": Vector2(4, 8),
	 "curve": 0.6, "elev": 0.7, "hill": 0.5},
	{"name": "FOREST", "ground": Color(0.14, 0.28, 0.12), "crown": Color(0.07, 0.24, 0.1),
	 "trunk": Color(0.2, 0.14, 0.1), "hills": Color(0.2, 0.32, 0.25),
	 "sky_top": Color(0.3, 0.5, 0.75), "sky_hor": Color(0.7, 0.78, 0.78), "fog": Color(0.6, 0.7, 0.65),
	 "fog_d": 0.0024, "trees": 1.0, "tree_s": 1.3, "build": 0, "b_h": Vector2(4, 8),
	 "curve": 1.4, "elev": 1.0, "hill": 0.8},
	{"name": "COASTAL", "ground": Color(0.84, 0.78, 0.58), "crown": Color(0.25, 0.5, 0.2),
	 "trunk": Color(0.4, 0.3, 0.2), "hills": Color(0.45, 0.6, 0.6),
	 "sky_top": Color(0.2, 0.55, 0.9), "sky_hor": Color(0.8, 0.9, 0.95), "fog": Color(0.78, 0.88, 0.94),
	 "fog_d": 0.0014, "trees": 0.25, "tree_s": 1.0, "build": 3, "b_h": Vector2(6, 14),
	 "curve": 1.2, "elev": 0.6, "hill": 0.7},
	{"name": "RED CANYON", "ground": Color(0.62, 0.34, 0.2), "crown": Color(0.35, 0.4, 0.15),
	 "trunk": Color(0.4, 0.3, 0.2), "hills": Color(0.7, 0.35, 0.2),
	 "sky_top": Color(0.35, 0.55, 0.85), "sky_hor": Color(0.93, 0.8, 0.68), "fog": Color(0.9, 0.75, 0.62),
	 "fog_d": 0.0014, "trees": 0.0, "tree_s": 1.0, "build": 0, "b_h": Vector2(4, 8),
	 "curve": 1.0, "elev": 1.2, "hill": 0.5},
]

## Modelled scenery per biome (from the prop kits): [prop, count per 60 m, lateral min, lateral max,
## scale min, scale max, sink (fraction of height buried)]. Lateral = metres from the road centre.
const BIOME_PROPS := {
	"INDIAN HIGHWAY": [["palm_a", 3, 12, 60, 0.8, 1.2, 0.0], ["palm_b", 3, 12, 60, 0.8, 1.2, 0.0],
		["adobe", 1, 20, 50, 0.9, 1.3, 0.0], ["hill_b", 1, 150, 320, 5, 9, 0.08]],
	"MOUNTAIN HIGHWAY": [["pine_s", 5, 12, 90, 0.9, 1.4, 0.0], ["pine_m", 4, 12, 90, 0.9, 1.3, 0.0],
		["pine_n1", 3, 14, 100, 0.9, 1.3, 0.0], ["rock_tall_b", 2, 20, 90, 0.7, 1.5, 0.0],
		["rock_b", 3, 11, 50, 1.0, 2.5, 0.0], ["cliff_a", 2, 45, 130, 2.0, 4.0, 0.05],
		["cliff_c", 2, 60, 160, 2.5, 5.0, 0.05], ["peak_b", 2, 70, 200, 1.5, 3.5, 0.0],
		["peak_c", 2, 90, 220, 1.5, 3.5, 0.0], ["mount_a", 1, 160, 320, 7, 12, 0.05]],
	"COUNTRYSIDE": [["pine_n1", 3, 14, 80, 0.9, 1.3, 0.0], ["pine_n2", 3, 14, 80, 0.9, 1.3, 0.0],
		["bush_berry", 4, 11, 45, 0.8, 1.5, 0.0], ["rock_a", 2, 11, 40, 1.0, 2.0, 0.0],
		["hill_b", 2, 110, 300, 4, 8, 0.08], ["hill_c", 1, 140, 320, 5, 9, 0.08]],
	"DESERT": [["d_rock_a", 3, 11, 70, 0.9, 1.8, 0.0], ["d_rock_b", 2, 14, 80, 0.8, 1.6, 0.0],
		["mesa_a", 2, 40, 150, 1.5, 3.0, 0.02], ["mesa_c", 2, 60, 200, 1.5, 3.2, 0.02],
		["cactus_a", 3, 11, 60, 0.8, 1.3, 0.0], ["cactus_b", 3, 11, 60, 0.8, 1.3, 0.0],
		["pear_a", 3, 11, 40, 0.9, 1.4, 0.0], ["dgrass_a", 5, 11, 35, 0.9, 1.4, 0.0],
		["skull", 1, 12, 40, 1.0, 1.3, 0.0], ["mesa_b", 2, 120, 300, 3, 6, 0.02]],
	"FOREST": [["pine_s", 7, 12, 90, 0.9, 1.4, 0.0], ["pine_m", 7, 12, 90, 0.9, 1.3, 0.0],
		["pine_l", 5, 12, 100, 0.9, 1.3, 0.0], ["pine_n1", 5, 12, 80, 0.9, 1.3, 0.0],
		["pine_n2", 4, 12, 80, 0.9, 1.3, 0.0], ["rock_a", 3, 11, 50, 1.0, 2.2, 0.0],
		["bush_berry", 5, 11, 40, 0.8, 1.6, 0.0], ["log", 2, 11, 40, 0.9, 1.4, 0.0],
		["rock_tall_a", 2, 25, 90, 0.8, 1.4, 0.0], ["hill_a", 2, 130, 320, 5, 9, 0.08]],
	"COASTAL": [["palm_a", 4, 11, 70, 0.8, 1.2, 0.0], ["palm_b", 4, 11, 70, 0.8, 1.2, 0.0],
		["d_rock_d", 2, 15, 80, 0.8, 1.6, 0.0], ["pear_a", 2, 11, 35, 0.8, 1.2, 0.0]],
	"RED CANYON": [["red_hill_a", 2, 70, 260, 1.3, 2.4, 0.05], ["red_hill_b", 2, 90, 300, 1.3, 2.4, 0.05],
		["red_hill_c", 2, 70, 260, 1.3, 2.4, 0.05], ["mesa_a", 2, 35, 130, 2.2, 3.8, 0.02],
		["mesa_c", 2, 50, 170, 2.2, 4.0, 0.02], ["cactus_r1", 3, 11, 50, 0.9, 1.4, 0.0],
		["cactus_r2", 3, 11, 50, 0.9, 1.4, 0.0], ["cactus_cluster", 2, 11, 45, 0.9, 1.4, 0.0],
		["dbush", 4, 11, 40, 0.8, 1.5, 0.0], ["d_rock_c", 2, 14, 80, 0.9, 1.7, 0.0]],
}
## kit_only: the old primitive trees are switched off; cones: the distant cone hills stay.
const BIOME_FLAGS := {
	"INDIAN HIGHWAY": {"kit_only": false, "cones": false},
	"MOUNTAIN HIGHWAY": {"kit_only": true, "cones": false},
	"COUNTRYSIDE": {"kit_only": false, "cones": false},
	"DESERT": {"kit_only": true, "cones": false},
	"FOREST": {"kit_only": true, "cones": false},
	"RED CANYON": {"kit_only": true, "cones": false},
}
const MAX_PROP := 12

var tree_count := 16
var _prop_density := 1.0
var view_segments := 9
var biome_index := 0
var biome: Dictionary = BIOMES[0]

var _segments: Dictionary = {}
var _starts: Dictionary = {}
var _pool: Array[Segment] = []
var _last_idx := -99999
var _last_idx2 := -99999
var _cur_idx := 0
var _elev_scale := 0.5
var _elev_off := 0.0
var _curve_scale := 0.8
var _rng := RandomNumberGenerator.new()
var _brng := RandomNumberGenerator.new()
var _hills: Array[MeshInstance3D] = []
var _far: MeshInstance3D

var _road_mat: StandardMaterial3D
var _terrain_mat: StandardMaterial3D
var _far_mat: StandardMaterial3D
var _concrete_mat: StandardMaterial3D
var _rail_mat: StandardMaterial3D
var _post_mat: StandardMaterial3D
var _trunk_mat: StandardMaterial3D
var _crown_mat: StandardMaterial3D
var _pole_mat: StandardMaterial3D
var _lamp_mat: StandardMaterial3D
var _tlight_mat: StandardMaterial3D
var _build_mat: StandardMaterial3D
var _hill_mat: StandardMaterial3D
var _trunk_mesh: CylinderMesh
var _crown_mesh: SphereMesh
var _post_mesh: BoxMesh
var _pole_mesh: BoxMesh
var _arm_mesh: BoxMesh
var _lamp_mesh: BoxMesh
var _unit_box: BoxMesh
var _pier_mesh: BoxMesh


# ------------------------------------------------------------------ helpers
class MeshBuf:
	var v := PackedVector3Array()
	var n := PackedVector3Array()
	var uv := PackedVector2Array()
	var idx := PackedInt32Array()

	## Adds a quad a-b-c-d whose front face points along `hint`.
	## (Godot front faces are clockwise.)
	func quad(a: Vector3, b: Vector3, c: Vector3, d: Vector3, hint: Vector3,
			ua := Vector2.ZERO, ub := Vector2.ZERO, uc := Vector2.ZERO, ud := Vector2.ZERO) -> void:
		var g := (b - a).cross(c - a)
		var base := v.size()
		var h := hint.normalized()
		v.append(a); v.append(b); v.append(c); v.append(d)
		n.append(h); n.append(h); n.append(h); n.append(h)
		uv.append(ua); uv.append(ub); uv.append(uc); uv.append(ud)
		if g.dot(h) > 0.0:
			idx.append_array(PackedInt32Array([base, base + 2, base + 1, base, base + 3, base + 2]))
		else:
			idx.append_array(PackedInt32Array([base, base + 1, base + 2, base, base + 2, base + 3]))

	func is_empty() -> bool:
		return v.is_empty()

	func faces() -> PackedVector3Array:
		var f := PackedVector3Array()
		for i in idx:
			f.append(v[i])
		return f


class Segment extends Node3D:
	var mi: MeshInstance3D
	var road_cs: CollisionShape3D
	var terr_cs: CollisionShape3D
	var struct_cs: CollisionShape3D
	var rail_cs: Array[CollisionShape3D] = []
	var posts: MultiMeshInstance3D
	var poles: MultiMeshInstance3D
	var arms: MultiMeshInstance3D
	var lamps: MultiMeshInstance3D
	var trunks: MultiMeshInstance3D
	var crowns: MultiMeshInstance3D
	var builds: MultiMeshInstance3D
	var piers: MultiMeshInstance3D
	var local_mid := Vector3.ZERO
	var prop_mmis: Array[MultiMeshInstance3D] = []
	var prop_n: Array[int] = []
	var pts := PackedVector3Array()
	var yws := PackedFloat32Array()
	var btype := 0
	var n_pole := 0
	var n_pier := 0
	var n_tree := 0
	var n_build := 0


func _ready() -> void:
	_starts[-2] = {"x": 0.0, "z": 120.0, "yaw": 0.0}
	_build_resources()
	_build_hills()
	set_biome(0)


# ---------------------------------------------------------- path functions
func _base_elev(s: float) -> float:
	var h := 18.0 * sin(s / 700.0) + 8.0 * sin(s / 230.0 + 1.3) + 3.0 * sin(s / 90.0 + 0.4)
	h -= 8.0 * sin(1.3) + 3.0 * sin(0.4)
	return h * smoothstep(0.0, 200.0, s)


func _elev(s: float) -> float:
	if s <= 0.0:
		return 0.0
	return _base_elev(s) * _elev_scale + _elev_off


func _kappa(s: float) -> float:
	if s <= 0.0:
		return 0.0
	var k := 0.0006 * sin(s / 1100.0 + 0.7) + 0.0006 * sin(s / 430.0 + 2.1) + 0.0003 * sin(s / 170.0 + 4.0)
	return k * _curve_scale * smoothstep(0.0, 150.0, s)


func _compute_path(i: int) -> Dictionary:
	var st: Dictionary = _starts[i]
	var x: float = st["x"]
	var z: float = st["z"]
	var yaw: float = st["yaw"]
	var pts := PackedVector3Array()
	var yws := PackedFloat32Array()
	var s0 := float(i) * SEG_LEN
	pts.append(Vector3(x, _elev(s0), z))
	yws.append(yaw)
	for j in SLICES:
		var k := _kappa(s0 + (j + 0.5) * DS)
		var ym := yaw + 0.5 * k * DS
		x += -sin(ym) * DS
		z += -cos(ym) * DS
		yaw += k * DS
		pts.append(Vector3(x, _elev(s0 + (j + 1) * DS), z))
		yws.append(yaw)
	if not _starts.has(i + 1):
		_starts[i + 1] = {"x": x, "z": z, "yaw": yaw}
	return {"p": pts, "yaw": yws}


func _get_path(i: int) -> Dictionary:
	if not _starts.has(i):
		var k := i - 1
		while not _starts.has(k):
			k -= 1
		while k < i:
			_compute_path(k)
			k += 1
	return _compute_path(i)


func _block_type(i: int) -> int:
	var b := floori(float(i) / BLOCK_SEGS)
	if b < 1:
		return 0
	_brng.seed = b * 9973 + 101
	var v := _brng.randf()
	if v < 0.16:
		return 1
	if v < 0.32:
		return 2
	return 0


func _feat(btype: int, sl: float) -> Vector2:
	if btype == 0:
		return Vector2.ZERO
	var e := smoothstep(0.0, 40.0, sl) * smoothstep(0.0, 40.0, BLOCK_LEN - sl)
	if btype == 1:
		return Vector2(14.0 * e, 0.0)
	return Vector2(0.0, e)


# ------------------------------------------------------------- public API
func _nearest_idx(pos: Vector3, fallback: int) -> int:
	var idx := fallback
	var best := INF
	for k in _segments.keys():
		var s: Segment = _segments[k]
		var d := (s.position + s.local_mid - pos).length_squared()
		if d < best:
			best = d
			idx = k
	return idx


## Keeps the road built around the first car (and the second one, if any).
func update_for(pos: Vector3, pos2 := Vector3.INF) -> void:
	_far.position = Vector3(pos.x, pos.y - 38.0, pos.z)
	for h in _hills:
		var half: float = float(h.get_meta("half")) * h.scale.y
		h.position = Vector3(pos.x + float(h.get_meta("ox")), pos.y - 40.0 + half, pos.z + float(h.get_meta("oz")))
	var idx := 0
	var idx2 := 0
	if not _segments.is_empty():
		idx = _nearest_idx(pos, 0)
		idx2 = idx if pos2.x == INF else _nearest_idx(pos2, idx)
	else:
		idx2 = idx
	_cur_idx = idx
	if idx == _last_idx and idx2 == _last_idx2:
		return
	_last_idx = idx
	_last_idx2 = idx2
	var lo := maxi(mini(idx, idx2) - SEGS_BEHIND, -2)
	var hi := maxi(idx, idx2) + view_segments
	for k in _segments.keys():
		if k < lo or k > hi:
			_retire(k)
	for i in range(lo, hi + 1):
		if not _segments.has(i):
			var seg: Segment = _pool.pop_back() if _pool.size() > 0 else _make_segment()
			_place(seg, i)
			_segments[i] = seg


## Nearest point on the road centre-line (= lane 2) to a world position:
## {center, yaw, s} where s is the distance along the road in metres.
func road_frame(pos: Vector3) -> Dictionary:
	var best := INF
	var out := {"center": pos, "yaw": 0.0, "s": 0.0}
	for k in _segments.keys():
		var sg: Segment = _segments[k]
		for j in SLICES:
			var a := sg.position + sg.pts[j]
			var b := sg.position + sg.pts[j + 1]
			var ab := b - a
			var l2 := ab.x * ab.x + ab.z * ab.z
			if l2 < 0.0001:
				continue
			var t := clampf(((pos.x - a.x) * ab.x + (pos.z - a.z) * ab.z) / l2, 0.0, 1.0)
			var c := a + ab * t
			var d := (pos.x - c.x) * (pos.x - c.x) + (pos.z - c.z) * (pos.z - c.z)
			if d < best:
				best = d
				out["center"] = c
				out["yaw"] = lerp_angle(sg.yws[j], sg.yws[j + 1], t)
				out["s"] = float(k) * SEG_LEN + (j + t) * DS
	return out


## Returns the offset applied (ZERO if none). Caller must add it to the car.
func rebase_if_needed(pos: Vector3) -> Vector3:
	if absf(pos.x) < REBASE_LIMIT and absf(pos.z) < REBASE_LIMIT:
		return Vector3.ZERO
	var off := -Vector3(snappedf(pos.x, 500.0), 0.0, snappedf(pos.z, 500.0))
	for s in _segments.values():
		s.position += off
	for k in _starts.keys():
		var st: Dictionary = _starts[k]
		st["x"] = float(st["x"]) + off.x
		st["z"] = float(st["z"]) + off.z
	return off


func set_biome(b: int) -> void:
	biome_index = wrapi(b, 0, BIOMES.size())
	var nb: Dictionary = BIOMES[biome_index]
	if _segments.is_empty():
		biome = nb
		_elev_scale = float(nb["elev"])
		_curve_scale = float(nb["curve"])
		_elev_off = 0.0
		_apply_biome_materials()
		return
	# Keep geometry up to the current segment; regenerate everything ahead.
	var idx := _cur_idx
	var sb := float(idx + 1) * SEG_LEN
	var old_y := _elev(sb)
	biome = nb
	_elev_scale = float(nb["elev"])
	_curve_scale = float(nb["curve"])
	_elev_off = old_y - _base_elev(sb) * _elev_scale
	for k in _starts.keys():
		if k > idx + 1:
			_starts.erase(k)
	for k in _segments.keys():
		if k > idx:
			_retire(k)
	_apply_biome_materials()
	_last_idx = -99999


func set_tree_count(n: int) -> void:
	tree_count = clampi(n, 0, MAX_TREES)
	for s in _segments.values():
		_apply_counts(s)


func set_view_segments(n: int) -> void:
	view_segments = clampi(n, 5, 16)
	_last_idx = -99999


func _retire(k: int) -> void:
	var s: Segment = _segments[k]
	_segments.erase(k)
	s.visible = false
	s.road_cs.disabled = true
	s.terr_cs.disabled = true
	s.struct_cs.disabled = true
	for c in s.rail_cs:
		c.disabled = true
	_pool.append(s)


func _biome_flag(key: String, default: bool) -> bool:
	return bool((BIOME_FLAGS.get(str(biome["name"]), {}) as Dictionary).get(key, default))


func set_prop_density(f: float) -> void:
	_prop_density = f
	for s in _segments.values():
		_apply_counts(s)


func _apply_counts(s: Segment) -> void:
	var normal := s.btype == 0
	var kit_only := _biome_flag("kit_only", false)
	var t := int(tree_count * float(biome["trees"])) if (normal and not kit_only) else 0
	for k in s.prop_mmis.size():
		var cnt := 0
		if normal and k < s.prop_n.size():
			cnt = int(ceil(s.prop_n[k] * _prop_density))
		s.prop_mmis[k].multimesh.visible_instance_count = mini(cnt, MAX_PROP)
	s.trunks.multimesh.visible_instance_count = t
	s.crowns.multimesh.visible_instance_count = t
	s.builds.multimesh.visible_instance_count = mini(int(biome["build"]), MAX_BUILD) if (normal and not kit_only) else 0
	s.poles.multimesh.visible_instance_count = 4 if s.btype != 2 else 0
	s.arms.multimesh.visible_instance_count = 4 if s.btype != 2 else 0
	s.lamps.multimesh.visible_instance_count = 4 if s.btype != 2 else 0
	s.piers.multimesh.visible_instance_count = s.n_pier


func _apply_biome_materials() -> void:
	var g: Color = biome["ground"]
	_terrain_mat.albedo_color = g
	_far_mat.albedo_color = g * 0.92
	_crown_mat.albedo_color = biome["crown"]
	_trunk_mat.albedo_color = biome["trunk"]
	_hill_mat.albedo_color = biome["hills"]
	var cones := _biome_flag("cones", true)
	for h in _hills:
		h.scale.y = float(biome["hill"])
		h.visible = cones
	for s in _segments.values():
		_apply_counts(s)


# --------------------------------------------------------------- resources
func _std(color: Color, rough := 0.9) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	return m


func _noise_tex(lo: float, hi: float) -> ImageTexture:
	var img := Image.create(64, 64, false, Image.FORMAT_RGB8)
	var r := RandomNumberGenerator.new()
	r.seed = 99
	for y in 64:
		for x in 64:
			var v := r.randf_range(lo, hi)
			img.set_pixel(x, y, Color(v, v, v))
	img.generate_mipmaps()
	return ImageTexture.create_from_image(img)


func _build_resources() -> void:
	_road_mat = _std(Color.WHITE, 0.85)
	_road_mat.albedo_texture = _make_road_texture()
	_road_mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
	_terrain_mat = _std(Color(0.3, 0.5, 0.2), 1.0)
	_terrain_mat.albedo_texture = _noise_tex(0.75, 1.0)
	_terrain_mat.uv1_triplanar = true
	_terrain_mat.uv1_world_triplanar = true
	_terrain_mat.uv1_scale = Vector3(0.12, 0.12, 0.12)
	_far_mat = _std(Color(0.28, 0.46, 0.18), 1.0)
	_concrete_mat = _std(Color(0.55, 0.55, 0.56), 0.95)
	_rail_mat = _std(Color(0.7, 0.72, 0.75), 0.4)
	_rail_mat.metallic = 0.6
	_post_mat = _std(Color(0.35, 0.35, 0.37))
	_trunk_mat = _std(Color(0.32, 0.22, 0.14))
	_crown_mat = _std(Color(0.16, 0.34, 0.14))
	_pole_mat = _std(Color(0.3, 0.32, 0.35), 0.5)
	_lamp_mat = _std(Color(1, 0.95, 0.8))
	_lamp_mat.emission_enabled = true
	_lamp_mat.emission = Color(1, 0.9, 0.65)
	_lamp_mat.emission_energy_multiplier = 2.0
	_tlight_mat = _std(Color(1, 1, 0.9))
	_tlight_mat.emission_enabled = true
	_tlight_mat.emission = Color(1, 0.95, 0.8)
	_tlight_mat.emission_energy_multiplier = 3.0
	_build_mat = _std(Color(1, 1, 1), 0.6)
	_build_mat.vertex_color_use_as_albedo = true
	_hill_mat = _std(Color(0.4, 0.5, 0.4), 1.0)

	_trunk_mesh = CylinderMesh.new()
	_trunk_mesh.top_radius = 0.15
	_trunk_mesh.bottom_radius = 0.25
	_trunk_mesh.height = 3.0
	_trunk_mesh.radial_segments = 6
	_crown_mesh = SphereMesh.new()
	_crown_mesh.radius = 1.7
	_crown_mesh.height = 3.4
	_crown_mesh.radial_segments = 8
	_crown_mesh.rings = 4
	_post_mesh = BoxMesh.new()
	_post_mesh.size = Vector3(0.12, 0.8, 0.12)
	_pole_mesh = BoxMesh.new()
	_pole_mesh.size = Vector3(0.18, 7.5, 0.18)
	_arm_mesh = BoxMesh.new()
	_arm_mesh.size = Vector3(2.0, 0.12, 0.12)
	_lamp_mesh = BoxMesh.new()
	_lamp_mesh.size = Vector3(0.7, 0.12, 0.35)
	_unit_box = BoxMesh.new()
	_unit_box.size = Vector3(1, 1, 1)
	_pier_mesh = BoxMesh.new()
	_pier_mesh.size = Vector3(6.0, 1.0, 1.2)

	_far = MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(8000, 8000)
	_far.mesh = pm
	_far.material_override = _far_mat
	_far.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_far)


func _make_road_texture() -> ImageTexture:
	var W := 128
	var H := 512
	var img := Image.create(W, H, false, Image.FORMAT_RGB8)
	img.fill(Color(0.17, 0.17, 0.18))
	var rng := RandomNumberGenerator.new()
	rng.seed = 1234
	for i in 5000:
		var g := rng.randf_range(0.10, 0.26)
		img.set_pixel(rng.randi_range(0, W - 1), rng.randi_range(0, H - 1), Color(g, g, g * 1.03))
	var pxm := float(W) / (ROAD_HALF * 2.0)
	var white := Color(0.92, 0.92, 0.9)
	for x: float in [-5.25, 5.25]:
		img.fill_rect(Rect2i(int((x + ROAD_HALF) * pxm) - 1, 0, 2, H), white)
	for x: float in [-1.75, 1.75]:       # dashes: 5 m on / 7 m off, period 12 m, texture = 120 m
		for k in 10:
			img.fill_rect(Rect2i(int((x + ROAD_HALF) * pxm) - 1, int(k * H / 10.0), 2, 21), white)
	img.generate_mipmaps()
	return ImageTexture.create_from_image(img)


func _mmi(mesh: Mesh, count: int, colors := false) -> MultiMeshInstance3D:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = colors
	mm.mesh = mesh
	mm.instance_count = count
	mm.custom_aabb = AABB(Vector3(-250, -80, -250), Vector3(500, 200, 500))
	var mi := MultiMeshInstance3D.new()
	mi.multimesh = mm
	mi.visibility_range_end = 450.0
	return mi


func _static_body(grip: float) -> StaticBody3D:
	var b := StaticBody3D.new()
	b.set_meta("grip", grip)
	return b


func _make_segment() -> Segment:
	var s := Segment.new()
	s.mi = MeshInstance3D.new()
	s.add_child(s.mi)

	var rb := _static_body(1.0)
	s.road_cs = CollisionShape3D.new()
	rb.add_child(s.road_cs)
	s.add_child(rb)
	var tb := _static_body(0.55)
	s.terr_cs = CollisionShape3D.new()
	tb.add_child(s.terr_cs)
	s.add_child(tb)
	var sb := _static_body(0.3)
	s.struct_cs = CollisionShape3D.new()
	sb.add_child(s.struct_cs)
	s.add_child(sb)
	var railb := _static_body(0.3)
	for n in SLICES * 2:
		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = Vector3(0.3, 1.0, DS + 0.4)
		cs.shape = bs
		railb.add_child(cs)
		s.rail_cs.append(cs)
	s.add_child(railb)

	s.posts = _mmi(_post_mesh, SLICES * 2)
	s.posts.material_override = _post_mat
	s.poles = _mmi(_pole_mesh, 4)
	s.poles.material_override = _pole_mat
	s.arms = _mmi(_arm_mesh, 4)
	s.arms.material_override = _pole_mat
	s.lamps = _mmi(_lamp_mesh, 4)
	s.lamps.material_override = _lamp_mat
	s.lamps.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	s.trunks = _mmi(_trunk_mesh, MAX_TREES)
	s.trunks.material_override = _trunk_mat
	s.crowns = _mmi(_crown_mesh, MAX_TREES)
	s.crowns.material_override = _crown_mat
	s.builds = _mmi(_unit_box, MAX_BUILD, true)
	s.builds.material_override = _build_mat
	s.piers = _mmi(_pier_mesh, 3)
	s.piers.material_override = _concrete_mat
	for m in [s.posts, s.poles, s.arms, s.lamps, s.trunks, s.crowns, s.builds, s.piers]:
		s.add_child(m)
	add_child(s)
	return s


func _tv(P: PackedVector3Array, R: PackedVector3Array, j: int, sgn: float, x: float, y: float) -> Vector3:
	return Vector3(P[j].x + R[j].x * sgn * x, y, P[j].z + R[j].z * sgn * x)


func _add_surface(am: ArrayMesh, buf: MeshBuf, mat: Material) -> void:
	if buf.is_empty():
		return
	var arr := []
	arr.resize(Mesh.ARRAY_MAX)
	arr[Mesh.ARRAY_VERTEX] = buf.v
	arr[Mesh.ARRAY_NORMAL] = buf.n
	arr[Mesh.ARRAY_TEX_UV] = buf.uv
	arr[Mesh.ARRAY_INDEX] = buf.idx
	am.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
	am.surface_set_material(am.get_surface_count() - 1, mat)


func _set_collider(cs: CollisionShape3D, buf: MeshBuf) -> void:
	if buf.is_empty():
		cs.disabled = true
		return
	var sh := ConcavePolygonShape3D.new()
	sh.backface_collision = true
	sh.set_faces(buf.faces())
	cs.shape = sh
	cs.disabled = false


func _place(seg: Segment, i: int) -> void:
	var path := _get_path(i)
	var p: PackedVector3Array = path["p"]
	var yw: PackedFloat32Array = path["yaw"]
	var o := Vector3(p[0].x, 0.0, p[0].z)
	seg.position = o
	seg.visible = true
	var P := PackedVector3Array()
	var R := PackedVector3Array()
	for j in SLICES + 1:
		P.append(p[j] - o)
		R.append(Vector3(cos(yw[j]), 0.0, -sin(yw[j])))
	seg.local_mid = P[SLICES / 2]
	seg.pts = P
	seg.yws = yw

	var btype := _block_type(i)
	seg.btype = btype
	var blk_start := floori(float(i) / BLOCK_SEGS) * BLOCK_SEGS
	var sl0 := float(i - blk_start) * SEG_LEN
	var depth := PackedFloat32Array()
	var mound := PackedFloat32Array()
	var sls := PackedFloat32Array()
	for j in SLICES + 1:
		var sl := sl0 + j * DS
		var f := _feat(btype, sl)
		sls.append(sl)
		depth.append(f.x)
		mound.append(f.y)

	var road := MeshBuf.new()
	var rail := MeshBuf.new()
	var terr := MeshBuf.new()
	var st := MeshBuf.new()
	var lt := MeshBuf.new()
	var up := Vector3.UP
	var v0 := float(i % 2) * 0.5
	var lat := [7.0, 8.5, 8.5, 40.0, 200.0]

	for j in SLICES:
		var j2 := j + 1
		var va := v0 + float(j) / SLICES * 0.5
		var vb := v0 + float(j2) / SLICES * 0.5
		# road deck
		road.quad(P[j] - R[j] * ROAD_HALF, P[j] + R[j] * ROAD_HALF,
				P[j2] + R[j2] * ROAD_HALF, P[j2] - R[j2] * ROAD_HALF, up,
				Vector2(0, va), Vector2(1, va), Vector2(1, vb), Vector2(0, vb))
		var tunnel := btype == 2 and sls[j] >= 39.9 and sls[j2] <= 200.1
		var bridge := btype == 1 and depth[j] > 1.0 and depth[j2] > 1.0

		for sgn: float in [-1.0, 1.0]:
			# guard rail (visual)
			rail.quad(P[j] + R[j] * 7.5 * sgn + up * 0.45, P[j] + R[j] * 7.5 * sgn + up * 0.95,
					P[j2] + R[j2] * 7.5 * sgn + up * 0.95, P[j2] + R[j2] * 7.5 * sgn + up * 0.45,
					-R[j] * sgn)
			# terrain cross-section
			var h0a := P[j].y - 0.08 - depth[j]
			var h0b := P[j2].y - 0.08 - depth[j2]
			var ha := [h0a, h0a, h0a + mound[j] * 6.6, h0a + mound[j] * 24.0, h0a + mound[j] * 24.0]
			var hb := [h0b, h0b, h0b + mound[j2] * 6.6, h0b + mound[j2] * 24.0, h0b + mound[j2] * 24.0]
			for k in 4:
				var a := _tv(P, R, j, sgn, lat[k], ha[k])
				var b := _tv(P, R, j, sgn, lat[k + 1], ha[k + 1])
				var c := _tv(P, R, j2, sgn, lat[k + 1], hb[k + 1])
				var d := _tv(P, R, j2, sgn, lat[k], hb[k])
				var nrm := (b - a).cross(d - a)
				if nrm.length() < 0.0001:
					continue
				nrm = nrm.normalized()
				var toward: Vector3 = up if absf(nrm.y) > 0.6 else -R[j] * sgn
				terr.quad(a, b, c, d, toward)
			if bridge:   # girders along deck edges
				st.quad(P[j] + R[j] * 7.1 * sgn - up * 0.1, P[j] + R[j] * 7.1 * sgn - up * 1.3,
						P[j2] + R[j2] * 7.1 * sgn - up * 1.3, P[j2] + R[j2] * 7.1 * sgn - up * 0.1,
						R[j] * sgn)
			if tunnel:
				st.quad(P[j] + R[j] * 8.3 * sgn, P[j] + R[j] * 8.3 * sgn + up * 6.5,
						P[j2] + R[j2] * 8.3 * sgn + up * 6.5, P[j2] + R[j2] * 8.3 * sgn,
						-R[j] * sgn)

		if bridge:   # underside slab
			st.quad(P[j] - R[j] * 7.1 - up * 1.3, P[j] + R[j] * 7.1 - up * 1.3,
					P[j2] + R[j2] * 7.1 - up * 1.3, P[j2] - R[j2] * 7.1 - up * 1.3, -up)
		if tunnel:
			st.quad(P[j] - R[j] * 8.6 + up * 6.5, P[j] + R[j] * 8.6 + up * 6.5,
					P[j2] + R[j2] * 8.6 + up * 6.5, P[j2] - R[j2] * 8.6 + up * 6.5, -up)
			var hc := P[j].y - 0.08 + 6.6
			var hd := P[j2].y - 0.08 + 6.6
			terr.quad(_tv(P, R, j, -1.0, 8.5, hc), _tv(P, R, j, 1.0, 8.5, hc),
					_tv(P, R, j2, 1.0, 8.5, hd), _tv(P, R, j2, -1.0, 8.5, hd), up)
			if j % 2 == 0:   # ceiling light strip
				var q0 := P[j].lerp(P[j2], 0.25)
				var q1 := P[j].lerp(P[j2], 0.75)
				var r0 := R[j]
				lt.quad(q0 - r0 * 0.4 + up * 6.45, q0 + r0 * 0.4 + up * 6.45,
						q1 + r0 * 0.4 + up * 6.45, q1 - r0 * 0.4 + up * 6.45, -up)

	var am := ArrayMesh.new()
	_add_surface(am, road, _road_mat)
	_add_surface(am, terr, _terrain_mat)
	_add_surface(am, st, _concrete_mat)
	_add_surface(am, rail, _rail_mat)
	_add_surface(am, lt, _tlight_mat)
	seg.mi.mesh = am

	_set_collider(seg.road_cs, road)
	_set_collider(seg.terr_cs, terr)
	_set_collider(seg.struct_cs, st)
	var n := 0
	for sgn: float in [-1.0, 1.0]:
		for j in SLICES:
			var mid := (P[j] + P[j + 1]) * 0.5
			var ym := (yw[j] + yw[j + 1]) * 0.5
			var rm := Vector3(cos(ym), 0.0, -sin(ym))
			var cs := seg.rail_cs[n]
			cs.transform = Transform3D(Basis(Vector3.UP, ym), mid + rm * 7.6 * sgn + up * 0.5)
			cs.disabled = false
			n += 1

	_decorate(seg, i, P, R, yw, btype, depth)
	_apply_counts(seg)


func _decorate(seg: Segment, i: int, P: PackedVector3Array, R: PackedVector3Array,
		yw: PackedFloat32Array, btype: int, depth: PackedFloat32Array) -> void:
	# guard-rail posts
	var n := 0
	for sgn: float in [-1.0, 1.0]:
		for j in SLICES:
			var pos := P[j] + R[j] * 7.5 * sgn + Vector3.UP * 0.4
			seg.posts.multimesh.set_instance_transform(n, Transform3D(Basis(Vector3.UP, yw[j]), pos))
			n += 1
	# street lights at j = 3 and 9 on both sides
	n = 0
	for sgn: float in [-1.0, 1.0]:
		for j: int in [3, 9]:
			var b := Basis(Vector3.UP, yw[j])
			seg.poles.multimesh.set_instance_transform(n, Transform3D(b, P[j] + R[j] * 8.3 * sgn + Vector3.UP * 3.75))
			seg.arms.multimesh.set_instance_transform(n, Transform3D(b, P[j] + R[j] * 7.3 * sgn + Vector3.UP * 7.4))
			seg.lamps.multimesh.set_instance_transform(n, Transform3D(b, P[j] + R[j] * 6.4 * sgn + Vector3.UP * 7.3))
			n += 1
	# bridge piers
	seg.n_pier = 0
	if btype == 1:
		for j: int in [2, 6, 10]:
			var d := depth[j] - 1.2
			if d > 2.0:
				var b := Basis(Vector3.UP, yw[j]) * Basis().scaled(Vector3(1, d, 1))
				seg.piers.multimesh.set_instance_transform(seg.n_pier,
						Transform3D(b, P[j] + Vector3.UP * (-1.3 - d * 0.5)))
				seg.n_pier += 1
	# trees, buildings and modelled scenery (normal blocks only)
	seg.prop_n.clear()
	if btype != 0:
		return
	_rng.seed = i * 7919 + 17
	var ts := float(biome["tree_s"])
	for t in MAX_TREES:
		var side := -1.0 if _rng.randf() < 0.5 else 1.0
		var x := side * _rng.randf_range(11.0, 70.0)
		var fj := _rng.randf_range(0.0, SLICES - 0.001)
		var sc := _rng.randf_range(0.8, 1.6) * ts
		var c := _interp(P, R, yw, fj, x)
		var b := Basis().scaled(Vector3(sc, sc, sc))
		seg.trunks.multimesh.set_instance_transform(t, Transform3D(b, c + Vector3.UP * (-0.08 + 1.5 * sc)))
		seg.crowns.multimesh.set_instance_transform(t, Transform3D(b, c + Vector3.UP * (-0.08 + 3.8 * sc)))
	var bh: Vector2 = biome["b_h"]
	for k in MAX_BUILD:
		var side := -1.0 if _rng.randf() < 0.5 else 1.0
		var x := side * _rng.randf_range(24.0, 70.0)
		var fj := _rng.randf_range(0.0, SLICES - 0.001)
		var w := _rng.randf_range(10.0, 22.0)
		var h := _rng.randf_range(bh.x, bh.y)
		var c := _interp(P, R, yw, fj, x)
		var yaw := lerpf(yw[int(fj)], yw[int(fj) + 1], fj - int(fj))
		var b := Basis(Vector3.UP, yaw) * Basis().scaled(Vector3(w, h, w * _rng.randf_range(0.8, 1.4)))
		seg.builds.multimesh.set_instance_transform(k, Transform3D(b, c + Vector3.UP * (-0.08 + h * 0.5)))
		var g := _rng.randf_range(0.45, 0.8)
		seg.builds.multimesh.set_instance_color(k, Color(g, g, g * 1.06))
	_scatter_props(seg, P, R, yw)


## Modelled scenery for the current biome (see BIOME_PROPS).
func _scatter_props(seg: Segment, P: PackedVector3Array, R: PackedVector3Array, yw: PackedFloat32Array) -> void:
	var list: Array = BIOME_PROPS.get(str(biome["name"]), [])
	seg.prop_n.clear()
	for k in list.size():
		var e: Array = list[k]
		var mesh: Mesh = PropLib.mesh(str(e[0]))
		if k >= seg.prop_mmis.size():
			var m := _mmi(mesh if mesh != null else _unit_box, MAX_PROP)
			m.multimesh.custom_aabb = AABB(Vector3(-450, -60, -200), Vector3(900, 320, 400))
			m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			m.visibility_range_end = 900.0
			seg.add_child(m)
			seg.prop_mmis.append(m)
		if mesh == null:
			seg.prop_n.append(0)
			continue
		var mmi := seg.prop_mmis[k]
		mmi.multimesh.mesh = mesh
		var cnt := mini(int(e[1]), MAX_PROP)
		var height := float((PropCatalog.PROPS[str(e[0])]["size"] as Array)[1])
		for t in cnt:
			var side := -1.0 if _rng.randf() < 0.5 else 1.0
			var x := side * _rng.randf_range(float(e[2]), float(e[3]))
			var fj := _rng.randf_range(0.0, SLICES - 0.001)
			var sc := _rng.randf_range(float(e[4]), float(e[5]))
			var b := Basis(Vector3.UP, _rng.randf() * TAU) * Basis().scaled(Vector3(sc, sc, sc))
			var c := _interp(P, R, yw, fj, x)
			mmi.multimesh.set_instance_transform(t, Transform3D(b, c + Vector3.UP * (-0.08 - float(e[6]) * height * sc)))
		seg.prop_n.append(cnt)
	for k in range(list.size(), seg.prop_mmis.size()):
		seg.prop_n.append(0)


## Point at fractional slice `fj`, `x` metres to the right of the centre-line.
func _interp(P: PackedVector3Array, R: PackedVector3Array, yw: PackedFloat32Array, fj: float, x: float) -> Vector3:
	var j := int(fj)
	var f := fj - j
	var c := P[j].lerp(P[j + 1], f)
	var y := lerpf(yw[j], yw[j + 1], f)
	var r := Vector3(cos(y), 0.0, -sin(y))
	return c + r * x


func _build_hills() -> void:
	var k := 0
	for side: float in [-1.0, 1.0]:
		for oz: float in [-900.0, -300.0, 300.0, 900.0]:
			var m := MeshInstance3D.new()
			var cm := CylinderMesh.new()
			cm.top_radius = 0.0
			cm.bottom_radius = 300.0 + 40.0 * (k % 3)
			cm.height = 220.0 + 60.0 * (k % 2)
			cm.radial_segments = 8
			cm.rings = 1
			m.mesh = cm
			m.material_override = _hill_mat
			m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			m.set_meta("ox", side * (650.0 + 40.0 * (k % 3)))
			m.set_meta("oz", oz + 120.0 * (k % 2))
			m.set_meta("half", cm.height * 0.5)
			add_child(m)
			_hills.append(m)
			k += 1
