class_name PropLib
extends RefCounted
## Loads the prop kits (assets/props/*.glb, built by tools/build_props.py) and hands out
## their meshes by name (see PropCatalog). Kits are loaded the first time one of their
## props is asked for and the meshes are shared by every road segment.

static var _meshes: Dictionary = {}
static var _loaded: Dictionary = {}


static func mesh(prop_name: String) -> Mesh:
	var info: Dictionary = PropCatalog.PROPS.get(prop_name, {})
	if info.is_empty():
		return null
	var kit := str(info["kit"])
	if not _loaded.has(kit):
		_load_kit(kit)
	return _meshes.get(prop_name, null)


static func _load_kit(kit: String) -> void:
	_loaded[kit] = true
	var ps: PackedScene = load("res://assets/props/%s.glb" % kit) as PackedScene
	if ps == null:
		push_warning("Prop kit missing: " + kit)
		return
	var root := ps.instantiate()
	for mi in root.find_children("*", "MeshInstance3D", true, false):
		_meshes[str(mi.name)] = (mi as MeshInstance3D).mesh
	root.free()


## For the SCRIPT CHECK screen: how many of the catalogued props actually loaded.
static func loaded_count() -> int:
	for n in PropCatalog.PROPS:
		mesh(n)
	return _meshes.size()
