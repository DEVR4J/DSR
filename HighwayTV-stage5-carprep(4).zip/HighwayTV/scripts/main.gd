extends Node3D
## Highway TV - Stage 1 entry point. Builds world, car, camera, HUD and wires input.

enum Quality { LOW, MEDIUM, HIGH, ULTRA }
const QUALITY_NAMES := ["LOW", "MEDIUM", "HIGH", "ULTRA"]

var quality: int = Quality.MEDIUM
var car: HighwayCar
var car2: HighwayCar          # player 2's car (2-player mode)
var two_player := false
const RACE_GAP := 6.0 * RoadWorld.LIGHT_SPACING     # 6 street lights = 180 m
var _countdown := 3.0
var _go_t := 0.0
var _over := false
var world: RoadWorld
var cam: ChaseCamera
var hud: HUD
var sun: DirectionalLight3D
var _env: Environment
var _sky_mat: ProceduralSkyMaterial
var biome := 0
var paused := false


func _ready() -> void:
	two_player = GameState.mode == 2
	quality = _recommend_quality()
	_setup_environment()

	world = RoadWorld.new()
	add_child(world)

	if two_player:
		# lane 1 (left) and lane 3 (right); the camera sits in lane 2 between them
		car = _make_car(0, GameState.car_id, _lane_xf(1))
		car2 = _make_car(1, GameState.car_id2, _lane_xf(3))
		car.add_player_tag("P1", Color(1.0, 0.5, 0.45))
	else:
		car = _make_car(0, GameState.car_id, Transform3D(Basis(), Vector3(0, 1.0, -8)))

	cam = ChaseCamera.new()
	cam.target = car
	cam.distance_scale = clampf(car.car_length / 4.3, 0.8, 1.7)
	if two_player:
		cam.two_player = true
		cam.targets.assign([car, car2])
		cam.world = world
	add_child(cam)
	cam.current = true

	hud = HUD.new()
	hud.car = car
	hud.car2 = car2
	hud.cam = cam
	if two_player:
		hud.names.assign([_car_name(GameState.car_id), _car_name(GameState.car_id2)])
	hud.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(hud)
	hud.resume_requested.connect(_toggle_pause)
	hud.menu_requested.connect(_to_menu)
	hud.rematch_requested.connect(_rematch)

	world.update_for(car.position, car2.position if car2 != null else Vector3.INF)
	_apply_quality()
	_set_biome(GameState.biome)

	GameInput.back_pressed.connect(_on_back)
	GameInput.accept_pressed.connect(_on_accept)
	GameInput.pause_pressed.connect(_toggle_pause)
	GameInput.camera_pressed.connect(_on_camera)
	GameState.players[0].reset_pressed.connect(_reset_car.bind(0))
	GameState.players[1].reset_pressed.connect(_reset_car.bind(1))
	GameState.players[0].locked = two_player
	GameState.players[1].locked = two_player
	if two_player:
		cam.reset_view()          # the lane camera starts from default distance/zoom/height
	_update_hud_text()


func _physics_process(delta: float) -> void:
	var p2 := Vector3.INF
	if car2 != null:
		p2 = car2.global_position
	world.update_for(car.global_position, p2)
	var off := world.rebase_if_needed(car.global_position)
	if off != Vector3.ZERO:
		car.global_position += off
		if car2 != null:
			car2.global_position += off
		cam.snap()
	if two_player:
		_race_step(delta)


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_F1:
		quality = (quality + 1) % 4
		_apply_quality()
	elif event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_F3:
		GameState.cluster_mode = (GameState.cluster_mode + 1) % 3
	elif event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_F2:
		_set_biome(biome + 1)


# ------------------------------------------------------------------- input
func _on_back() -> void:
	if _over:
		_to_menu()
	else:
		_toggle_pause()          # BACK pauses / resumes (MAIN MENU is a button in the pause screen)


func _on_accept() -> void:
	if not paused:           # while paused, OK presses the focused button instead
		cam.next_mode()

func _on_camera() -> void:
	if not paused:
		cam.next_mode()

func _reset_car(slot: int) -> void:
	var c := car if slot == 0 else car2
	if not paused and c != null:
		c.reset_upright()

# ------------------------------------------------------------ two players
func _lane_xf(lane: int) -> Transform3D:
	return Transform3D(Basis(), Vector3((lane - 2) * 3.5, 1.0, -8.0))


func _car_name(id: String) -> String:
	if id == "":
		return "BUILT-IN COUPE"
	return str(CarSpec.load_spec(id).get("name", id)).to_upper()


## Countdown, gap tracking and the win rule: the car that gets more than six street
## lights (180 m) ahead of the other one wins.
func _race_step(delta: float) -> void:
	if _over:
		return
	var f1 := world.road_frame(car.global_position)
	var f2 := world.road_frame(car2.global_position)
	var gap: float = float(f1["s"]) - float(f2["s"])
	cam.gap = absf(gap)
	hud.race_gap = gap
	hud.race_limit = RACE_GAP
	if _countdown > 0.0:
		_countdown -= delta
		hud.banner = str(ceili(_countdown)) if _countdown > 0.0 else "GO!"
		if _countdown <= 0.0:
			_go_t = 1.0
			GameState.players[0].locked = false
			GameState.players[1].locked = false
		return
	if _go_t > 0.0:
		_go_t -= delta
		if _go_t <= 0.0:
			hud.banner = ""
	if absf(gap) > RACE_GAP:
		_over = true
		var win := 1 if gap > 0.0 else 2
		hud.banner = ""
		hud.show_result("PLAYER %d WINS!" % win, "%s  -  led by %d m" % [_car_name(GameState.car_id if win == 1 else GameState.car_id2), int(absf(gap))])
		paused = true
		get_tree().paused = true


func _rematch() -> void:
	GameState.goto("res://scenes/main.tscn")


func _make_car(slot: int, id: String, xf: Transform3D) -> HighwayCar:
	var c := HighwayCar.new()
	c.pstate = GameState.players[slot]
	if slot == 1:
		c.paint_color = Color(0.1, 0.35, 0.85)
	if id != "":
		c.spec = CarSpec.load_spec(id)
	c.transform = xf
	add_child(c)
	if slot == 1:
		c.add_player_tag("P2", Color(0.45, 0.75, 1.0))
	return c


func _to_menu() -> void:
	GameState.goto("res://scenes/menu.tscn")


func _toggle_pause() -> void:
	if _over:
		return
	paused = not paused
	get_tree().paused = paused
	hud.set_paused(paused)


# ---------------------------------------------------------------- graphics
func _recommend_quality() -> int:
	var cores := OS.get_processor_count()
	if cores >= 8:
		return Quality.HIGH
	if cores >= 4:
		return Quality.MEDIUM
	return Quality.LOW


func _apply_quality() -> void:
	sun.shadow_enabled = quality >= Quality.MEDIUM
	sun.directional_shadow_max_distance = [0.0, 60.0, 90.0, 130.0][quality]
	var msaa := [Viewport.MSAA_DISABLED, Viewport.MSAA_DISABLED, Viewport.MSAA_2X, Viewport.MSAA_4X]
	get_viewport().msaa_3d = msaa[quality]
	world.set_tree_count([6, 12, 18, 24][quality])
	world.set_view_segments([7, 9, 11, 13][quality])
	world.set_prop_density([0.5, 0.8, 1.0, 1.3][quality])
	_update_hud_text()


func _update_hud_text() -> void:
	if hud != null:
		hud.extra_text = "%s (F2)\nQUALITY %s (F1)" % [world.biome["name"], QUALITY_NAMES[quality]]
		if car.custom_failed:
			hud.extra_text += "\nCUSTOM CAR FAILED TO LOAD - using built-in car"


func _set_biome(b: int) -> void:
	biome = wrapi(b, 0, RoadWorld.BIOMES.size())
	world.set_biome(biome)
	var d: Dictionary = world.biome
	_sky_mat.sky_top_color = d["sky_top"]
	_sky_mat.sky_horizon_color = d["sky_hor"]
	_sky_mat.ground_horizon_color = d["sky_hor"]
	_sky_mat.ground_bottom_color = d["ground"]
	_env.fog_light_color = d["fog"]
	_env.fog_density = d["fog_d"]
	world.update_for(car.global_position)
	_update_hud_text()


func _setup_environment() -> void:
	var sm := ProceduralSkyMaterial.new()
	_sky_mat = sm
	sm.sky_top_color = Color(0.25, 0.45, 0.8)
	sm.sky_horizon_color = Color(0.7, 0.8, 0.9)
	sm.ground_horizon_color = Color(0.6, 0.68, 0.6)
	sm.ground_bottom_color = Color(0.3, 0.4, 0.3)
	var sky := Sky.new()
	sky.sky_material = sm
	var env := Environment.new()
	_env = env
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.9
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_light_color = Color(0.72, 0.8, 0.9)
	env.fog_density = 0.0012
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -35, 0)
	sun.light_energy = 1.3
	sun.shadow_enabled = true
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	add_child(sun)


func _exit_tree() -> void:
	GameState.players[0].locked = false
	GameState.players[1].locked = false
	GameState.cam_dist = 1.0
	GameState.cam_pitch = 0.0
	GameState.cam_yaw = 0.0
	GameState.cam_zoom = 1.0
	for pair in [[GameInput.back_pressed, _on_back], [GameInput.accept_pressed, _on_accept],
			[GameInput.pause_pressed, _toggle_pause], [GameInput.camera_pressed, _on_camera],
			[GameInput.camera_pressed, _on_camera]]:
		if pair[0].is_connected(pair[1]):
			pair[0].disconnect(pair[1])
