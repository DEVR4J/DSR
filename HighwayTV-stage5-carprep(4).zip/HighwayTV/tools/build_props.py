"""Builds the prop kits (assets/props/*.glb + catalog.json) from the downloaded packs.
usage: python3 build_props.py <packs_dir> <out_dir>
Each prop is cut out of a pack (a whole node, a connected component of a merged mesh, or several
nodes merged), re-based so its origin is bottom-centre, scaled to a real-world size, and written
with only the materials/textures it needs (textures shrunk)."""
import sys, os, json, struct, io, collections
import numpy as np
from PIL import Image
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from kit import Pack, components

SRC = sys.argv[1] if len(sys.argv) > 1 else '/tmp/assets'
OUT = sys.argv[2] if len(sys.argv) > 2 else '/tmp/kit/out'
MAX_TEX = 512
_packs = {}
def pack(n):
    if n not in _packs: _packs[n] = Pack(os.path.join(SRC, n))
    return _packs[n]

# ----------------------------------------------------------------- selectors
def node_parts(pk, names=None, suffix=None, index=None, raw=False):
    out = []
    for i, (nm, M, mi) in enumerate(pk.nodes()):
        ok = (names is not None and nm in names) or (suffix is not None and nm.endswith(suffix)) or (index is not None and i == index)
        if ok:
            for p in pk.prims(mi, np.eye(4) if raw else M): out.append(dict(p, pack=pk))
    assert out, (names, suffix, index)
    return out

def comp_parts(pk, node, pred, pick=0):
    cands = []
    for nm, M, mi in pk.nodes():
        if nm != node: continue
        for p in pk.prims(mi, M):
            k, lab = components(p['pos'], p['idx'])
            for c in range(k):
                sel = p['idx'][lab == c]
                used = np.unique(sel); remap = -np.ones(len(p['pos']), dtype=np.int64); remap[used] = np.arange(len(used))
                q = dict(pos=p['pos'][used], nrm=None if p['nrm'] is None else p['nrm'][used],
                         uv=None if p['uv'] is None else p['uv'][used], idx=remap[sel], mat=p['mat'], pack=pk)
                ext = q['pos'].max(0) - q['pos'].min(0)
                if pred(len(sel), ext): cands.append(q)
    assert cands, (node,)
    cands.sort(key=lambda q: (q['pos'].max(0) - q['pos'].min(0))[1])
    return [cands[min(pick, len(cands) - 1)]]

def all_comps(pk, node, pred):
    return comp_parts(pk, node, pred, 0)

# --------------------------------------------------------------- normalizing
def normalize(parts, height=None, size=None, scale=None, rot_y=0.0, sink=0.0):
    allp = np.concatenate([p['pos'] for p in parts]); lo = allp.min(0); hi = allp.max(0); ext = hi - lo
    if height: s = height / max(ext[1], 1e-9)
    elif size: s = size / max(ext.max(), 1e-9)
    else: s = scale or 1.0
    c = np.array([(lo[0] + hi[0]) / 2, lo[1], (lo[2] + hi[2]) / 2])
    a = np.radians(rot_y); R = np.array([[np.cos(a), 0, np.sin(a)], [0, 1, 0], [-np.sin(a), 0, np.cos(a)]])
    out = []
    for p in parts:
        q = dict(p); q['pos'] = ((p['pos'] - c) * s) @ R.T; q['pos'][:, 1] -= sink
        if p['nrm'] is not None: q['nrm'] = p['nrm'] @ R.T
        out.append(q)
    return out

def flat_normals(pos, idx):
    n = np.cross(pos[idx[:, 1]] - pos[idx[:, 0]], pos[idx[:, 2]] - pos[idx[:, 0]])
    l = np.linalg.norm(n, axis=1, keepdims=True); return n / np.maximum(l, 1e-9)

# -------------------------------------------------------------------- writer
class Glb:
    def __init__(s):
        s.bin = bytearray(); s.bv = []; s.acc = []; s.meshes = []; s.nodes = []
        s.materials = []; s.textures = []; s.images = []; s.matkey = {}; s.imgkey = {}
    def view(s, data, target=None):
        while len(s.bin) % 4: s.bin.append(0)
        v = {'buffer': 0, 'byteOffset': len(s.bin), 'byteLength': len(data)}
        if target: v['target'] = target
        s.bin += data; s.bv.append(v); return len(s.bv) - 1
    def accessor(s, arr, ctype, typ, target, minmax=False):
        a = {'bufferView': s.view(arr.tobytes(), target), 'componentType': ctype, 'count': int(len(arr)), 'type': typ}
        if minmax: a['min'] = [float(x) for x in arr.min(0)]; a['max'] = [float(x) for x in arr.max(0)]
        s.acc.append(a); return len(s.acc) - 1
    def image(s, pk, ii):
        key = (pk.dir, ii)
        if key in s.imgkey: return s.imgkey[key]
        im = pk.image(ii); 
        if max(im.size) > MAX_TEX:
            k = MAX_TEX / max(im.size); im = im.resize((max(1, int(im.width * k)), max(1, int(im.height * k))), Image.LANCZOS)
        buf = io.BytesIO(); opaque = im.getchannel('A').getextrema()[0] == 255
        if opaque and im.width * im.height > 128 * 128: im.convert('RGB').save(buf, 'JPEG', quality=85); mime = 'image/jpeg'
        else: im.save(buf, 'PNG', optimize=True); mime = 'image/png'
        s.images.append({'bufferView': s.view(buf.getvalue()), 'mimeType': mime})
        s.textures.append({'source': len(s.images) - 1}); s.imgkey[key] = len(s.textures) - 1; return s.imgkey[key]
    def material(s, pk, mi, double):
        key = (pk.dir, mi, double)
        if key in s.matkey: return s.matkey[key]
        m = pk.g['materials'][mi] if pk.g.get('materials') else {}
        pbr = m.get('pbrMetallicRoughness', {}); out = {'pbrMetallicRoughness': {'baseColorFactor': pbr.get('baseColorFactor', [1, 1, 1, 1]),
             'metallicFactor': 0.0, 'roughnessFactor': 0.95}, 'name': m.get('name', 'mat%d' % mi), 'doubleSided': bool(double or m.get('doubleSided'))}
        t = pbr.get('baseColorTexture')
        if t is not None:
            out['pbrMetallicRoughness']['baseColorTexture'] = {'index': s.image(pk, pk.g['textures'][t['index']]['source'])}
        if m.get('alphaMode') in ('MASK',): out['alphaMode'] = 'MASK'; out['alphaCutoff'] = m.get('alphaCutoff', 0.5)
        s.materials.append(out); s.matkey[key] = len(s.materials) - 1; return s.matkey[key]
    def add_prop(s, name, parts, double=False):
        groups = collections.OrderedDict()
        for p in parts: groups.setdefault((p['pack'].dir, p['mat']), []).append(p)
        prims = []; tris = 0
        for (d, mi), lst in groups.items():
            pk = lst[0]['pack']
            pos = np.concatenate([q['pos'] for q in lst]).astype(np.float32)
            off = 0; idxs = []; uvs = []; nrms = []
            for q in lst:
                idxs.append(q['idx'] + off); off += len(q['pos'])
                uvs.append(q['uv'] if q['uv'] is not None else np.zeros((len(q['pos']), 2)))
                nrms.append(q['nrm'] if q['nrm'] is not None else np.zeros((len(q['pos']), 3)))
            idx = np.concatenate(idxs); uv = np.concatenate(uvs).astype(np.float32); nrm = np.concatenate(nrms)
            if np.abs(nrm).sum() < 1e-6:           # no normals in the source: flat shading
                fn = flat_normals(pos.astype(np.float64), idx)
                P = pos[idx.reshape(-1)]; U = uv[idx.reshape(-1)]; N = np.repeat(fn, 3, axis=0); idx = np.arange(len(P)).reshape(-1, 3); pos, uv, nrm = P, U, N
            nrm = nrm.astype(np.float32); tris += len(idx)
            it = np.uint16 if len(pos) < 65535 else np.uint32
            prims.append({'attributes': {'POSITION': s.accessor(pos, 5126, 'VEC3', 34962, True), 'NORMAL': s.accessor(nrm, 5126, 'VEC3', 34962),
                          'TEXCOORD_0': s.accessor(uv, 5126, 'VEC2', 34962)},
                          'indices': s.accessor(idx.reshape(-1).astype(it), 5123 if it == np.uint16 else 5125, 'SCALAR', 34963),
                          'material': s.material(pk, mi, double)})
        s.meshes.append({'name': name, 'primitives': prims}); s.nodes.append({'name': name, 'mesh': len(s.meshes) - 1})
        return tris
    def save(s, path):
        g = {'asset': {'version': '2.0', 'generator': 'highwaytv build_props'}, 'scene': 0, 'scenes': [{'nodes': list(range(len(s.nodes)))}],
             'nodes': s.nodes, 'meshes': s.meshes, 'accessors': s.acc, 'bufferViews': s.bv, 'materials': s.materials,
             'buffers': [{'byteLength': len(s.bin)}]}
        if s.textures: g['textures'] = s.textures; g['images'] = s.images
        js = json.dumps(g, separators=(',', ':')).encode()
        while len(js) % 4: js += b' '
        b = bytes(s.bin)
        while len(b) % 4: b += b'\0'
        with open(path, 'wb') as f:
            f.write(struct.pack('<III', 0x46546C67, 2, 12 + 8 + len(js) + 8 + len(b)))
            f.write(struct.pack('<II', len(js), 0x4E4F534A)); f.write(js)
            f.write(struct.pack('<II', len(b), 0x004E4942)); f.write(b)

# ------------------------------------------------------------------ the items
def sig_node(pk, tris, pred, pick=0):
    c = []
    for nm, M, mi in pk.nodes():
        ps = pk.prims(mi, M)
        if sum(len(p['idx']) for p in ps) != tris: continue
        allp = np.concatenate([p['pos'] for p in ps]); ext = allp.max(0) - allp.min(0)
        if pred(ext): c.append((ext[1], [dict(p, pack=pk) for p in ps]))
    assert c, (tris,)
    c.sort(key=lambda x: x[0]); return c[min(pick, len(c) - 1)][1]

def near(h, t, tol=0.03): return lambda tr, e: tr == t and abs(e[1] - h) < tol

FD = lambda: pack('free_desert_environment')
KITS = collections.OrderedDict()
KITS['forest'] = [
    ('pine_s', 'tree', lambda: comp_parts(pack('low_poly_forest_1'), 'Object_2', near(1.82, 192) if False else (lambda t, e: t == 192 and abs(e[1] - 1.82) < 0.03)), dict(height=8)),
    ('pine_m', 'tree', lambda: comp_parts(pack('low_poly_forest_1'), 'Object_2', lambda t, e: t == 192 and abs(e[1] - 2.63) < 0.03), dict(height=11)),
    ('pine_l', 'tree', lambda: comp_parts(pack('low_poly_forest_1'), 'Object_3', lambda t, e: t == 192 and abs(e[1] - 3.9) < 0.03), dict(height=15)),
    ('pine_n1', 'tree', lambda: node_parts(pack('low_poly_nature_assets_1'), names=['default8_Material_0']), dict(height=9)),
    ('pine_n2', 'tree', lambda: node_parts(pack('low_poly_nature_assets_1'), names=['default9_Material_0']), dict(height=12)),
    ('rock_a', 'rock', lambda: comp_parts(pack('low_poly_forest_1'), 'Object_2', lambda t, e: t == 23 and 0.3 < e[1] < 0.6, 0), dict(height=0.9)),
    ('rock_b', 'rock', lambda: comp_parts(pack('low_poly_forest_1'), 'Object_2', lambda t, e: t == 23 and 0.3 < e[1] < 0.6, 3), dict(height=0.8)),
    ('rock_c', 'rock', lambda: comp_parts(pack('low_poly_forest_1'), 'Object_2', lambda t, e: t == 23 and 0.3 < e[1] < 0.6, 5), dict(height=1.1)),
    ('rock_tall_a', 'cliff', lambda: comp_parts(pack('low_poly_forest_1'), 'Object_2', lambda t, e: t == 56 and abs(e[1] - 3.71) < 0.05), dict(height=4)),
    ('rock_tall_b', 'cliff', lambda: comp_parts(pack('low_poly_forest_1'), 'Object_2', lambda t, e: t == 56 and abs(e[1] - 6.62) < 0.05), dict(height=7)),
    ('rock_tall_c', 'cliff', lambda: comp_parts(pack('low_poly_forest_1'), 'Object_2', lambda t, e: t == 56 and abs(e[1] - 8.62) < 0.05), dict(height=9)),
    ('bush_berry', 'bush', lambda: node_parts(pack('low_poly_nature_assets_1'), names=['default4_Material_0']), dict(size=1.9)),
    ('log', 'log', lambda: node_parts(pack('low_poly_nature_assets_1'), names=['default7_Material_0']), dict(size=3.2)),
    ('stump', 'log', lambda: node_parts(pack('low_poly_nature_assets_1'), names=['default1_Material_0']), dict(height=0.9)),
]
MT = lambda i: (lambda: node_parts(pack('free_pack_-_modular_terrain'), index=i))
KITS['mountain'] = [
    ('cliff_a', 'cliff', MT(2), {}), ('cliff_b', 'cliff', MT(16), {}), ('cliff_c', 'cliff', MT(27), {}),
    ('cliff_d', 'cliff', MT(32), {}), ('cliff_e', 'cliff', MT(29), {}), ('cliff_f', 'cliff', MT(1), {}),
    ('mount_a', 'mountain', MT(6), {}), ('mount_b', 'mountain', MT(28), {}), ('mount_c', 'mountain', MT(5), {}),
    ('hill_a', 'hill', MT(13), {}), ('hill_b', 'hill', MT(20), {}), ('hill_c', 'hill', MT(25), {}), ('hill_d', 'hill', MT(4), {}),
    ('dead_tree', 'tree', lambda: comp_parts(pack('low_poly_environments_01'), 'Object_5', lambda t, e: t == 516 and e[1] > 19, 0), dict(height=7.0)),
    ('peak_b', 'peak', lambda: comp_parts(pack('low_poly_environments_01'), 'Object_5', lambda t, e: t == 346 and e[1] > 20, 0), {}),
    ('peak_c', 'peak', lambda: comp_parts(pack('low_poly_environments_01'), 'Object_5', lambda t, e: t == 346 and 14 < e[1] < 15, 0), {}),
]
FDN = lambda n: (lambda: node_parts(FD(), names=[n + '_palette_0']))
RM = lambda: pack('desert_race_game_prototype_map')
KITS['desert'] = [
    ('d_rock_a', 'rock', FDN('Cube.003'), dict(height=1.7)), ('d_rock_b', 'rock', FDN('Cube.009'), dict(size=6.0)),
    ('d_rock_c', 'rock', FDN('Cube.010'), dict(size=5.0)), ('d_rock_d', 'rock', FDN('Icosphere.020'), dict(height=3.2)),
    ('d_rock_e', 'rock', FDN('Icosphere.015'), dict(height=2.0)),
    ('mesa_a', 'cliff', FDN('Icosphere.022'), dict(height=7.0)), ('mesa_b', 'cliff', FDN('Icosphere.023'), dict(height=6.0)),
    ('mesa_c', 'cliff', FDN('Icosphere.024'), dict(height=7.5)),
    ('bone_a', 'bones', FDN('Icosphere.026'), dict(size=1.2)), ('bone_b', 'bones', FDN('Icosphere.027'), dict(size=1.1)),
    ('cactus_a', 'cactus', FDN('Cylinder.002'), dict(height=5.5)), ('cactus_b', 'cactus', FDN('Cylinder.004'), dict(height=4.5)),
    ('pear_a', 'bush', FDN('Plane.012'), dict(height=1.4, double=True)), ('pear_b', 'bush', FDN('Plane.013'), dict(height=1.6, double=True)),
    ('dgrass_a', 'grass', FDN('Plane.016'), dict(height=1.0, double=True)), ('dgrass_b', 'grass', FDN('Plane.017'), dict(height=0.9, double=True)),
    ('skull', 'bones', FDN('Icosphere.030'), dict(size=1.3)),
    ('cactus_r1', 'cactus', lambda: node_parts(RM(), names=['Circle.004_Material.001_0'], raw=True), dict(height=4.5)),
    ('cactus_r2', 'cactus', lambda: node_parts(RM(), names=['Circle.006_Material.001_0'], raw=True), dict(height=3.5)),
    ('cactus_cluster', 'cactus', lambda: node_parts(RM(), names=['Circle.015_Material.001_0'], raw=True), dict(height=2.5)),
    ('dbush', 'bush', lambda: node_parts(RM(), names=['Icosphere.005_Material.001_0'], raw=True), dict(size=1.6)),
    ('red_hill_a', 'redhill', lambda: node_parts(RM(), names=['Plane.006_Material.001_0']), dict(size=60.0)),
    ('red_hill_b', 'redhill', lambda: node_parts(RM(), names=['Plane.003_Material.001_0']), dict(size=70.0)),
    ('red_hill_c', 'redhill', lambda: node_parts(RM(), names=['Plane.011_Material.001_0']), dict(size=50.0)),
    ('barrier', 'barrier', lambda: node_parts(RM(), names=['Cube.001_Material.001_0'], raw=True), dict(size=3.0)),
    ('palm_a', 'palm', lambda: node_parts(pack('low_poly_desert'), names=['PALM5_0', 'PALM5_1']), dict(height=9.0, double=True)),
    ('palm_b', 'palm', lambda: node_parts(pack('low_poly_desert'), names=['PALM3_006_0', 'PALM3_006_1']), dict(height=8.0, double=True)),
    ('adobe', 'house', lambda: node_parts(pack('low_poly_desert'), names=['Cube_003_2']), dict(size=7.0)),
]

if __name__ == '__main__':
    os.makedirs(OUT, exist_ok=True)
    catalog = {}
    for kit, items in KITS.items():
        g = Glb()
        for name, tag, sel, opt in items:
            opt = dict(opt); dbl = opt.pop('double', False)
            try:
                parts = normalize(sel(), **opt)
            except AssertionError as e:
                print("SKIP", name, "no match", e); continue
            tris = g.add_prop(name, parts, dbl)
            allp = np.concatenate([p['pos'] for p in parts]); ext = allp.max(0) - allp.min(0)
            catalog[name] = {'kit': kit, 'tag': tag, 'tris': int(tris), 'size': [round(float(x), 2) for x in ext]}
        path = os.path.join(OUT, kit + '.glb'); g.save(path)
        print(kit, len(g.nodes), 'props', os.path.getsize(path) // 1024, 'KB')
    json.dump(catalog, open(os.path.join(OUT, 'catalog.json'), 'w'), indent=1)
    print(len(catalog), 'props total')
