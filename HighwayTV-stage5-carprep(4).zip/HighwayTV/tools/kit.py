import json, os, struct, io, numpy as np
from PIL import Image, ImageDraw
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
CT={5120:np.int8,5121:np.uint8,5122:np.int16,5123:np.uint16,5125:np.uint32,5126:np.float32}
NC={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}
def local(n):
    if 'matrix' in n: return np.array(n['matrix']).reshape(4,4).T
    T=np.eye(4); s=n.get('scale',[1,1,1]); t=n.get('translation',[0,0,0]); x,y,z,w=n.get('rotation',[0,0,0,1])
    R=np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])
    T[:3,:3]=R*np.array(s); T[:3,3]=t; return T
class Pack:
    def __init__(s,d):
        s.dir=d
        f=[x for x in os.listdir(d) if x.endswith('.gltf')][0]
        s.g=json.load(open(os.path.join(d,f)))
        s.bins=[open(os.path.join(d,b['uri']),'rb').read() for b in s.g.get('buffers',[])]
        s.images={}
    def acc(s,i):
        a=s.g['accessors'][i]; bv=s.g['bufferViews'][a['bufferView']]
        dt=np.dtype(CT[a['componentType']]); nc=NC[a['type']]
        off=bv.get('byteOffset',0)+a.get('byteOffset',0); stride=bv.get('byteStride',0) or dt.itemsize*nc
        buf=s.bins[bv['buffer']]; n=a['count']
        if stride==dt.itemsize*nc:
            arr=np.frombuffer(buf,dtype=dt,count=n*nc,offset=off).reshape(n,nc)
        else:
            arr=np.stack([np.frombuffer(buf,dtype=dt,count=nc,offset=off+k*stride) for k in range(n)])
        if a.get('normalized'): arr=arr.astype(np.float32)/np.iinfo(dt).max
        return arr.astype(np.float64) if dt==np.float32 else arr
    def prims(s,mi,M):
        out=[]
        for p in s.g['meshes'][mi]['primitives']:
            if p.get('mode',4)!=4: continue
            at=p['attributes']; pos=s.acc(at['POSITION'])
            pw=(M[:3,:3]@pos.T).T+M[:3,3]
            nrm=None
            if 'NORMAL' in at:
                nrm=(np.linalg.inv(M[:3,:3]).T@s.acc(at['NORMAL']).T).T
                l=np.linalg.norm(nrm,axis=1,keepdims=True); nrm=nrm/np.maximum(l,1e-9)
            uv=s.acc(at['TEXCOORD_0']) if 'TEXCOORD_0' in at else None
            idx=s.acc(p['indices']).reshape(-1,3).astype(np.int64) if 'indices' in p else np.arange(len(pos)).reshape(-1,3)
            out.append(dict(pos=pw,nrm=nrm,uv=uv,idx=idx,mat=p.get('material',0)))
        return out
    def nodes(s):
        res=[]
        def walk(i,P,path):
            n=s.g['nodes'][i]; M=P@local(n); nm=n.get('name',str(i))
            if 'mesh' in n: res.append((nm,M,n['mesh']))
            for c in n.get('children',[]): walk(c,M,path+'/'+nm)
        for r in s.g['scenes'][s.g.get('scene',0)]['nodes']: walk(r,np.eye(4),'')
        return res
    def image(s,i):
        if i in s.images: return s.images[i]
        im=Image.open(os.path.join(s.dir,s.g['images'][i]['uri'])).convert('RGBA'); s.images[i]=im; return im
    def mat_color(s,mi):
        m=s.g['materials'][mi] if s.g.get('materials') else {}
        pbr=m.get('pbrMetallicRoughness',{})
        f=pbr.get('baseColorFactor',[1,1,1,1]); tex=pbr.get('baseColorTexture')
        img=None
        if tex is not None:
            t=s.g['textures'][tex['index']]; img=s.image(t['source'])
        return f,img
def components(pos,idx,tol=1e-3):
    key=np.round(pos/tol).astype(np.int64)
    _,inv=np.unique(key,axis=0,return_inverse=True)
    inv=inv.reshape(-1)
    f=inv[idx]  # welded ids
    n=inv.max()+1
    r=np.concatenate([f[:,0],f[:,1]]); c=np.concatenate([f[:,1],f[:,2]])
    g=coo_matrix((np.ones(len(r)),(r,c)),shape=(n,n))
    k,lab=connected_components(g,directed=False)
    return k,lab[f[:,0]]   # label per triangle
def render(parts,pk,size=180,az=35,el=22):
    # parts: list of prim dicts (world pos) ; returns PIL image
    allp=np.concatenate([p['pos'] for p in parts]); c=(allp.min(0)+allp.max(0))/2; ext=(allp.max(0)-allp.min(0)).max()+1e-9
    a=np.radians(az); e=np.radians(el)
    Ry=np.array([[np.cos(a),0,np.sin(a)],[0,1,0],[-np.sin(a),0,np.cos(a)]])
    Rx=np.array([[1,0,0],[0,np.cos(e),-np.sin(e)],[0,np.sin(e),np.cos(e)]])
    R=Rx@Ry
    tris=[]
    for p in parts:
        f,img=pk.mat_color(p['mat'])
        q=((p['pos']-c)@R.T)/ext
        for t in p['idx']:
            v=q[t]; d=v[:,2].mean()
            nrm=np.cross(v[1]-v[0],v[2]-v[0]); ln=np.linalg.norm(nrm)
            sh=0.6+0.4*abs(nrm[2]/ln) if ln>0 else 0.8
            if img is not None and p['uv'] is not None:
                uvc=p['uv'][t].mean(0); x=int((uvc[0]%1)*(img.width-1)); y=int((uvc[1]%1)*(img.height-1)); col=img.getpixel((x,y))[:3]
            else: col=tuple(int(255*min(1,max(0,x))) for x in f[:3])
            col=tuple(int(cc*sh) for cc in col)
            tris.append((d,[(size/2+v[k][0]*size*0.85, size*0.9-(v[k][1]+0.5)*size*0.85) for k in range(3)],col))
    tris.sort(key=lambda x:x[0])
    im=Image.new('RGB',(size,size),(215,225,235)); dr=ImageDraw.Draw(im)
    for d,pts,col in tris: dr.polygon(pts,fill=col)
    return im
def montage(items,cols=6,size=180,path='m.png'):
    rows=(len(items)+cols-1)//cols
    M=Image.new('RGB',(cols*size,rows*(size+14)),(255,255,255)); dr=ImageDraw.Draw(M)
    for i,(label,im) in enumerate(items):
        x=(i%cols)*size; y=(i//cols)*(size+14); M.paste(im,(x,y+14)); dr.text((x+2,y+1),label[:28],fill=(0,0,0))
    M.save(path)
