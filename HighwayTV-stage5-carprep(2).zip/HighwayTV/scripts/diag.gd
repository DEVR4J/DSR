extends Control
## SCRIPT CHECK: loads every game script and reports which ones fail to compile
## on this device, plus whether the autoloads are alive. Photograph this screen
## if something is broken.

const SCRIPTS := ["player_state", "game_input", "game_state", "car_spec", "obj_loader", "car_importer", "car_optimizer",
	"qr_code", "controller_page", "car_lights", "horn_synth", "phone_server", "vehicle", "world", "chase_camera", "hud", "main",
	"importer", "prep_screen", "phone_screen", "menu"]


func _ready() -> void:
	var bg := ColorRect.new()
	bg.color = Color(0.04, 0.05, 0.07)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var title := Label.new()
	title.text = "SCRIPT CHECK"
	title.add_theme_font_size_override("font_size", 48)
	title.position = Vector2(80, 40)
	add_child(title)

	var lines: PackedStringArray = []
	var bad := 0
	for n in SCRIPTS:
		var path := "res://scripts/%s.gd" % n
		var sc: Variant = load(path)
		var ok: bool = sc != null and sc is GDScript and (sc as GDScript).can_instantiate()
		if not ok:
			bad += 1
		lines.append("%s   %s" % ["OK    " if ok else "FAILED", n + ".gd"])
	for a in ["GameInput", "GameState", "PhoneServer"]:
		var alive := get_node_or_null("/root/" + a) != null
		if not alive:
			bad += 1
		lines.append("%s   autoload %s" % ["OK    " if alive else "FAILED", a])

	var l := Label.new()
	l.position = Vector2(80, 130)
	l.size = Vector2(1000, 900)
	l.add_theme_font_size_override("font_size", 28)
	l.text = "\n".join(lines)
	add_child(l)
	var summary := Label.new()
	summary.position = Vector2(1150, 160)
	summary.size = Vector2(700, 400)
	summary.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	summary.add_theme_font_size_override("font_size", 36)
	summary.text = "ALL SCRIPTS LOADED" if bad == 0 else "%d PROBLEM(S)\n\nSend a photo of this screen to the developer." % bad
	add_child(summary)

	var b := Button.new()
	b.text = "BACK"
	b.position = Vector2(1150, 700)
	b.custom_minimum_size = Vector2(380, 80)
	b.add_theme_font_size_override("font_size", 32)
	b.pressed.connect(_back)
	add_child(b)
	b.grab_focus()
	GameInput.back_pressed.connect(_back)


func _exit_tree() -> void:
	if GameInput.back_pressed.is_connected(_back):
		GameInput.back_pressed.disconnect(_back)


func _back() -> void:
	GameState.goto("res://scenes/menu.tscn")
