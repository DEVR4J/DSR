extends Control
## CAR PREP: pick a downloaded car model (.zip/.glb/.gltf/.obj), optimize it
## (triangles + textures), balance its handling, then send it to the TV
## (phone -> TV over Wi-Fi) or save a copy. Works by touch or D-pad.

const STAGE_ROOT := "user://prep"
const OUT_DIR := "user://prep_out"
const CFG := "user://prep.cfg"

var _list: VBoxContainer
var _status: Label
var _bar: ProgressBar
var _addr: LineEdit
var _fd: FileDialog

var _q := 1
var _balance := true
var _root: Node3D
var _rep: Dictionary = {}
var _model_path := ""
var _name := "car"
var _thread: Thread
var _busy := false
var _report: Dictionary = {}
var _out_zip := ""
var _prep_info: Dictionary = {}


func _ready() -> void:
	var bg := ColorRect.new()
	bg.color = Color(0.05, 0.06, 0.08)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var title := Label.new()
	title.text = "CAR PREP  -  optimize & balance a car model"
	title.add_theme_font_size_override("font_size", 44)
	title.position = Vector2(60, 24)
	add_child(title)

	_status = Label.new()
	_status.position = Vector2(60, 120)
	_status.size = Vector2(980, 780)
	_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_status.add_theme_font_size_override("font_size", 28)
	add_child(_status)
	_bar = ProgressBar.new()
	_bar.position = Vector2(60, 930)
	_bar.size = Vector2(980, 36)
	_bar.max_value = 1.0
	add_child(_bar)

	var scroll := ScrollContainer.new()
	scroll.position = Vector2(1090, 40)
	scroll.size = Vector2(790, 1000)
	scroll.follow_focus = true
	add_child(scroll)
	_list = VBoxContainer.new()
	_list.custom_minimum_size = Vector2(760, 0)
	_list.add_theme_constant_override("separation", 8)
	scroll.add_child(_list)

	_row(_t_const.bind("1. PICK MODEL (.zip .glb .gltf .obj)"), Callable(), _pick)
	_row(_t_quality, _adj_quality)
	_row(_t_balance, _adj_balance, _adj_balance.bind(1))
	_row(_t_const.bind("2. OPTIMIZE"), Callable(), _optimize)
	_addr = _field("TV address, e.g. 192.168.1.20:8080 (shown on the TV: PHONE CONTROLLER)")
	_row(_t_const.bind("3. SEND TO TV"), Callable(), _send)
	_row(_t_const.bind("SAVE A COPY..."), Callable(), _save_copy)
	_row(_t_const.bind("BACK"), Callable(), _back)

	var cf := ConfigFile.new()
	if cf.load(CFG) == OK:
		_addr.text = str(cf.get_value("tv", "addr", ""))
	if DirAccess.dir_exists_absolute(STAGE_ROOT):
		CarSpec.remove_dir(STAGE_ROOT)
	DirAccess.make_dir_recursive_absolute(OUT_DIR)
	_refresh()
	(_list.get_child(0) as Control).grab_focus()
	_set_status("Download a car model (zip is fine), then:\n1. PICK MODEL\n2. OPTIMIZE (shrinks triangles and textures, sets balanced handling)\n"
		+ "3. Open PHONE CONTROLLER on the TV, type its address here and SEND TO TV.\n"
		+ "On the TV: IMPORT CUSTOM CAR > APP / PHONE UPLOAD FILE.")
	GameInput.back_pressed.connect(_back)


func _exit_tree() -> void:
	if _thread != null and _thread.is_started():
		_thread.wait_to_finish()
	if GameInput.back_pressed.is_connected(_back):
		GameInput.back_pressed.disconnect(_back)


func _process(_d: float) -> void:
	if _busy:
		_bar.value = CarOptimizer.progress
		_status.text = "Working... %s" % CarOptimizer.progress_text


func _set_status(t: String) -> void:
	_status.text = t


# --------------------------------------------------------------------- rows
func _row(text_fn: Callable, adjust_fn: Callable = Callable(), press_fn: Callable = Callable()) -> void:
	var b := Button.new()
	b.custom_minimum_size = Vector2(0, 72)
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.add_theme_font_size_override("font_size", 28)
	b.set_meta("text_fn", text_fn)
	b.set_meta("adjust", adjust_fn)
	b.set_meta("press", press_fn)
	b.pressed.connect(_on_pressed.bind(b))
	b.gui_input.connect(_on_input.bind(b))
	_list.add_child(b)


func _field(hint: String) -> LineEdit:
	var e := LineEdit.new()
	e.placeholder_text = hint
	e.custom_minimum_size = Vector2(0, 72)
	e.add_theme_font_size_override("font_size", 28)
	_list.add_child(e)
	return e


func _on_pressed(b: Button) -> void:
	if _busy:
		return
	var f: Callable = b.get_meta("press")
	if f.is_valid():
		f.call()
	_refresh()


func _on_input(ev: InputEvent, b: Button) -> void:
	var d := 0
	if ev.is_action_pressed("ui_left", true):
		d = -1
	elif ev.is_action_pressed("ui_right", true):
		d = 1
	var f: Callable = b.get_meta("adjust")
	if d != 0 and f.is_valid():
		f.call(d)
		b.accept_event()
		_refresh()


func _refresh() -> void:
	for c in _list.get_children():
		if c is Button:
			c.text = (c.get_meta("text_fn") as Callable).call()


func _t_const(s: String) -> String:
	return s


func _t_quality() -> String:
	var p: Dictionary = CarOptimizer.PROFILES[_q]
	return "QUALITY   <  %s  >   %dk tris, %d px" % [p["name"], int(p["tris"]) / 1000, p["tex"]]


func _adj_quality(d: int) -> void:
	_q = wrapi(_q + d, 0, CarOptimizer.PROFILES.size())


func _t_balance() -> String:
	return "BALANCE HANDLING   <  %s  >" % ("ON" if _balance else "OFF")


func _adj_balance(_d: int) -> void:
	_balance = not _balance


# --------------------------------------------------------------- pick/load
func _pick() -> void:
	if DisplayServer.has_feature(DisplayServer.FEATURE_NATIVE_DIALOG_FILE):
		DisplayServer.file_dialog_show("Select car model", "", "", false,
				DisplayServer.FILE_DIALOG_MODE_OPEN_FILES, PackedStringArray(), _on_native_files)
	else:
		if _fd == null:
			_fd = FileDialog.new()
			_fd.access = FileDialog.ACCESS_FILESYSTEM
			_fd.file_mode = FileDialog.FILE_MODE_OPEN_FILES
			_fd.use_native_dialog = false
			_fd.files_selected.connect(_load_paths)
			add_child(_fd)
		_fd.popup_centered_ratio(0.8)


func _on_native_files(ok: bool, paths: PackedStringArray, _f: int) -> void:
	if ok and paths.size() > 0:
		_load_paths.call_deferred(paths)


func _load_paths(paths: PackedStringArray) -> void:
	_set_status("Importing...")
	await get_tree().process_frame
	_free_model()
	if DirAccess.dir_exists_absolute(STAGE_ROOT):
		CarSpec.remove_dir(STAGE_ROOT)
	var st := CarImporter.stage_files(paths, STAGE_ROOT)
	if not st["ok"]:
		_set_status("Import failed: " + str(st["error"]))
		return
	_model_path = st["model"]
	_name = _safe(str(st["name"]))
	if not _open_model():
		return
	var s := CarOptimizer.stats(_root)
	_set_status("Loaded %s\n\nTriangles: %s\nMeshes: %d\nTextures: %d (about %.0f MB on the GPU)\nLength: %.1f m   Wheels found: %d/4\nSuggested class: %s\n\nPress OPTIMIZE."
		% [_name, _fmt(s["tris"]), s["meshes"], s["textures"], s["tex_mb"], _rep["length"], _rep["wheels_found"],
		CarOptimizer.balance(_rep)["class"]])


func _open_model() -> bool:
	var node := CarImporter.load_model(_model_path)
	if node == null:
		_set_status("Import failed: " + CarImporter.last_error)
		return false
	_root = node
	_rep = CarImporter.analyze(_root)
	if not _rep["ok"]:
		_set_status("Import failed: " + str(_rep["error"]))
		_free_model()
		return false
	return true


func _free_model() -> void:
	if _root != null:
		_root.free()
		_root = null


func _safe(s: String) -> String:
	var out := ""
	for ch in s.replace(" ", "_"):
		if ch.is_valid_identifier() or ch == "-" or (ch.unicode_at(0) > 47 and ch.unicode_at(0) < 58):
			out += ch
	return out if out != "" else "car"


func _fmt(n: int) -> String:
	return "%.1fk" % (n / 1000.0) if n >= 1000 else str(n)


# ----------------------------------------------------------------- optimize
func _optimize() -> void:
	if _model_path == "":
		_set_status("Pick a model first.")
		return
	_set_status("Preparing model...")
	await get_tree().process_frame
	_free_model()
	if not _open_model():          # fresh copy each time so you can try other qualities
		return
	_busy = true
	CarOptimizer.progress = 0.0
	_thread = Thread.new()
	_thread.start(_work)


func _work() -> void:
	_report = CarOptimizer.run(_root, CarOptimizer.PROFILES[_q])
	_work_done.call_deferred()


func _work_done() -> void:
	_thread.wait_to_finish()
	_thread = null
	_status.text = "Packing the optimized car..."
	await get_tree().process_frame
	_export()
	_busy = false
	_bar.value = 1.0
	_refresh()


func _export() -> void:
	# Bake orientation/scale into a wrapper so the TV sees a clean, upright car facing -Z.
	var wrapper := Node3D.new()
	wrapper.name = "CarRoot"
	var model := Node3D.new()
	model.name = "Model"
	var spec := {"rot": _rep["rot"], "scale": _rep["scale"], "offset": _rep["offset"]}
	CarImporter.apply_transform(model, spec)
	_root.transform = Transform3D.IDENTITY
	for c in _root.get_children():
		_root.remove_child(c)
		model.add_child(c)
	wrapper.add_child(model)
	var dir := "%s/%s" % [OUT_DIR, _name]
	DirAccess.make_dir_recursive_absolute(dir)
	var glb := dir + "/model.glb"
	var err := _write_glb(wrapper, glb)
	wrapper.free()
	_root.free()
	_root = null
	if err != OK:
		_set_status("Could not write the optimized model (error %d)." % err)
		return
	var bal := CarOptimizer.balance(_rep)
	var prep := {"version": 1, "oriented": true, "name": _name, "class": bal["class"]}
	if _balance:
		prep["params"] = bal["params"]
	var pj := dir + "/carprep.json"
	var f := FileAccess.open(pj, FileAccess.WRITE)
	f.store_string(JSON.stringify(prep, "\t"))
	f.close()
	_out_zip = "%s/%s_prep.zip" % [OUT_DIR, _name]
	if not _zip([glb, pj], ["model.glb", "carprep.json"], _out_zip):
		_set_status("Could not create the ZIP package.")
		return
	var b: Dictionary = _report["before"]
	var a: Dictionary = _report["after"]
	var size_mb := FileAccess.get_file_as_bytes(_out_zip).size() / 1048576.0
	_set_status("Done: %s_prep.zip (%.1f MB)\n\nTriangles: %s -> %s\nTextures: %d (%.0f MB GPU) -> %d (%.0f MB GPU)\nHandling class: %s%s\n\nNow SEND TO TV."
		% [_name, size_mb, _fmt(b["tris"]), _fmt(a["tris"]), b["textures"], b["tex_mb"], a["textures"], a["tex_mb"],
		bal["class"], " (balanced)" if _balance else " (handling left to the importer)"])


func _write_glb(root: Node3D, path: String) -> int:
	for fmt in ["Lossy WebP", "PNG"]:
		var doc := GLTFDocument.new()
		doc.image_format = fmt
		doc.lossy_quality = 0.85
		var st := GLTFState.new()
		var e := doc.append_from_scene(root, st)
		if e == OK:
			e = doc.write_to_filesystem(st, path)
		if e == OK:
			return OK
	return FAILED


func _zip(files: Array, names: Array, out: String) -> bool:
	var zp := ZIPPacker.new()
	if zp.open(out) != OK:
		return false
	for i in files.size():
		zp.start_file(names[i])
		zp.write_file(FileAccess.get_file_as_bytes(files[i]))
		zp.close_file()
	zp.close()
	return true


# ---------------------------------------------------------------- send/save
func _send() -> void:
	if _out_zip == "" or not FileAccess.file_exists(_out_zip):
		_set_status("Optimize a car first.")
		return
	var addr := _addr.text.strip_edges().replace("http://", "").trim_suffix("/")
	if addr == "":
		_set_status("Type the TV address (shown on the TV: PHONE CONTROLLER).")
		return
	if not addr.contains(":"):
		addr += ":8080"
	var cf := ConfigFile.new()
	cf.set_value("tv", "addr", addr)
	cf.save(CFG)
	var bytes := FileAccess.get_file_as_bytes(_out_zip)
	var http := HTTPRequest.new()
	http.timeout = 90.0
	add_child(http)
	var url := "http://%s/upload?name=%s" % [addr, _out_zip.get_file().uri_encode()]
	var err := http.request_raw(url, PackedStringArray(["Content-Type: application/octet-stream"]),
			HTTPClient.METHOD_POST, bytes)
	if err != OK:
		_set_status("Could not start sending (error %d). Check the address." % err)
		http.queue_free()
		return
	_set_status("Sending %.1f MB to the TV..." % (bytes.size() / 1048576.0))
	var res: Array = await http.request_completed
	http.queue_free()
	if res[0] == HTTPRequest.RESULT_SUCCESS and res[1] == 200:
		_set_status("Sent! On the TV open IMPORT CUSTOM CAR and use the APP / PHONE UPLOAD FILE row.")
	elif res[1] == 403:
		_set_status("The TV refused the upload. Open PHONE CONTROLLER on the TV first, then try again.")
	else:
		_set_status("Send failed (network %d, HTTP %d). Same Wi-Fi? Address correct?" % [res[0], res[1]])


func _save_copy() -> void:
	if _out_zip == "" or not FileAccess.file_exists(_out_zip):
		_set_status("Optimize a car first.")
		return
	DisplayServer.file_dialog_show("Save optimized car", "", _out_zip.get_file(), false,
			DisplayServer.FILE_DIALOG_MODE_SAVE_FILE, PackedStringArray(), _on_save)


func _on_save(ok: bool, paths: PackedStringArray, _f: int) -> void:
	if not ok or paths.is_empty():
		return
	var f := FileAccess.open(paths[0], FileAccess.WRITE)
	if f == null:
		_set_status.call_deferred("Could not write to that location.")
		return
	f.store_buffer(FileAccess.get_file_as_bytes(_out_zip))
	f.close()
	_set_status.call_deferred("Saved a copy.")


func _back() -> void:
	if _busy:
		return
	GameState.goto("res://scenes/menu.tscn")
