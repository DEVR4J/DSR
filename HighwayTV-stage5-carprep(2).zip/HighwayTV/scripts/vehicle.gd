class_name HighwayCar
extends VehicleBody3D
## Drivable car built on Godot's raycast vehicle, with an engine/gearbox layer,
## speed-sensitive steering, ABS, traction control, aero and per-surface grip.
## The car faces -Z. Everything is built in code so Stage 3 can later swap the
## visual mesh for an imported GLB and feed these exported values from a config.

signal gear_changed(new_gear: int)

@export_group("Chassis")
@export var car_mass := 1350.0
@export var wheel_radius := 0.34
@export var wheel_width := 0.24
@export var wheelbase := 2.7
@export var track_width := 1.6
@export_group("Suspension")
@export var susp_rest_length := 0.25
@export var susp_travel := 0.2
@export var susp_stiffness := 28.0     # per-kg in Godot's model
@export var damp_compression := 0.45   # 0..1 of critical
@export var damp_relaxation := 0.65
@export var roll_influence := 0.10     # low = harder to roll over
@export_group("Tyres")
@export var grip_front := 1.3
@export var grip_rear := 1.2
@export var handbrake_rear_grip := 0.5
@export_group("Steering")
@export var max_steer_deg := 30.0
@export var steer_speed_ref := 12.0    # m/s at which lock is roughly 1/2
@export_group("Engine / gearbox")
@export var peak_torque := 340.0       # Nm
@export var idle_rpm := 900.0
@export var redline_rpm := 6800.0
@export var forward_ratios: Array[float] = [3.5, 2.1, 1.45, 1.05, 0.8, 0.65]
@export var reverse_ratio := 3.4
@export var final_drive := 3.9
@export var drivetrain_eff := 0.88
@export var upshift_rpm := 6200.0
@export var engine_brake_n := 900.0
@export_group("Brakes / aero")
@export var brake_per_kg := 0.03       # Godot brake units per kg (docs: ~25-30 per 1000 kg)
@export var drag_cd_a := 0.70          # Cd * frontal area (m^2)
@export var downforce_coeff := 0.35
@export var abs_enabled := true
@export var traction_control := true

# --- live state (read by HUD / camera) ---
var automatic := true
var gear := 1                  # -1 reverse, 0 neutral, 1..N
var engine_rpm := 900.0
var speed_ms := 0.0            # signed, forward positive
var speed_kmh := 0.0           # absolute
var weather_grip := 1.0
var last_0_100 := 0.0

## Custom car description (from CarSpec). Empty = built-in car.
var spec: Dictionary = {}
var custom_failed := false
## Whose controls/lights this car uses (set before add_child; default = player 1).
var pstate: PlayerState
var paint_color := Color(0.75, 0.05, 0.07)
var braking_visual := false
var light_parts := {"head": [], "tail": [], "reverse": [], "ind_l": [], "ind_r": []}
var lights: CarLights
var hood_cam_pos := Vector3(0, 0.95, -0.25)
var cockpit_cam_pos := Vector3(-0.35, 0.58, 0.25)    # driver's eyes
var car_length := 4.3

var _wheels: Array[VehicleWheel3D] = []
var _rear: Array[VehicleWheel3D] = []
var _steer := 0.0
var _shift_timer := 0.0
var _abs_factor := 1.0
var _rear_surface := 1.0
var _t100 := -1.0
var _tail_mat: StandardMaterial3D
var _steer_pivot: Node3D
var _steer_axis := Vector3.BACK
var _horn: AudioStreamPlayer
var _light_front := Vector3(0.62, 0.15, -2.15)     # lamp half-width, height, front z


func _ready() -> void:
	if pstate == null:
		pstate = GameState.players[0]
	var custom := not spec.is_empty()
	if custom:
		_apply_spec_params()
	mass = car_mass
	center_of_mass_mode = RigidBody3D.CENTER_OF_MASS_MODE_CUSTOM
	center_of_mass = Vector3(0, -0.15, 0)
	angular_damp = 0.4
	continuous_cd = true
	engine_rpm = idle_rpm
	if not (custom and _build_custom()):
		custom_failed = custom
		if custom_failed:
			_reset_default_params()
		_build_collision()
		_build_body()
		_build_wheels()
		_build_default_steering_wheel()
	_setup_lights_and_horn()
	pstate.gear_up_pressed.connect(shift_up)
	pstate.gear_down_pressed.connect(shift_down)
	pstate.gearbox_toggle_pressed.connect(_toggle_gearbox)


func _apply_spec_params() -> void:
	var d := CarSpec.defaults()
	d.merge(spec, true)
	car_mass = float(d["mass"])
	wheel_radius = float(d["radius"])
	wheelbase = float(d["wheelbase"])
	track_width = float(d["track"])
	susp_rest_length = float(d["susp_rest"])
	susp_stiffness = float(d["susp_stiffness"])
	damp_compression = float(d["damp_comp"])
	damp_relaxation = float(d["damp_rel"])
	max_steer_deg = float(d["max_steer"])
	peak_torque = float(d["peak_torque"])
	redline_rpm = float(d["redline"])
	upshift_rpm = redline_rpm * 0.91
	brake_per_kg = float(d["brake_per_kg"])
	automatic = bool(d["automatic"])
	forward_ratios.assign(CarSpec.ratios(int(d["gears"])))
	final_drive = float(d["final_drive"])
	grip_front = float(d["grip_front"])
	grip_rear = float(d["grip_rear"])
	drag_cd_a = float(d["drag_cd_a"])


func _reset_default_params() -> void:
	car_mass = 1350.0
	wheel_radius = 0.34
	wheelbase = 2.7
	track_width = 1.6
	susp_rest_length = 0.25
	susp_stiffness = 28.0
	mass = car_mass


## Builds the car from an imported model. Returns false (before touching the
## scene) if the model cannot be loaded, so the caller can fall back.
func _build_custom() -> bool:
	var model := CarImporter.load_model(str(spec.get("model_file", "")))
	if model == null:
		push_warning("Custom car failed to load: " + CarImporter.last_error)
		return false
	CarImporter.apply_transform(model, spec)
	add_child(model)

	var bp := CarSpec.v3(spec["body_pos"])
	var bs := CarSpec.v3(spec["body_size"])
	var bottom := maxf(bp.y, -wheel_radius + 0.25)
	var top := bp.y + bs.y
	var h := maxf(top - bottom, 0.3)
	var cs := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(bs.x * 0.92, h, bs.z * 0.95)
	cs.shape = box
	cs.position = Vector3(bp.x + bs.x * 0.5, bottom + h * 0.5, bp.z + bs.z * 0.5)
	add_child(cs)
	center_of_mass = Vector3(0, lerpf(bottom, top, 0.2), 0)
	hood_cam_pos = Vector3(0, top - 0.2, bp.z + bs.z * 0.35)
	if spec.has("cockpit"):
		cockpit_cam_pos = CarSpec.v3(spec["cockpit"])
	else:
		cockpit_cam_pos = Vector3(-0.32, lerpf(bottom, top, 0.72), bp.z + bs.z * 0.55)
	_light_front = Vector3(bs.x * 0.3, lerpf(bottom, top, 0.3), bp.z + 0.1)
	car_length = bs.z

	var hx := track_width * 0.5
	var hz := wheelbase * 0.5
	var attach_y := maxf(susp_rest_length - 9.8 / (4.0 * susp_stiffness), 0.02)
	var vis: Array = spec["wheel_vis_pos"]
	var groups: Dictionary = spec["wheels"]
	for n in 4:
		var key: String = CarImporter.CORNERS[n]
		var sx := -1.0 if n % 2 == 0 else 1.0
		var sz := -1.0 if n < 2 else 1.0
		var w := _make_wheel("Wheel" + key.to_upper(), CarSpec.v3(vis[n]), n < 2, n >= 2, false)
		for pth in groups.get(key, []):
			var nd := model.get_node_or_null(NodePath(str(pth)))
			if nd != null:
				nd.reparent(w, true)      # keeps its place; now spins/steers with the wheel
		w.position = Vector3(sx * hx, attach_y, sz * hz)
	_collect_light_parts(model)
	_setup_steering_wheel(model)
	return true


# ------------------------------------------------------------------ building
func _build_collision() -> void:
	var main := CollisionShape3D.new()
	var b1 := BoxShape3D.new()
	b1.size = Vector3(1.8, 0.55, 4.3)
	main.shape = b1
	main.position = Vector3(0, 0.05, 0)
	add_child(main)
	var cab := CollisionShape3D.new()
	var b2 := BoxShape3D.new()
	b2.size = Vector3(1.5, 0.5, 1.9)
	cab.shape = b2
	cab.position = Vector3(0, 0.6, 0.35)
	add_child(cab)


func _mat(color: Color, metallic := 0.0, rough := 0.6) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.metallic = metallic
	m.roughness = rough
	return m


func _box(size: Vector3, pos: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.position = pos
	mi.material_override = mat
	add_child(mi)
	return mi


func _build_body() -> void:
	var paint := _mat(paint_color, 0.75, 0.28)
	paint.clearcoat_enabled = true
	paint.clearcoat = 1.0
	paint.clearcoat_roughness = 0.08
	var glass := _mat(Color(0.03, 0.05, 0.08), 0.9, 0.05)
	var dark := _mat(Color(0.05, 0.05, 0.06), 0.2, 0.7)
	_box(Vector3(1.8, 0.55, 4.3), Vector3(0, 0.05, 0), paint)
	_box(Vector3(1.5, 0.5, 1.9), Vector3(0, 0.6, 0.35), glass)
	_box(Vector3(1.46, 0.06, 1.4), Vector3(0, 0.87, 0.35), paint)
	_box(Vector3(1.7, 0.18, 0.12), Vector3(0, -0.12, -2.17), dark)   # front bumper
	_box(Vector3(1.7, 0.18, 0.12), Vector3(0, -0.12, 2.17), dark)    # rear bumper
	var head := _mat(Color(0.85, 0.85, 0.8), 0.3, 0.2)
	_tail_mat = _mat(Color(0.35, 0.0, 0.0), 0.2, 0.3)
	var amber := _mat(Color(0.5, 0.28, 0.0), 0.1, 0.3)
	for sx: float in [-1.0, 1.0]:
		light_parts["head"].append(_box(Vector3(0.38, 0.12, 0.05), Vector3(0.62 * sx, 0.15, -2.16), head))
		light_parts["tail"].append(_box(Vector3(0.42, 0.10, 0.05), Vector3(0.64 * sx, 0.2, 2.16), _tail_mat))
		var side := "ind_l" if sx < 0.0 else "ind_r"
		light_parts[side].append(_box(Vector3(0.16, 0.08, 0.05), Vector3(0.84 * sx, 0.1, -2.16), amber))
		light_parts[side].append(_box(Vector3(0.16, 0.08, 0.05), Vector3(0.84 * sx, 0.12, 2.16), amber))


func _build_wheels() -> void:
	var hx := track_width * 0.5
	var hz := wheelbase * 0.5
	_make_wheel("WheelFL", Vector3(-hx, 0.15, -hz), true, false)
	_make_wheel("WheelFR", Vector3(hx, 0.15, -hz), true, false)
	_make_wheel("WheelRL", Vector3(-hx, 0.15, hz), false, true)
	_make_wheel("WheelRR", Vector3(hx, 0.15, hz), false, true)


func _make_wheel(wname: String, pos: Vector3, steer: bool, traction: bool, with_mesh := true) -> VehicleWheel3D:
	var w := VehicleWheel3D.new()
	w.name = wname
	w.position = pos
	w.use_as_steering = steer
	w.use_as_traction = traction
	w.wheel_radius = wheel_radius
	w.wheel_rest_length = susp_rest_length
	w.suspension_travel = susp_travel
	w.suspension_stiffness = susp_stiffness
	w.suspension_max_force = car_mass * 20.0
	w.damping_compression = damp_compression
	w.damping_relaxation = damp_relaxation
	w.wheel_roll_influence = roll_influence
	w.wheel_friction_slip = grip_front if steer else grip_rear
	if with_mesh:
		var tyre := MeshInstance3D.new()
		var cm := CylinderMesh.new()
		cm.top_radius = wheel_radius
		cm.bottom_radius = wheel_radius
		cm.height = wheel_width
		cm.radial_segments = 24
		tyre.mesh = cm
		tyre.rotation_degrees = Vector3(0, 0, 90)
		tyre.material_override = _mat(Color(0.05, 0.05, 0.05), 0.0, 0.9)
		w.add_child(tyre)
		var rim := MeshInstance3D.new()
		var rm := CylinderMesh.new()
		rm.top_radius = wheel_radius * 0.62
		rm.bottom_radius = wheel_radius * 0.62
		rm.height = wheel_width + 0.02
		rm.radial_segments = 12
		rim.mesh = rm
		rim.rotation_degrees = Vector3(0, 0, 90)
		rim.material_override = _mat(Color(0.75, 0.77, 0.8), 1.0, 0.25)
		w.add_child(rim)
	add_child(w)
	_wheels.append(w)
	if traction:
		_rear.append(w)
	return w


# ------------------------------------------------------------------- physics
func _physics_process(delta: float) -> void:
	var fwd := -global_transform.basis.z
	speed_ms = linear_velocity.dot(fwd)
	speed_kmh = absf(speed_ms) * 3.6

	var thr := pstate.throttle
	var brk := pstate.brake
	var hb := pstate.handbrake

	_update_gear_direction(thr, brk)
	var drive_in := thr
	if automatic and gear == -1:     # reverse: Down = accelerate, Up = brake
		drive_in = brk
		brk = thr

	_update_wheel_grip()
	_apply_drive(delta, drive_in, brk, hb)
	_apply_steering(delta)
	_update_steering_wheel()
	_apply_aero()
	_track_0_100(delta, thr)
	braking_visual = maxf(brk, hb) > 0.05
	pstate.speed_kmh = speed_kmh
	pstate.gear_text = gear_label()


func _total_ratio() -> float:
	if gear >= 1:
		return forward_ratios[gear - 1] * final_drive
	if gear == -1:
		return reverse_ratio * final_drive
	return 0.0


func _driven_wheel_rpm() -> float:
	var s := 0.0
	for w in _rear:
		s += absf(w.get_rpm())
	return s / maxf(1.0, _rear.size())


func _torque_curve(rpm: float) -> float:
	var n := clampf(rpm / redline_rpm, 0.0, 1.2)
	return clampf((0.55 + 1.2 * n - 1.1 * n * n) / 0.877, 0.0, 1.0)


func _apply_drive(delta: float, thr: float, brk: float, hb: float) -> void:
	var ratio := _total_ratio()
	var wheel_rpm := _driven_wheel_rpm()
	var target := idle_rpm + thr * 2500.0
	if gear == 0:
		target = idle_rpm + thr * (redline_rpm - idle_rpm)
	else:
		target = maxf(target, wheel_rpm * ratio)
	engine_rpm = clampf(lerpf(engine_rpm, target, clampf(12.0 * delta, 0.0, 1.0)),
			idle_rpm * 0.9, redline_rpm + 300.0)

	_shift_timer = maxf(0.0, _shift_timer - delta)
	if automatic and gear >= 1 and _shift_timer <= 0.0:
		if engine_rpm > upshift_rpm and gear < forward_ratios.size():
			set_gear(gear + 1)
		elif gear > 1 and engine_rpm < 2200.0 \
				and wheel_rpm * forward_ratios[gear - 2] * final_drive < 5200.0:
			set_gear(gear - 1)

	# Engine torque -> driving force in real Newtons, applied along the car's visual
	# forward axis (-Z). Godot's own engine_force has an unclear unit and sign, so it
	# is not used (this also fixes drive/reverse pushing the wrong way).
	var torque := peak_torque * _torque_curve(engine_rpm) * thr
	if engine_rpm >= redline_rpm or _shift_timer > 0.0:
		torque = 0.0
	var force_n := torque * ratio * drivetrain_eff / wheel_radius
	# Traction limit: the driven tyres cannot push harder than grip x load.
	var f_max := 1.1 * grip_rear * _rear_surface * weather_grip * 0.5 * car_mass * 9.8
	if not traction_control:
		f_max *= 1.25
	var drive := minf(force_n, f_max)
	var fwd := -global_transform.basis.z
	var max_brake := brake_per_kg * car_mass
	var braking := brk > 0.02 or hb > 0.1
	if _any_contact() and not braking:
		if gear >= 1:
			apply_central_force(fwd * drive)
		elif gear == -1:
			apply_central_force(-fwd * drive)
		if thr < 0.05 and gear >= 1 and speed_ms > 2.0:       # engine braking
			apply_central_force(-fwd * engine_brake_n * (engine_rpm / redline_rpm))
	engine_force = 0.0

	# ABS: back off brake pressure when a wheel locks
	var skid := 1.0
	if abs_enabled and brk > 0.1 and speed_kmh > 10.0:
		for w in _wheels:
			skid = minf(skid, w.get_skidinfo())
	_abs_factor = lerpf(_abs_factor, 0.55 if skid < 0.7 else 1.0, clampf(20.0 * delta, 0.0, 1.0))
	brake = brk * max_brake * _abs_factor + hb * 0.3 * max_brake


func _apply_steering(delta: float) -> void:
	var v := absf(speed_ms)
	var lock := maxf(max_steer_deg / (1.0 + pow(v / steer_speed_ref, 2.0)), 3.0)
	var target := -pstate.steer * deg_to_rad(lock)   # +steering = left in Godot
	_steer = lerpf(_steer, target, clampf(9.0 * delta, 0.0, 1.0))
	steering = _steer


func _apply_aero() -> void:
	var v := linear_velocity
	var sp := v.length()
	if sp < 0.5:
		return
	apply_central_force(-v.normalized() * 0.6 * drag_cd_a * sp * sp)          # air drag
	apply_central_force(-v.normalized() * 0.012 * car_mass * 9.8)               # rolling resistance
	apply_central_force(-global_transform.basis.y * downforce_coeff * sp * sp)  # downforce


func _any_contact() -> bool:
	for w in _wheels:
		if w.is_in_contact():
			return true
	return false


func _update_wheel_grip() -> void:
	var rs := 1.0
	for w in _wheels:
		var base := grip_front if w.use_as_steering else grip_rear
		var surf := 1.0
		var b: Node = w.get_contact_body()
		if b != null and b.has_meta("grip"):
			surf = b.get_meta("grip")
		var hbf := 1.0
		if not w.use_as_steering:
			hbf = lerpf(1.0, handbrake_rear_grip, pstate.handbrake)
			rs = minf(rs, surf)
		w.wheel_friction_slip = base * surf * weather_grip * hbf
	_rear_surface = rs


func _update_gear_direction(thr: float, brk: float) -> void:
	if not automatic:
		return
	if gear >= 0 and speed_ms < 0.8 and brk > 0.1 and thr < 0.05:
		set_gear(-1)
	elif gear == -1 and speed_ms > -0.8 and thr > 0.1 and brk < 0.05:
		set_gear(1)


func set_gear(g: int) -> void:
	if g == gear:
		return
	gear = g
	_shift_timer = 0.25
	gear_changed.emit(g)


func _toggle_gearbox() -> void:
	if not get_tree().paused:
		automatic = not automatic


func shift_up() -> void:
	if get_tree().paused or automatic:
		return
	if gear < forward_ratios.size():
		set_gear(gear + 1)


func shift_down() -> void:
	if get_tree().paused or automatic:
		return
	if gear > -1 and not (gear == 0 and speed_ms > 2.0):
		set_gear(gear - 1)


func _track_0_100(delta: float, thr: float) -> void:
	if speed_kmh < 2.0:
		_t100 = 0.0 if thr > 0.5 else -1.0
	elif _t100 >= 0.0:
		_t100 += delta
		if speed_kmh >= 100.0:
			last_0_100 = _t100
			_t100 = -1.0


func reset_upright() -> void:
	var f := -global_transform.basis.z
	var yaw := atan2(-f.x, -f.z)
	global_transform = Transform3D(Basis(Vector3.UP, yaw), global_position + Vector3(0, 1.0, 0))
	linear_velocity = Vector3.ZERO
	angular_velocity = Vector3.ZERO


# ------------------------------------------------- lights, horn, steering wheel
func _setup_lights_and_horn() -> void:
	pstate.reset_lights()
	lights = CarLights.new()
	add_child(lights)
	lights.setup(self, _light_front, Vector3(0, cockpit_cam_pos.y + 0.1, cockpit_cam_pos.z - 0.3), light_parts, pstate)
	_horn = AudioStreamPlayer.new()
	_horn.stream = HornSynth.make()
	_horn.volume_db = -6.0
	add_child(_horn)
	pstate.horn_changed.connect(_on_horn)


func _on_horn(on: bool) -> void:
	if on and not get_tree().paused:
		if not _horn.playing:
			_horn.play()
	else:
		_horn.stop()


## Finds lamp meshes of an imported car by name (headlight, taillight, brake light,
## reverse light, indicator with left/right marker, fog light, ...).
func _collect_light_parts(model: Node) -> void:
	for mi in CarImporter.mesh_nodes(model):
		var toks := CarImporter._tokens(str(mi.name))
		var kind := _light_kind(toks)
		if kind == "":
			continue
		if kind == "ind":
			var side := _light_side(toks)
			if side <= 0:
				light_parts["ind_l"].append(mi)
			if side >= 0:
				light_parts["ind_r"].append(mi)
		else:
			light_parts[kind].append(mi)


func _light_side(toks: PackedStringArray) -> int:
	for t in toks:
		if t in ["lf", "lr", "l", "left", "lh"]:
			return -1
		if t in ["rf", "rr", "r", "right", "rh"]:
			return 1
	return 0


func _light_kind(toks: PackedStringArray) -> String:
	var ind := false
	var tail := false
	var rev := false
	var head := false
	var head_word := false
	var lightish := false
	var rear := false
	var front := false
	for t in toks:
		if t.begins_with("indicator") or t.begins_with("blinker") or t == "turn" or t == "signal":
			ind = true
		if t.begins_with("taillight") or t.begins_with("taillamp") or t == "tail" or t.begins_with("brakelight") \
				or t.begins_with("breaklight") or t == "stoplight":
			tail = true
		if t.begins_with("reverse") or t == "backup":
			rev = true
		if t.begins_with("headlight") or t.begins_with("headlamp") or t.begins_with("foglight") or t.begins_with("foglamp"):
			head = true
		if t == "head":
			head_word = true
		if t.begins_with("light") or t.begins_with("lamp"):
			lightish = true
		if t == "rear":
			rear = true
		if t == "front":
			front = true
	if ind:
		return "ind"
	if rev:
		return "reverse"
	if tail or (rear and lightish):
		return "tail"
	if head or (head_word and lightish) or (front and lightish):
		return "head"
	return ""


func _update_steering_wheel() -> void:
	if _steer_pivot != null:
		# ~14:1 steering ratio; _steer > 0 is a left turn = anticlockwise seen by the driver
		_steer_pivot.transform.basis = Basis(_steer_axis, _steer * 14.0)


func _build_default_steering_wheel() -> void:
	_steer_axis = Vector3(0, 0.42, 0.91).normalized()
	_steer_pivot = Node3D.new()
	_steer_pivot.position = Vector3(-0.35, 0.5, -0.12)
	add_child(_steer_pivot)
	var dark := _mat(Color(0.05, 0.05, 0.05), 0.0, 0.8)
	var ring := MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = 0.13
	tm.outer_radius = 0.17
	ring.mesh = tm
	ring.basis = Basis(Quaternion(Vector3.UP, _steer_axis))
	ring.material_override = dark
	_steer_pivot.add_child(ring)
	var bar := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.3, 0.02, 0.03)
	bar.mesh = bm
	bar.material_override = dark
	ring.add_child(bar)
	var mark := MeshInstance3D.new()
	var mm := BoxMesh.new()
	mm.size = Vector3(0.03, 0.025, 0.06)
	mark.mesh = mm
	mark.position = Vector3(0, 0, -0.15)
	mark.material_override = _mat(Color(0.9, 0.1, 0.1), 0.0, 0.5)
	ring.add_child(mark)


## Makes the model's own steering wheel turn with the steering input: it is
## re-parented under a pivot at its centre and rotated about its (PCA) normal.
func _setup_steering_wheel(model: Node3D) -> void:
	var meshes: Array[MeshInstance3D] = []
	for mi in CarImporter.mesh_nodes(model):
		for t in CarImporter._tokens(str(mi.name)):
			if t.begins_with("steer"):
				meshes.append(mi)
				break
	if meshes.is_empty():
		return
	var best: MeshInstance3D = meshes[0]
	var best_vol := -1.0
	var union := AABB()
	var first := true
	for mi in meshes:
		if mi.mesh == null:
			continue
		var a := CarImporter.mesh_aabb(mi, model)
		union = a if first else union.merge(a)
		first = false
		var vol := a.size.x * a.size.y * a.size.z
		if vol > best_vol:
			best_vol = vol
			best = mi
	if first:
		return
	var pts := _sample_points(best, model, 1500)
	if pts.size() < 10:
		return
	var axis := _plane_normal(pts)
	var center := union.get_center()
	if axis.dot(cockpit_cam_pos - center) < 0.0:
		axis = -axis
	_steer_axis = axis
	_steer_pivot = Node3D.new()
	_steer_pivot.position = center
	add_child(_steer_pivot)
	for mi in meshes:
		mi.reparent(_steer_pivot, true)


func _sample_points(mi: MeshInstance3D, model: Node, max_n: int) -> PackedVector3Array:
	var t := CarImporter.xform_to_root(mi, model)
	var out := PackedVector3Array()
	var m := mi.mesh
	for s in m.get_surface_count():
		var arr := m.surface_get_arrays(s)
		if arr.is_empty() or arr[Mesh.ARRAY_VERTEX] == null:
			continue
		var v: PackedVector3Array = arr[Mesh.ARRAY_VERTEX]
		var stride := maxi(1, v.size() / max_n)
		for i in range(0, v.size(), stride):
			out.append(t * v[i])
	return out


## Normal of the best-fit plane (smallest principal axis) of a point cloud.
func _plane_normal(pts: PackedVector3Array) -> Vector3:
	var mean := Vector3.ZERO
	for p in pts:
		mean += p
	mean /= float(pts.size())
	var c: Array[float] = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]      # xx xy xz yy yz zz
	for p in pts:
		var d := p - mean
		c[0] += d.x * d.x
		c[1] += d.x * d.y
		c[2] += d.x * d.z
		c[3] += d.y * d.y
		c[4] += d.y * d.z
		c[5] += d.z * d.z
	var v1 := _power_axis(c, Vector3(1.0, 0.3, 0.2))
	var l1 := v1.dot(_cov_mul(c, v1))
	var c2: Array[float] = [c[0] - l1 * v1.x * v1.x, c[1] - l1 * v1.x * v1.y, c[2] - l1 * v1.x * v1.z,
			c[3] - l1 * v1.y * v1.y, c[4] - l1 * v1.y * v1.z, c[5] - l1 * v1.z * v1.z]
	var start := v1.cross(Vector3.UP)
	if start.length() < 0.1:
		start = v1.cross(Vector3.RIGHT)
	var v2 := _power_axis(c2, start.normalized())
	var n := v1.cross(v2)
	return n.normalized() if n.length() > 0.0001 else Vector3.BACK


func _cov_mul(c: Array[float], v: Vector3) -> Vector3:
	return Vector3(c[0] * v.x + c[1] * v.y + c[2] * v.z,
			c[1] * v.x + c[3] * v.y + c[4] * v.z,
			c[2] * v.x + c[4] * v.y + c[5] * v.z)


func _power_axis(c: Array[float], start: Vector3) -> Vector3:
	var v := start.normalized()
	for i in 40:
		var w := _cov_mul(c, v)
		if w.length() < 0.000001:
			break
		v = w.normalized()
	return v


func gear_label() -> String:
	if gear == -1:
		return "R"
	if gear == 0:
		return "N"
	return ("D" if automatic else "M") + str(gear)


## Floating "P2" tag so the two cars can be told apart on one screen.
func add_player_tag(text: String, color: Color) -> void:
	var l := Label3D.new()
	l.text = text
	l.font_size = 96
	l.pixel_size = 0.01
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.no_depth_test = true
	l.modulate = color
	l.outline_size = 24
	l.position = Vector3(0, 2.1, 0)
	add_child(l)
