class_name HornSynth
extends RefCounted
## Placeholder car horn generated in code (two-tone, seamless 1 s loop) until real
## audio files are supplied.


static func make() -> AudioStreamWAV:
	var rate := 22050
	var data := PackedByteArray()
	data.resize(rate * 2)
	for i in rate:
		var t := float(i) / rate
		var v := 0.30 * sin(TAU * 392.0 * t) + 0.30 * sin(TAU * 494.0 * t) \
				+ 0.10 * sin(TAU * 784.0 * t) + 0.08 * sin(TAU * 988.0 * t)
		data.encode_s16(i * 2, int(clampf(v, -1.0, 1.0) * 30000.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.stereo = false
	w.data = data
	w.loop_mode = AudioStreamWAV.LOOP_FORWARD
	w.loop_begin = 0
	w.loop_end = rate
	return w
