class_name CarLights
extends Node3D
## Headlights (LOW / HIGH / LOW+HIGH) with real spot lights, tail + brake + reverse
## lights, turn signals, hazards and a cabin light. Glow on the car body comes from
## additive overlay materials on the lamp meshes (found by name), so it also works on
## imported cars. State lives in the car's PlayerState so the HUD and phone can show it.

const MODE_NAMES := ["OFF", "LOW BEAM", "HIGH BEAM", "LOW + HIGH"]

var car: Node
var st: PlayerState
var parts: Dictionary = {}
var _low: Array[SpotLight3D] = []
var _high: Array[SpotLight3D] = []
var _cabin: OmniLight3D
var _ov := {}
var _on := {}
var _t := 0.0


func setup(c: Node, front: Vector3, cabin_pos: Vector3, p: Dictionary, state: PlayerState) -> void:
	car = c
	st = state
	parts = p
	for sx: float in [-1.0, 1.0]:
		_low.append(_spot(Vector3(front.x * sx, front.y, front.z - 0.1), 40.0, 48.0, 1.6, -4.0))
		_high.append(_spot(Vector3(front.x * sx, front.y + 0.03, front.z - 0.1), 85.0, 26.0, 3.2, -1.0))
	_cabin = OmniLight3D.new()
	_cabin.position = cabin_pos
	_cabin.omni_range = 2.6
	_cabin.light_energy = 0.9
	_cabin.light_color = Color(1.0, 0.92, 0.75)
	_cabin.visible = false
	add_child(_cabin)
	for k in ["head", "tail", "reverse", "ind_l", "ind_r"]:
		_ov[k] = _overlay()
	st.light_action.connect(_on_action)


func _spot(pos: Vector3, rng: float, angle: float, energy: float, tilt: float) -> SpotLight3D:
	var s := SpotLight3D.new()
	s.position = pos
	s.rotation_degrees = Vector3(tilt, 0, 0)
	s.spot_range = rng
	s.spot_angle = angle
	s.light_energy = energy
	s.light_color = Color(1.0, 0.96, 0.85)
	s.shadow_enabled = false
	s.visible = false
	add_child(s)
	return s


func _overlay() -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	return m


func _on_action(n: String) -> void:
	if get_tree().paused:
		return
	match n:
		"lights":
			st.light_mode = (st.light_mode + 1) % 4
		"hazard":
			st.hazard = not st.hazard
		"ind_l":
			st.ind_left = not st.ind_left
			if st.ind_left:
				st.ind_right = false
		"ind_r":
			st.ind_right = not st.ind_right
			if st.ind_right:
				st.ind_left = false
		"cabin":
			st.cabin_light = not st.cabin_light


func _process(delta: float) -> void:
	_t += delta
	var blink := fmod(_t, 0.7) < 0.35
	st.blink = blink
	var m := st.light_mode
	var low_on := m == 1 or m == 3
	var high_on := m == 2 or m == 3
	for l in _low:
		l.visible = low_on
	for l in _high:
		l.visible = high_on
	_cabin.visible = st.cabin_light

	var head_i := 0.0
	if low_on and high_on:
		head_i = 0.85
	elif high_on:
		head_i = 0.7
	elif low_on:
		head_i = 0.35
	_glow("head", Color(1.0, 0.95, 0.8), head_i)
	var tail_i := 0.0
	if bool(car.get("braking_visual")):
		tail_i = 1.0
	elif m > 0:
		tail_i = 0.28
	_glow("tail", Color(1.0, 0.05, 0.02), tail_i)
	_glow("reverse", Color(1.0, 1.0, 1.0), 0.8 if int(car.get("gear")) == -1 else 0.0)
	var amber := Color(1.0, 0.55, 0.05)
	_glow("ind_l", amber, 1.0 if ((st.ind_left or st.hazard) and blink) else 0.0)
	_glow("ind_r", amber, 1.0 if ((st.ind_right or st.hazard) and blink) else 0.0)


func _glow(kind: String, color: Color, intensity: float) -> void:
	var key := "%s:%.2f" % [kind, intensity]
	if _on.get(kind, "") == key:
		return
	_on[kind] = key
	var mat: StandardMaterial3D = _ov[kind]
	mat.albedo_color = Color(color.r * intensity, color.g * intensity, color.b * intensity, 1.0)
	for mi in parts.get(kind, []):
		(mi as MeshInstance3D).material_overlay = mat if intensity > 0.01 else null
