class_name HUD
extends CanvasLayer
## TV-safe HUD: speed/RPM gauge, gear, distance, time, camera, pause overlay.

class Gauge extends Control:
	var frac := 0.0
	func _draw() -> void:
		var c := size * 0.5
		var r := minf(size.x, size.y) * 0.44
		draw_arc(c, r, deg_to_rad(135), deg_to_rad(405), 72, Color(1, 1, 1, 0.14), 16.0, true)
		if frac > 0.005:
			var col := Color(0.25, 0.85, 1.0) if frac < 0.82 else Color(1.0, 0.25, 0.15)
			draw_arc(c, r, deg_to_rad(135), deg_to_rad(135 + 270.0 * frac), 72, col, 16.0, true)

## Optional instrument cluster: speedometer + tachometer dials, gear, warning lamps.
class Cluster extends Control:
	var kmh := 0.0
	var rpm := 0.0
	var redline := 7000.0
	var gear := "N"
	var left := false
	var right := false
	var beam := 0
	var braking := false
	var handbrake := false
	var hazard := false

	func _draw() -> void:
		var f := ThemeDB.fallback_font
		var w := size.x
		var h := size.y
		_dial(f, Vector2(w * 0.24, h * 0.56), h * 0.46, 240.0, 20.0, kmh, "KM/H", 0.0)
		_dial(f, Vector2(w * 0.76, h * 0.56), h * 0.46, 9.0, 1.0, rpm / 1000.0, "RPM x1000", redline / 1000.0)
		draw_string(f, Vector2(w * 0.5 - 60, h * 0.62), gear, HORIZONTAL_ALIGNMENT_CENTER, 120, 84, Color.WHITE)
		draw_string(f, Vector2(w * 0.5 - 60, h * 0.84), "%d km/h" % int(kmh), HORIZONTAL_ALIGNMENT_CENTER, 120, 26, Color(0.7, 0.9, 1.0))
		var amber := Color(1.0, 0.6, 0.05)
		var off := Color(1, 1, 1, 0.12)
		var y := h * 0.1
		draw_colored_polygon(PackedVector2Array([Vector2(w * 0.38, y), Vector2(w * 0.42, y - 16), Vector2(w * 0.42, y + 16)]), amber if left else off)
		draw_colored_polygon(PackedVector2Array([Vector2(w * 0.62, y), Vector2(w * 0.58, y - 16), Vector2(w * 0.58, y + 16)]), amber if right else off)
		var lamp := Color(0.2, 1.0, 0.3) if (beam == 1 or beam == 3) else off
		draw_circle(Vector2(w * 0.46, y), 9.0, lamp)
		draw_circle(Vector2(w * 0.54, y), 9.0, Color(0.3, 0.55, 1.0) if (beam == 2 or beam == 3) else off)
		draw_circle(Vector2(w * 0.5, y), 9.0, Color(1.0, 0.2, 0.2) if (hazard or braking or handbrake) else off)

	func _dial(f: Font, c: Vector2, r: float, vmax: float, major: float, val: float, label: String, red_from: float) -> void:
		var a0 := deg_to_rad(135.0)
		var a1 := deg_to_rad(405.0)
		draw_circle(c, r, Color(0, 0, 0, 0.55))
		draw_arc(c, r * 0.92, a0, a1, 64, Color(1, 1, 1, 0.3), 3.0, true)
		if red_from > 0.0:
			draw_arc(c, r * 0.92, lerpf(a0, a1, red_from / vmax), a1, 24, Color(1, 0.2, 0.15), 6.0, true)
		var n := int(vmax / major)
		for i in n + 1:
			var v := i * major
			var a := lerpf(a0, a1, v / vmax)
			var d := Vector2(cos(a), sin(a))
			draw_line(c + d * r * 0.8, c + d * r * 0.92, Color.WHITE, 3.0)
			draw_string(f, c + d * r * 0.64 - Vector2(20, -8), str(int(v)), HORIZONTAL_ALIGNMENT_CENTER, 40, 18, Color(1, 1, 1, 0.85))
		draw_string(f, c + Vector2(-60, r * 0.42), label, HORIZONTAL_ALIGNMENT_CENTER, 120, 16, Color(1, 1, 1, 0.6))
		var na := lerpf(a0, a1, clampf(val / vmax, 0.0, 1.0))
		draw_line(c, c + Vector2(cos(na), sin(na)) * r * 0.78, Color(1.0, 0.35, 0.1), 5.0, true)
		draw_circle(c, 9.0, Color(0.9, 0.9, 0.9))


var car: HighwayCar
var car2: HighwayCar
var cam: ChaseCamera
var st: PlayerState = GameState.players[0]
var _p2: Label
var extra_text := ""
var distance_m := 0.0
var elapsed := 0.0

var _gauge: Gauge
var _cluster: Cluster
var _icons: Label
var _instr_btn: Button
var _speed: Label
var _gear: Label
var _tl: Label
var _tr: Label
var _hint: Label
signal resume_requested
signal menu_requested

var _pause: ColorRect
var _resume_btn: Button
var _view_btn: Button
var _sliders: Dictionary = {}
var _hint_t := 14.0


func _label(size: int, align: int = HORIZONTAL_ALIGNMENT_LEFT) -> Label:
	var l := Label.new()
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", Color(1, 1, 1))
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
	l.add_theme_constant_override("outline_size", 6)
	l.horizontal_alignment = align as HorizontalAlignment
	return l


func _ready() -> void:
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)

	_gauge = Gauge.new()
	_gauge.anchor_left = 1.0
	_gauge.anchor_right = 1.0
	_gauge.anchor_top = 1.0
	_gauge.anchor_bottom = 1.0
	_gauge.offset_left = -440.0
	_gauge.offset_top = -440.0
	_gauge.offset_right = -60.0
	_gauge.offset_bottom = -60.0
	root.add_child(_gauge)
	_cluster = Cluster.new()
	_cluster.anchor_left = 0.5
	_cluster.anchor_right = 0.5
	_cluster.anchor_top = 1.0
	_cluster.anchor_bottom = 1.0
	_cluster.offset_left = -500.0
	_cluster.offset_right = 500.0
	_cluster.offset_top = -330.0
	_cluster.offset_bottom = -20.0
	_cluster.visible = false
	root.add_child(_cluster)
	_icons = _label(30, HORIZONTAL_ALIGNMENT_CENTER)
	_icons.anchor_left = 0.5
	_icons.anchor_right = 0.5
	_icons.anchor_top = 1.0
	_icons.anchor_bottom = 1.0
	_icons.offset_left = -420.0
	_icons.offset_right = 420.0
	_icons.offset_top = -380.0
	_icons.offset_bottom = -340.0
	root.add_child(_icons)
	var vb := VBoxContainer.new()
	vb.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	vb.alignment = BoxContainer.ALIGNMENT_CENTER
	_gauge.add_child(vb)
	_speed = _label(112, HORIZONTAL_ALIGNMENT_CENTER)
	vb.add_child(_speed)
	var unit := _label(28, HORIZONTAL_ALIGNMENT_CENTER)
	unit.text = "KM/H"
	vb.add_child(unit)
	_gear = _label(48, HORIZONTAL_ALIGNMENT_CENTER)
	vb.add_child(_gear)

	_tl = _label(30)
	_tl.position = Vector2(60, 40)
	root.add_child(_tl)

	_tr = _label(26, HORIZONTAL_ALIGNMENT_RIGHT)
	_tr.anchor_left = 1.0
	_tr.anchor_right = 1.0
	_tr.offset_left = -620.0
	_tr.offset_right = -60.0
	_tr.offset_top = 40.0
	root.add_child(_tr)

	_p2 = _label(26)
	_p2.anchor_top = 1.0
	_p2.anchor_bottom = 1.0
	_p2.offset_left = 60.0
	_p2.offset_top = -210.0
	_p2.offset_bottom = -150.0
	root.add_child(_p2)

	_hint = _label(24)
	_hint.anchor_top = 1.0
	_hint.anchor_bottom = 1.0
	_hint.offset_left = 60.0
	_hint.offset_top = -140.0
	_hint.offset_bottom = -50.0
	_hint.text = "LEFT/RIGHT steer   UP accelerate   DOWN brake/reverse\nOK camera   BACK pause   (keyboard: F1 quality, F2 environment)"
	root.add_child(_hint)

	_pause = ColorRect.new()
	_pause.color = Color(0, 0, 0, 0.3)
	_pause.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_pause.visible = false
	root.add_child(_pause)
	var title := _label(64)
	title.text = "PAUSED"
	title.position = Vector2(100, 90)
	_pause.add_child(title)
	var panel := PanelContainer.new()
	panel.position = Vector2(1130, 90)
	panel.custom_minimum_size = Vector2(700, 0)
	_pause.add_child(panel)
	var vb2 := VBoxContainer.new()
	vb2.add_theme_constant_override("separation", 14)
	panel.add_child(vb2)
	_resume_btn = _button("RESUME", resume_requested.emit)
	vb2.add_child(_resume_btn)
	_view_btn = _button("", _cycle_view)
	vb2.add_child(_view_btn)
	_add_slider(vb2, "dist", "CAMERA DISTANCE (0 = inside car, FREE VIEW)", 0.0, 2.5, 0.05)
	_add_slider(vb2, "zoom", "ZOOM", 0.5, 4.0, 0.1)
	_add_slider(vb2, "pitch", "CAMERA ANGLE (up/down)", -20.0, 70.0, 1.0)
	_add_slider(vb2, "yaw", "ROTATE AROUND CAR (360)", -180.0, 180.0, 1.0)
	_instr_btn = _button("", _cycle_instruments)
	vb2.add_child(_instr_btn)
	vb2.add_child(_button("RESET CAMERA", _reset_cam))
	vb2.add_child(_button("MAIN MENU", menu_requested.emit))


func _button(text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 66)
	b.add_theme_font_size_override("font_size", 30)
	b.pressed.connect(cb)
	return b


func _add_slider(parent: Control, key: String, text: String, lo: float, hi: float, step: float) -> void:
	var lab := Label.new()
	lab.add_theme_font_size_override("font_size", 26)
	parent.add_child(lab)
	var sl := HSlider.new()
	sl.min_value = lo
	sl.max_value = hi
	sl.step = step
	sl.custom_minimum_size = Vector2(0, 44)
	sl.focus_mode = Control.FOCUS_ALL
	sl.value_changed.connect(_on_slider.bind(key))
	parent.add_child(sl)
	_sliders[key] = {"slider": sl, "label": lab, "text": text}


func _on_slider(v: float, key: String) -> void:
	match key:
		"dist": GameState.cam_dist = v
		"zoom": GameState.cam_zoom = v
		"pitch": GameState.cam_pitch = v
		"yaw": GameState.cam_yaw = v
	_refresh_sliders()


func _refresh_sliders() -> void:
	var vals := {"dist": GameState.cam_dist, "zoom": GameState.cam_zoom, "pitch": GameState.cam_pitch, "yaw": GameState.cam_yaw}
	for key in _sliders:
		var e: Dictionary = _sliders[key]
		var sl: HSlider = e["slider"]
		if not is_equal_approx(sl.value, float(vals[key])):
			sl.set_value_no_signal(float(vals[key]))
		(e["label"] as Label).text = "%s:  %.2f" % [e["text"], float(vals[key])] if key == "dist" or key == "zoom" \
				else "%s:  %d" % [e["text"], int(vals[key])]
	_instr_btn.text = "INSTRUMENTS:  %s   (OK = change)" % ["STANDARD GAUGE", "INSTRUMENT CLUSTER", "OFF"][GameState.cluster_mode]
	_view_btn.text = "VIEW MODE:  %s   (OK = next)" % ChaseCamera.MODE_NAMES[cam.mode]


func _cycle_instruments() -> void:
	GameState.cluster_mode = (GameState.cluster_mode + 1) % 3
	_refresh_sliders()


func _cycle_view() -> void:
	cam.next_mode()
	_refresh_sliders()


func _reset_cam() -> void:
	cam.reset_view()
	_refresh_sliders()


func set_paused(p: bool) -> void:
	_pause.visible = p
	if p:
		_refresh_sliders()
		_resume_btn.grab_focus()


func _process(delta: float) -> void:
	if car == null:
		return
	if not get_tree().paused:
		distance_m += absf(car.speed_ms) * delta
		elapsed += delta
		_hint_t -= delta
		_hint.modulate.a = clampf(_hint_t, 0.0, 1.0)
	_gauge.frac = clampf(car.engine_rpm / (car.redline_rpm * 1.05), 0.0, 1.0)
	_gauge.queue_redraw()
	_speed.text = str(int(round(car.speed_kmh)))
	if car.gear == -1:
		_gear.text = "R"
	elif car.gear == 0:
		_gear.text = "N"
	else:
		_gear.text = ("D" if car.automatic else "M") + str(car.gear)
	var mins := int(elapsed) / 60
	var secs := int(elapsed) % 60
	_tl.text = "DIST  %.2f km\nTIME  %02d:%02d" % [distance_m / 1000.0, mins, secs]
	var t := "%s CAM   %d FPS" % [ChaseCamera.MODE_NAMES[cam.mode], Engine.get_frames_per_second()]
	if PhoneServer.status == PhoneServer.Status.CONNECTED:
		t += "\nPHONES: " + ", ".join(PhoneServer.connected_names())
	elif PhoneServer.status == PhoneServer.Status.WAITING:
		t += "\nPHONE: not connected"
	if extra_text != "":
		t += "\n" + extra_text
	if car.last_0_100 > 0.0:
		t += "\n0-100: %.1f s" % car.last_0_100
	_tr.text = t
	_p2.text = "" if car2 == null or not is_instance_valid(car2) else "P2 (%s):  %d km/h  %s" % [GameState.players[1].phone_name, int(car2.speed_kmh), car2.gear_label()]
	var cm := GameState.cluster_mode
	_gauge.visible = cm == 0
	_cluster.visible = cm == 1
	var blink := st.blink
	_cluster.kmh = car.speed_kmh
	_cluster.rpm = car.engine_rpm
	_cluster.redline = car.redline_rpm
	_cluster.gear = _gear.text
	_cluster.left = (st.ind_left or st.hazard) and blink
	_cluster.right = (st.ind_right or st.hazard) and blink
	_cluster.beam = st.light_mode
	_cluster.braking = car.braking_visual
	_cluster.hazard = st.hazard
	if cm == 1:
		_cluster.queue_redraw()
	var ic := ""
	if (st.ind_left or st.hazard) and blink:
		ic += "<<  "
	if st.hazard:
		ic += "HAZARD  "
	if (st.ind_right or st.hazard) and blink:
		ic += ">>  "
	if st.light_mode > 0:
		ic += "  " + CarLights.MODE_NAMES[st.light_mode]
	if st.cabin_light:
		ic += "  CABIN"
	_icons.text = ic if cm != 1 else ""
