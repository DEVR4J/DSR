extends Node
## Autoload "PhoneServer": local Wi-Fi phone controller.
##  - HTTP server (port P) serves the controller web page and accepts car uploads.
##  - WebSocket server (port P+1) carries controls from the phone browser.
## No pairing code: open http://<tv-ip>:P/ on a phone on the same Wi-Fi. Up to TWO phones
## can be connected: phone 1 drives player 1, phone 2 gets its own car on the same screen.
## If a phone goes silent for TIMEOUT seconds (or disconnects) its controls are neutralised
## immediately and (for phone 2) its car is removed.

signal changed
signal slot_changed(slot: int, active: bool)
signal car_selected(slot: int, id: String)

enum Status { STOPPED, WAITING, CONNECTED }
const BASE_PORT := 8080
const TIMEOUT := 1.5
const UPLOAD_DIR := "user://phone_uploads"
const REASONS := {200: "OK", 204: "No Content", 403: "Forbidden", 404: "Not Found",
		413: "Payload Too Large", 415: "Unsupported Media Type", 500: "Server Error"}

var status := Status.STOPPED
var ip := ""
var http_port := 0
var ws_port := 0
var allow_uploads := false          # true while the PHONE CONTROLLER screen is open
var car_ids: Array[String] = ["", ""]  # car each phone picked ("" = built-in)
var last_message := ""
var all_ips: PackedStringArray = []

var _http := TCPServer.new()
var _ws := TCPServer.new()
var _conns: Array[HttpConn] = []
var _clients: Array[Client] = []
var slots: Array[Client] = [null, null]
var _tele_t := 0.0


class HttpConn:
	var stream: StreamPeerTCP
	var buf := PackedByteArray()
	var born := 0.0
	var header_done := false
	var file: FileAccess = null
	var body_left := 0
	var close_at := 0.0


class Client:
	var peer: WebSocketPeer
	var born := 0.0
	var last_seen := 0.0
	var authed := false
	var cid := ""
	var pname := ""
	var slot := -1


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	start()


func _now() -> float:
	return Time.get_ticks_msec() / 1000.0


func url() -> String:
	return "http://%s:%d/" % [ip, http_port]


func connected_names() -> PackedStringArray:
	var out := PackedStringArray()
	for i in 2:
		if slots[i] != null:
			out.append("P%d %s" % [i + 1, (slots[i] as Client).pname])
	return out


func _is_active(cl: Client) -> bool:
	return cl.slot >= 0 and slots[cl.slot] == cl


# ------------------------------------------------------------------ control
func start() -> void:
	if status != Status.STOPPED:
		return
	ip = _find_ip()
	http_port = 0
	all_ips = IP.get_local_addresses()
	var last_err := OK
	for p in range(BASE_PORT, BASE_PORT + 40, 2):
		var e1 := _http.listen(p)
		if e1 == OK:
			var e2 := _ws.listen(p + 1)
			if e2 == OK:
				http_port = p
				ws_port = p + 1
				break
			_http.stop()
			last_err = e2
		else:
			last_err = e1
	if http_port == 0:
		last_message = "Could not open a network port (error %d)" % last_err
		changed.emit()
		return
	status = Status.WAITING
	last_message = "Waiting for phone"
	changed.emit()


func stop() -> void:
	for i in 2:
		if slots[i] != null:
			_deactivate(i, "Server stopped")
	for c: Client in _clients:
		c.peer.close()
	_clients.clear()
	for c: HttpConn in _conns:
		c.stream.disconnect_from_host()
	_conns.clear()
	_http.stop()
	_ws.stop()
	http_port = 0
	ws_port = 0
	status = Status.STOPPED
	changed.emit()


func disconnect_all() -> void:
	for i in 2:
		var cl := slots[i]
		if cl != null:
			cl.peer.close()
			_deactivate(i, "Phones disconnected")


func _find_ip() -> String:
	var best := ""
	var rank := 99
	for a in IP.get_local_addresses():
		if a.contains(":") or not a.contains("."):
			continue
		var r := 99
		if a.begins_with("192.168."):
			r = 0
		elif a.begins_with("10."):
			r = 1
		elif a.begins_with("172."):
			var second := int(a.split(".")[1])
			if second >= 16 and second <= 31:
				r = 2
		if r < rank:
			rank = r
			best = a
	return best if best != "" else "unknown"


# --------------------------------------------------------------------- loop
func _process(delta: float) -> void:
	if status == Status.STOPPED:
		return
	var now := _now()
	_poll_http(now)
	_poll_ws(now)
	for i in 2:
		var cl := slots[i]
		if cl != null and now - cl.last_seen > TIMEOUT:
			_deactivate(i, "Player %d's phone timed out" % (i + 1))
	_tele_t += delta
	if _tele_t > 0.2:
		_tele_t = 0.0
		for i in 2:
			var cl := slots[i]
			if cl != null:
				var p: PlayerState = GameState.players[i]
				_send(cl, {"t": "st", "k": int(p.speed_kmh), "g": p.gear_text, "lm": p.light_mode, "hz": p.hazard,
						"il": p.ind_left, "ir": p.ind_right, "cb": p.cabin_light, "pl": i + 1})


# ---------------------------------------------------------------- websocket
func _poll_ws(now: float) -> void:
	while _ws.is_connection_available():
		var s := _ws.take_connection()
		var cl := Client.new()
		cl.peer = WebSocketPeer.new()
		if cl.peer.accept_stream(s) != OK:
			continue
		cl.born = now
		cl.last_seen = now
		_clients.append(cl)
	for cl: Client in _clients.duplicate():
		cl.peer.poll()
		match cl.peer.get_ready_state():
			WebSocketPeer.STATE_OPEN:
				while cl.peer.get_available_packet_count() > 0:
					_on_message(cl, cl.peer.get_packet().get_string_from_utf8(), now)
				if not cl.authed and now - cl.born > 5.0:
					cl.peer.close()
			WebSocketPeer.STATE_CLOSED:
				_clients.erase(cl)
				if _is_active(cl):
					_deactivate(cl.slot, "Phone disconnected")


func _send(cl: Client, d: Dictionary) -> void:
	if cl.peer.get_ready_state() == WebSocketPeer.STATE_OPEN:
		cl.peer.send_text(JSON.stringify(d))


func _f(v: Variant) -> float:
	var x := float(v)
	return 0.0 if is_nan(x) or is_inf(x) else x


func _on_message(cl: Client, txt: String, now: float) -> void:
	var d: Variant = JSON.parse_string(txt)
	if not (d is Dictionary):
		return
	cl.last_seen = now
	var t := str(d.get("t", ""))
	if t == "hello":
		_hello(cl, d, now)
		return
	if not cl.authed:
		return
	if not _is_active(cl):
		_try_reactivate(cl)          # a phone that timed out resumes as soon as it talks again
		if not _is_active(cl):
			return
	var slot := cl.slot
	match t:
		"i":
			var p: PlayerState = GameState.players[slot]
			p.set_remote(_f(d.get("s", 0)), _f(d.get("th", 0)), _f(d.get("b", 0)), _f(d.get("h", 0)))
			if slot == 0:
				GameState.look_x = clampf(_f(d.get("lx", 0)), -1.0, 1.0)
				GameState.look_y = clampf(_f(d.get("ly", 0)), -1.0, 1.0)
		"b":
			_button(slot, str(d.get("n", "")), bool(d.get("v", true)))
		"nav":
			_nav(str(d.get("n", "")))
		"cam":
			if slot == 0:
				GameState.cam_dist = clampf(_f(d.get("d", 1.0)), 0.0, 2.5)
				GameState.cam_zoom = clampf(_f(d.get("z", 1.0)), 0.5, 4.0)
				GameState.cam_pitch = clampf(_f(d.get("p", 0.0)), -20.0, 70.0)
				GameState.cam_yaw = clampf(_f(d.get("y", 0.0)), -180.0, 180.0)
		"car":
			car_ids[slot] = str(d.get("id", ""))
			car_selected.emit(slot, car_ids[slot])


func _hello(cl: Client, d: Dictionary, now: float) -> void:
	var cid := str(d.get("cid", "")).substr(0, 24)
	cl.cid = cid
	cl.pname = _clean(str(d.get("name", "Phone")))
	var slot := -1
	for i in 2:                                # the same phone reconnecting takes its place back
		var o := slots[i]
		if o != null and o != cl and o.cid == cid:
			o.peer.close()
			_clients.erase(o)
			_deactivate(i, "Phone reconnecting")
			slot = i
			break
	if slot < 0:
		for i in 2:
			if slots[i] == null:
				slot = i
				break
	if slot < 0:                               # two phones already connected
		_send(cl, {"t": "busy"})
		cl.peer.close()
		return
	cl.authed = true
	_activate(cl, slot)
	_send(cl, {"t": "ok", "name": cl.pname, "slot": slot})
	_send(cl, {"t": "cars", "list": _car_list(), "sel": car_ids[slot]})


func _car_list() -> Array:
	var out: Array = [{"id": "", "name": "Built-in coupe"}]
	for id in CarSpec.list_ids():
		out.append({"id": id, "name": str(CarSpec.load_spec(id).get("name", id))})
	return out


func _try_reactivate(cl: Client) -> void:
	var order: Array[int] = [maxi(cl.slot, 0), 0, 1]
	for i in order:
		if slots[i] == null:
			_activate(cl, i)
			return


func _clean(s: String) -> String:
	var out := ""
	for ch in s.substr(0, 24):
		if ch.unicode_at(0) >= 32:
			out += ch
	return out if out != "" else "Phone"


func _activate(cl: Client, slot: int) -> void:
	slots[slot] = cl
	cl.slot = slot
	GameState.players[slot].phone_name = cl.pname
	status = Status.CONNECTED
	last_message = "Player %d connected" % (slot + 1)
	changed.emit()
	slot_changed.emit(slot, true)


func _deactivate(slot: int, reason: String) -> void:
	var p: PlayerState = GameState.players[slot]
	p.clear_remote()                           # input neutralisation
	p.phone_name = ""
	if slot == 0:
		GameState.look_x = 0.0
		GameState.look_y = 0.0
	slots[slot] = null
	if slots[0] == null and slots[1] == null and status == Status.CONNECTED:
		status = Status.WAITING
	last_message = reason
	changed.emit()
	slot_changed.emit(slot, false)


func _button(slot: int, n: String, v: bool) -> void:
	var p: PlayerState = GameState.players[slot]
	match n:
		"gear_up": p.gear_up_pressed.emit()
		"gear_down": p.gear_down_pressed.emit()
		"gearbox": p.gearbox_toggle_pressed.emit()
		"reset": p.reset_pressed.emit()
		"horn": p.horn_changed.emit(v)
		"lights", "hazard", "ind_l", "ind_r", "cabin": p.light_action.emit(n)
		"pause": GameInput.pause_pressed.emit()
		"camera":
			if slot == 0:
				GameInput.camera_pressed.emit()
		"cluster":
			if slot == 0:
				GameState.cluster_mode = (GameState.cluster_mode + 1) % 3


func _nav(n: String) -> void:
	match n:
		"up": _press_action("ui_up")
		"down": _press_action("ui_down")
		"left": _press_action("ui_left")
		"right": _press_action("ui_right")
		"ok":
			_press_action("ui_accept")
			GameInput.accept_pressed.emit()
		"back": GameInput.back_pressed.emit()


func _press_action(act: String) -> void:
	var ev := InputEventAction.new()
	ev.action = act
	ev.pressed = true
	Input.parse_input_event(ev)
	await get_tree().create_timer(0.05, true).timeout
	var up := InputEventAction.new()
	up.action = act
	up.pressed = false
	Input.parse_input_event(up)


# --------------------------------------------------------------------- http
func _poll_http(now: float) -> void:
	while _http.is_connection_available():
		var c := HttpConn.new()
		c.stream = _http.take_connection()
		c.born = now
		_conns.append(c)
	for c: HttpConn in _conns.duplicate():
		c.stream.poll()
		var st := c.stream.get_status()
		if st == StreamPeerTCP.STATUS_ERROR or st == StreamPeerTCP.STATUS_NONE:
			_drop(c)
			continue
		if c.close_at > 0.0:
			if now > c.close_at:
				_drop(c)
			continue
		if st == StreamPeerTCP.STATUS_CONNECTED:
			var n := c.stream.get_available_bytes()
			if n > 0:
				var res := c.stream.get_data(n)
				if res[0] == OK:
					_http_feed(c, res[1])
		if now - c.born > 20.0:
			_drop(c)


func _drop(c: HttpConn) -> void:
	if c.file != null:
		c.file.close()
		c.file = null
	c.stream.disconnect_from_host()
	_conns.erase(c)


func _find_end(b: PackedByteArray) -> int:
	for i in range(0, b.size() - 3):
		if b[i] == 13 and b[i + 1] == 10 and b[i + 2] == 13 and b[i + 3] == 10:
			return i
	return -1


func _http_feed(c: HttpConn, data: PackedByteArray) -> void:
	if c.header_done:
		_upload_chunk(c, data)
		return
	c.buf.append_array(data)
	var end := _find_end(c.buf)
	if end < 0:
		if c.buf.size() > 16384:
			_drop(c)
		return
	c.header_done = true
	var head := c.buf.slice(0, end).get_string_from_utf8()
	var rest := c.buf.slice(end + 4)
	c.buf = PackedByteArray()
	var lines := head.split("\r\n")
	var parts := lines[0].split(" ")
	if parts.size() < 2:
		_drop(c)
		return
	var headers := {}
	for i in range(1, lines.size()):
		var kv := lines[i].split(":", true, 1)
		if kv.size() == 2:
			headers[kv[0].strip_edges().to_lower()] = kv[1].strip_edges()
	var target := parts[1]
	var path := target.get_slice("?", 0)
	var query := _parse_query(target.get_slice("?", 1) if target.contains("?") else "")
	if parts[0] == "GET" and (path == "/" or path == "/index.html"):
		_respond(c, 200, "text/html; charset=utf-8", ControllerPage.HTML.replace("__WSPORT__", str(ws_port)).to_utf8_buffer())
	elif parts[0] == "GET" and path == "/favicon.ico":
		_respond(c, 204, "text/plain", PackedByteArray())
	elif parts[0] == "POST" and path == "/upload":
		_start_upload(c, headers, query, rest)
	else:
		_respond(c, 404, "text/plain", "Not found".to_utf8_buffer())


func _parse_query(q: String) -> Dictionary:
	var out := {}
	for pair in q.split("&", false):
		var kv := pair.split("=", true, 1)
		out[kv[0].uri_decode()] = kv[1].uri_decode() if kv.size() > 1 else ""
	return out


func _upload_allowed(c: HttpConn) -> bool:
	if allow_uploads:
		return true
	var host := c.stream.get_connected_host()
	for cl: Client in _clients:
		if cl.authed and cl.peer.get_connected_host() == host:
			return true
	return false


func _start_upload(c: HttpConn, headers: Dictionary, query: Dictionary, rest: PackedByteArray) -> void:
	if not _upload_allowed(c):
		_respond(c, 403, "text/plain", "Open PHONE CONTROLLER on the TV, or connect the controller first".to_utf8_buffer())
		return
	var nm := str(query.get("name", "")).get_file().replace(" ", "_")
	var clean := ""
	for ch in nm:
		if ch.is_valid_identifier() or ch == "." or ch == "-" or ch.unicode_at(0) > 47 and ch.unicode_at(0) < 58:
			clean += ch
	nm = clean
	var ext := nm.get_extension().to_lower()
	if nm == "" or not (ext in CarImporter.MODEL_EXT or ext in CarImporter.AUX_EXT):
		_respond(c, 415, "text/plain", "Unsupported file type".to_utf8_buffer())
		return
	var length := int(headers.get("content-length", "0"))
	if length <= 0 or length > CarImporter.MAX_BYTES:
		_respond(c, 413, "text/plain", "File too large or empty".to_utf8_buffer())
		return
	DirAccess.make_dir_recursive_absolute(UPLOAD_DIR)
	c.file = FileAccess.open(UPLOAD_DIR + "/" + nm, FileAccess.WRITE)
	if c.file == null:
		_respond(c, 500, "text/plain", "Cannot write".to_utf8_buffer())
		return
	c.body_left = length
	last_message = "Receiving %s from phone..." % nm
	changed.emit()
	_upload_chunk(c, rest)


func _upload_chunk(c: HttpConn, data: PackedByteArray) -> void:
	if c.file == null:
		return
	var n := mini(data.size(), c.body_left)
	if n > 0:
		c.file.store_buffer(data.slice(0, n))
		c.body_left -= n
	c.born = _now()
	if c.body_left <= 0:
		c.file.close()
		c.file = null
		last_message = "File received from phone (use IMPORT CUSTOM CAR > APP FOLDER FILE)"
		changed.emit()
		_respond(c, 200, "text/plain", "OK".to_utf8_buffer())


func _respond(c: HttpConn, code: int, ctype: String, body: PackedByteArray) -> void:
	var hdr := "HTTP/1.1 %d %s\r\nContent-Type: %s\r\nContent-Length: %d\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n" \
			% [code, REASONS.get(code, "OK"), ctype, body.size()]
	c.stream.put_data(hdr.to_utf8_buffer())
	if body.size() > 0:
		c.stream.put_data(body)
	c.close_at = _now() + 0.5
