extends Node3D
## Highway TV - Stage 1 entry point. Builds world, car, camera, HUD and wires input.

enum Quality { LOW, MEDIUM, HIGH, ULTRA }
const QUALITY_NAMES := ["LOW", "MEDIUM", "HIGH", "ULTRA"]

var quality: int = Quality.MEDIUM
var car: HighwayCar
var car2: HighwayCar          # second phone's car (same screen)
var world: RoadWorld
var cam: ChaseCamera
var hud: HUD
var sun: DirectionalLight3D
var _env: Environment
var _sky_mat: ProceduralSkyMaterial
var biome := 0
var paused := false


func _ready() -> void:
	quality = _recommend_quality()
	_setup_environment()

	world = RoadWorld.new()
	add_child(world)

	car = _make_car(0, GameState.car_id, Transform3D(Basis(), Vector3(0, 1.0, -8)))

	cam = ChaseCamera.new()
	cam.target = car
	cam.distance_scale = clampf(car.car_length / 4.3, 0.8, 1.7)
	add_child(cam)
	cam.current = true

	hud = HUD.new()
	hud.car = car
	hud.cam = cam
	hud.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(hud)
	hud.resume_requested.connect(_toggle_pause)
	hud.menu_requested.connect(_to_menu)

	world.update_for(car.position)
	_apply_quality()
	_set_biome(GameState.biome)

	GameInput.back_pressed.connect(_on_back)
	GameInput.accept_pressed.connect(_on_accept)
	GameInput.pause_pressed.connect(_toggle_pause)
	GameInput.camera_pressed.connect(_on_camera)
	GameState.players[0].reset_pressed.connect(_reset_car.bind(0))
	GameState.players[1].reset_pressed.connect(_reset_car.bind(1))
	PhoneServer.slot_changed.connect(_on_slot_changed)
	PhoneServer.car_selected.connect(_on_car_selected)
	if PhoneServer.slots[1] != null:
		_on_slot_changed(1, true)
	_update_hud_text()


func _physics_process(_delta: float) -> void:
	var p2 := Vector3.INF
	if car2 != null:
		p2 = car2.global_position
		if p2.distance_to(car.global_position) > 150.0:      # left behind: bring car 2 back next to car 1
			car2.global_transform = _p2_spawn_xf()
			car2.linear_velocity = Vector3.ZERO
			car2.angular_velocity = Vector3.ZERO
			p2 = car2.global_position
	world.update_for(car.global_position, p2)
	var off := world.rebase_if_needed(car.global_position)
	if off != Vector3.ZERO:
		car.global_position += off
		if car2 != null:
			car2.global_position += off
		cam.snap()


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_F1:
		quality = (quality + 1) % 4
		_apply_quality()
	elif event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_F3:
		GameState.cluster_mode = (GameState.cluster_mode + 1) % 3
	elif event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_F2:
		_set_biome(biome + 1)


# ------------------------------------------------------------------- input
func _on_back() -> void:
	_toggle_pause()          # BACK pauses / resumes (MAIN MENU is a button in the pause screen)

func _on_accept() -> void:
	if not paused:           # while paused, OK presses the focused button instead
		cam.next_mode()

func _on_camera() -> void:
	if not paused:
		cam.next_mode()

func _reset_car(slot: int) -> void:
	var c := car if slot == 0 else car2
	if not paused and c != null:
		c.reset_upright()

# ------------------------------------------------------------ two players
func _make_car(slot: int, id: String, xf: Transform3D) -> HighwayCar:
	var c := HighwayCar.new()
	c.pstate = GameState.players[slot]
	if slot == 1:
		c.paint_color = Color(0.1, 0.35, 0.85)
	if id != "":
		c.spec = CarSpec.load_spec(id)
	c.transform = xf
	add_child(c)
	if slot == 1:
		c.add_player_tag("P2", Color(0.45, 0.75, 1.0))
	return c


## Next to player 1 (right-hand lane, a few metres behind), facing the same way.
func _p2_spawn_xf() -> Transform3D:
	var xf := car.global_transform
	var f := -xf.basis.z
	f.y = 0.0
	f = f.normalized() if f.length() > 0.01 else Vector3.FORWARD
	var yaw := atan2(-f.x, -f.z)
	var right := Vector3(cos(yaw), 0.0, -sin(yaw))
	return Transform3D(Basis(Vector3.UP, yaw), xf.origin + right * 3.5 - f * 6.0 + Vector3.UP * 0.6)


func _on_slot_changed(slot: int, active: bool) -> void:
	if slot != 1:
		return
	if active and car2 == null:
		car2 = _make_car(1, PhoneServer.car_ids[1], _p2_spawn_xf())
		hud.car2 = car2
	elif not active and car2 != null:
		remove_child(car2)
		car2.free()
		car2 = null
		hud.car2 = null


func _on_car_selected(slot: int, id: String) -> void:
	if slot == 1:
		if car2 == null:
			return
		var xf := car2.global_transform
		xf.origin += Vector3.UP * 0.3
		remove_child(car2)
		car2.free()
		car2 = _make_car(1, id, xf)
		hud.car2 = car2
	else:                       # the first phone picked a different car for player 1
		GameState.car_id = id
		var xf := car.global_transform
		xf.origin += Vector3.UP * 0.3
		remove_child(car)
		car.free()
		car = _make_car(0, id, xf)
		cam.target = car
		cam.distance_scale = clampf(car.car_length / 4.3, 0.8, 1.7)
		cam.snap()
		hud.car = car


func _to_menu() -> void:
	GameState.goto("res://scenes/menu.tscn")


func _toggle_pause() -> void:
	paused = not paused
	get_tree().paused = paused
	hud.set_paused(paused)


# ---------------------------------------------------------------- graphics
func _recommend_quality() -> int:
	var cores := OS.get_processor_count()
	if cores >= 8:
		return Quality.HIGH
	if cores >= 4:
		return Quality.MEDIUM
	return Quality.LOW


func _apply_quality() -> void:
	sun.shadow_enabled = quality >= Quality.MEDIUM
	sun.directional_shadow_max_distance = [0.0, 60.0, 90.0, 130.0][quality]
	var msaa := [Viewport.MSAA_DISABLED, Viewport.MSAA_DISABLED, Viewport.MSAA_2X, Viewport.MSAA_4X]
	get_viewport().msaa_3d = msaa[quality]
	world.set_tree_count([6, 12, 18, 24][quality])
	world.set_view_segments([7, 9, 11, 13][quality])
	_update_hud_text()


func _update_hud_text() -> void:
	if hud != null:
		hud.extra_text = "%s (F2)\nQUALITY %s (F1)" % [world.biome["name"], QUALITY_NAMES[quality]]
		if car.custom_failed:
			hud.extra_text += "\nCUSTOM CAR FAILED TO LOAD - using built-in car"


func _set_biome(b: int) -> void:
	biome = wrapi(b, 0, RoadWorld.BIOMES.size())
	world.set_biome(biome)
	var d: Dictionary = world.biome
	_sky_mat.sky_top_color = d["sky_top"]
	_sky_mat.sky_horizon_color = d["sky_hor"]
	_sky_mat.ground_horizon_color = d["sky_hor"]
	_sky_mat.ground_bottom_color = d["ground"]
	_env.fog_light_color = d["fog"]
	_env.fog_density = d["fog_d"]
	world.update_for(car.global_position)
	_update_hud_text()


func _setup_environment() -> void:
	var sm := ProceduralSkyMaterial.new()
	_sky_mat = sm
	sm.sky_top_color = Color(0.25, 0.45, 0.8)
	sm.sky_horizon_color = Color(0.7, 0.8, 0.9)
	sm.ground_horizon_color = Color(0.6, 0.68, 0.6)
	sm.ground_bottom_color = Color(0.3, 0.4, 0.3)
	var sky := Sky.new()
	sky.sky_material = sm
	var env := Environment.new()
	_env = env
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.9
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_light_color = Color(0.72, 0.8, 0.9)
	env.fog_density = 0.0012
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -35, 0)
	sun.light_energy = 1.3
	sun.shadow_enabled = true
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	add_child(sun)


func _exit_tree() -> void:
	for pair in [[GameInput.back_pressed, _on_back], [GameInput.accept_pressed, _on_accept],
			[GameInput.pause_pressed, _toggle_pause], [GameInput.camera_pressed, _on_camera],
			[PhoneServer.slot_changed, _on_slot_changed], [PhoneServer.car_selected, _on_car_selected]]:
		if pair[0].is_connected(pair[1]):
			pair[0].disconnect(pair[1])
