#!/usr/bin/env python3
"""Make the Godot Android gradle template an Android TV app (idempotent).
Adds the LEANBACK_LAUNCHER category (so it appears on the TV home screen),
marks touchscreen/leanback as optional, and sets a TV banner.
Fails loudly if the template layout is not what we expect."""
import pathlib, re, sys

p = pathlib.Path("android/build/AndroidManifest.xml")
s = p.read_text(encoding="utf-8")

if "LEANBACK_LAUNCHER" not in s:
    s, n = re.subn(
        r'(<category\s+android:name="android\.intent\.category\.LAUNCHER"\s*/>)',
        r'\1\n                <category android:name="android.intent.category.LEANBACK_LAUNCHER" />',
        s, count=1)
    if n == 0:
        sys.exit("ERROR: LAUNCHER category not found in manifest")

feats = ""
if "android.software.leanback" not in s:
    feats += '    <uses-feature android:name="android.software.leanback" android:required="false" />\n'
if "android.hardware.touchscreen" not in s:
    feats += '    <uses-feature android:name="android.hardware.touchscreen" android:required="false" />\n'
if feats:
    s = s.replace("<application", feats + "    <application", 1)

if "android:banner" not in s:
    s = s.replace("<application", '<application android:banner="@mipmap/icon"', 1)

if "LEANBACK_LAUNCHER" not in s:
    sys.exit("ERROR: manifest patch failed")
p.write_text(s, encoding="utf-8")
print("Android TV manifest patch applied")
