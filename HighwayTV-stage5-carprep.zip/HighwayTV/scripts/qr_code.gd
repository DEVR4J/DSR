class_name QrCode
extends RefCounted
## Small QR-code encoder (byte mode, error correction L, versions 1-6 -> up to
## 134 bytes; verified by decoding). Algorithm follows the public ISO 18004 steps. Use QrCode.make_image().

const ECC_PER_BLOCK := [0, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18]
const NUM_BLOCKS := [0, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4]

var size := 0
var m := PackedByteArray()      # module colours (1 = dark), index y * size + x
var f := PackedByteArray()      # 1 = function module (not masked / not data)
var valid := false


static func make_image(text: String, px := 8, border := 4) -> Image:
	var q := QrCode.new()
	q.build(text.to_utf8_buffer())
	if not q.valid:
		return null
	var dim := (q.size + border * 2) * px
	var img := Image.create(dim, dim, false, Image.FORMAT_L8)
	img.fill(Color.WHITE)
	for y in q.size:
		for x in q.size:
			if q.m[y * q.size + x] == 1:
				img.fill_rect(Rect2i((x + border) * px, (y + border) * px, px, px), Color.BLACK)
	return img


static func _raw_modules(ver: int) -> int:
	var r := (16 * ver + 128) * ver + 64
	if ver >= 2:
		var na := ver / 7 + 2
		r -= (25 * na - 10) * na - 55
		if ver >= 7:
			r -= 36
	return r


static func _data_codewords(ver: int) -> int:
	return _raw_modules(ver) / 8 - ECC_PER_BLOCK[ver] * NUM_BLOCKS[ver]


static func _append(bits: PackedByteArray, val: int, n: int) -> void:
	for i in range(n - 1, -1, -1):
		bits.append((val >> i) & 1)


static func _gf_mul(x: int, y: int) -> int:
	var z := 0
	for i in range(7, -1, -1):
		z = (z << 1) ^ ((z >> 7) * 0x11D)
		z ^= ((y >> i) & 1) * x
	return z


static func _rs_gen(deg: int) -> PackedByteArray:
	var r := PackedByteArray()
	r.resize(deg)
	r[deg - 1] = 1
	var root := 1
	for i in deg:
		for j in deg:
			r[j] = _gf_mul(r[j], root)
			if j + 1 < deg:
				r[j] ^= r[j + 1]
		root = _gf_mul(root, 2)
	return r


static func _rs_rem(data: PackedByteArray, gen: PackedByteArray) -> PackedByteArray:
	var res := PackedByteArray()
	res.resize(gen.size())
	for b in data:
		var factor: int = b ^ res[0]
		res.remove_at(0)
		res.append(0)
		for i in res.size():
			res[i] ^= _gf_mul(gen[i], factor)
	return res


func build(data: PackedByteArray) -> void:
	var ver := 1
	var cc_bits := 8
	while ver <= 6:
		cc_bits = 8 if ver <= 9 else 16
		if 4 + cc_bits + data.size() * 8 <= _data_codewords(ver) * 8:
			break
		ver += 1
	if ver > 6:
		return
	var bits := PackedByteArray()
	_append(bits, 4, 4)
	_append(bits, data.size(), cc_bits)
	for b in data:
		_append(bits, b, 8)
	var cap := _data_codewords(ver) * 8
	_append(bits, 0, mini(4, cap - bits.size()))
	_append(bits, 0, (8 - bits.size() % 8) % 8)
	var pad := 0xEC
	while bits.size() < cap:
		_append(bits, pad, 8)
		pad = 0x11 if pad == 0xEC else 0xEC
	var dc := PackedByteArray()
	dc.resize(bits.size() / 8)
	for i in bits.size():
		dc[i >> 3] = dc[i >> 3] | (bits[i] << (7 - (i & 7)))

	# error correction + interleave
	var nb: int = NUM_BLOCKS[ver]
	var ecc_len: int = ECC_PER_BLOCK[ver]
	var raw_cw := _raw_modules(ver) / 8
	var num_short := nb - raw_cw % nb
	var short_len := raw_cw / nb
	var gen := _rs_gen(ecc_len)
	var blocks: Array = []
	var k := 0
	for i in nb:
		var dlen := short_len - ecc_len + (0 if i < num_short else 1)
		var d := dc.slice(k, k + dlen)
		k += dlen
		var ecc := _rs_rem(d, gen)
		if i < num_short:
			d.append(0)
		d.append_array(ecc)
		blocks.append(d)
	var result := PackedByteArray()
	for i in (blocks[0] as PackedByteArray).size():
		for j in nb:
			if i != short_len - ecc_len or j >= num_short:
				result.append((blocks[j] as PackedByteArray)[i])

	size = ver * 4 + 17
	m.resize(size * size)
	f.resize(size * size)
	_draw_function(ver)
	_draw_codewords(result)
	var best := 0
	var best_pen := 1 << 30
	for mk in 8:
		_apply_mask(mk)
		_format_bits(mk)
		var p := _penalty()
		if p < best_pen:
			best_pen = p
			best = mk
		_apply_mask(mk)
	_apply_mask(best)
	_format_bits(best)
	valid = true


func _setfn(x: int, y: int, dark: bool) -> void:
	if x < 0 or y < 0 or x >= size or y >= size:
		return
	m[y * size + x] = 1 if dark else 0
	f[y * size + x] = 1


func _finder(cx: int, cy: int) -> void:
	for dy in range(-4, 5):
		for dx in range(-4, 5):
			var dist := maxi(absi(dx), absi(dy))
			_setfn(cx + dx, cy + dy, dist != 2 and dist != 4)


func _alignment(cx: int, cy: int) -> void:
	for dy in range(-2, 3):
		for dx in range(-2, 3):
			_setfn(cx + dx, cy + dy, maxi(absi(dx), absi(dy)) != 1)


func _align_pos(ver: int) -> Array:
	if ver == 1:
		return []
	var na := ver / 7 + 2
	var step := int(ceil(float(ver * 4 + na * 2 + 1) / float(na * 2 - 2))) * 2
	var res := [6]
	var pos := size - 7
	while res.size() < na:
		res.insert(1, pos)
		pos -= step
	return res


func _draw_function(ver: int) -> void:
	for i in size:
		_setfn(6, i, i % 2 == 0)
		_setfn(i, 6, i % 2 == 0)
	_finder(3, 3)
	_finder(size - 4, 3)
	_finder(3, size - 4)
	var al := _align_pos(ver)
	var n := al.size()
	for i in n:
		for j in n:
			if not ((i == 0 and j == 0) or (i == 0 and j == n - 1) or (i == n - 1 and j == 0)):
				_alignment(al[i], al[j])
	_format_bits(0)
	if ver >= 7:
		var rem := ver
		for i in 12:
			rem = (rem << 1) ^ ((rem >> 11) * 0x1F25)
		var bits := (ver << 12) | rem
		for i in 18:
			var c := ((bits >> i) & 1) == 1
			var a := size - 11 + i % 3
			var b := i / 3
			_setfn(a, b, c)
			_setfn(b, a, c)


func _format_bits(mask: int) -> void:
	var data := (1 << 3) | mask          # ECC level L = 01
	var rem := data
	for i in 10:
		rem = (rem << 1) ^ ((rem >> 9) * 0x537)
	var bits := ((data << 10) | rem) ^ 0x5412
	for i in 6:
		_setfn(8, i, ((bits >> i) & 1) == 1)
	_setfn(8, 7, ((bits >> 6) & 1) == 1)
	_setfn(8, 8, ((bits >> 7) & 1) == 1)
	_setfn(7, 8, ((bits >> 8) & 1) == 1)
	for i in range(9, 15):
		_setfn(14 - i, 8, ((bits >> i) & 1) == 1)
	for i in 8:
		_setfn(size - 1 - i, 8, ((bits >> i) & 1) == 1)
	for i in range(8, 15):
		_setfn(8, size - 15 + i, ((bits >> i) & 1) == 1)
	_setfn(8, size - 8, true)


func _draw_codewords(data: PackedByteArray) -> void:
	var i := 0
	var right := size - 1
	while right >= 1:
		if right == 6:
			right = 5
		for vert in size:
			for j in 2:
				var x := right - j
				var upward := ((right + 1) & 2) == 0
				var y := size - 1 - vert if upward else vert
				if f[y * size + x] == 0 and i < data.size() * 8:
					m[y * size + x] = (data[i >> 3] >> (7 - (i & 7))) & 1
					i += 1
		right -= 2


func _apply_mask(mask: int) -> void:
	for y in size:
		for x in size:
			var inv := false
			match mask:
				0: inv = (x + y) % 2 == 0
				1: inv = y % 2 == 0
				2: inv = x % 3 == 0
				3: inv = (x + y) % 3 == 0
				4: inv = (x / 3 + y / 2) % 2 == 0
				5: inv = x * y % 2 + x * y % 3 == 0
				6: inv = (x * y % 2 + x * y % 3) % 2 == 0
				7: inv = ((x + y) % 2 + x * y % 3) % 2 == 0
			if inv and f[y * size + x] == 0:
				m[y * size + x] ^= 1


func _line_penalty(line: PackedByteArray) -> int:
	var res := 0
	var run := 1
	for i in range(1, line.size()):
		if line[i] == line[i - 1]:
			run += 1
			if run == 5:
				res += 3
			elif run > 5:
				res += 1
		else:
			run = 1
	var p1 := [1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0]
	var p2 := [0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1]
	for s in range(0, line.size() - 10):
		var a := true
		var b := true
		for k in 11:
			if line[s + k] != p1[k]:
				a = false
			if line[s + k] != p2[k]:
				b = false
			if not a and not b:
				break
		if a or b:
			res += 40
	return res


func _penalty() -> int:
	var res := 0
	var dark := 0
	for a in size:
		var row := PackedByteArray()
		var col := PackedByteArray()
		for b in size:
			row.append(m[a * size + b])
			col.append(m[b * size + a])
			dark += m[a * size + b]
		res += _line_penalty(row) + _line_penalty(col)
	for y in size - 1:
		for x in size - 1:
			var c := m[y * size + x]
			if c == m[y * size + x + 1] and c == m[(y + 1) * size + x] and c == m[(y + 1) * size + x + 1]:
				res += 3
	var total := size * size
	var kk := int(ceil(absf(dark * 20.0 - total * 10.0) / total)) - 1
	res += maxi(kk, 0) * 10
	return res
