extends Node
## Autoload "GameState": selections that survive scene changes.

var car_id := ""        # "" = built-in car, otherwise a saved custom car id
var biome := 0
var speed_kmh := 0.0     # telemetry for the phone page / HUD
var gear_text := ""
# camera sliders (shared by the pause menu, phone page and camera)
var cam_dist := 1.0      # orbit distance multiplier 0 .. 2.5 (0 = inside the car in FREE VIEW)
var cam_zoom := 1.0      # field-of-view zoom 0.5 .. 4
var cam_pitch := 0.0     # extra angle up/down in degrees -20 .. 70
var cam_yaw := 0.0       # rotation around the car -180 .. 180 (0 = behind)


func goto(path: String) -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file(path)
