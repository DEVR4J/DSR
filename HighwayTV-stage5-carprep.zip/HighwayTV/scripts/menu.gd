extends Control
## Main menu (Stage 3 minimal version; full styling comes in Stage 6).
## D-pad up/down moves, left/right changes CAR / ENVIRONMENT, OK selects, BACK exits.

var _cars: Array[String] = [""]      # "" = built-in car
var _car_idx := 0
var _names: Array[String] = ["BUILT-IN COUPE"]
var _buttons: Array[Button] = []
var _msg: Label


func _ready() -> void:
	for id in CarSpec.list_ids():
		var s := CarSpec.load_spec(id)
		_cars.append(id)
		_names.append(str(s.get("name", id)).to_upper())
	_car_idx = maxi(_cars.find(GameState.car_id), 0)

	var bg := ColorRect.new()
	bg.color = Color(0.04, 0.05, 0.07)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var stripe := ColorRect.new()
	stripe.color = Color(0.9, 0.1, 0.15)
	stripe.position = Vector2(120, 150)
	stripe.size = Vector2(10, 220)
	add_child(stripe)
	var title := Label.new()
	title.text = "HIGHWAY TV"
	title.add_theme_font_size_override("font_size", 120)
	title.position = Vector2(160, 110)
	add_child(title)
	var sub := Label.new()
	sub.text = "ENDLESS DRIVING SIMULATOR"
	sub.add_theme_font_size_override("font_size", 34)
	sub.modulate = Color(1, 1, 1, 0.6)
	sub.position = Vector2(166, 270)
	add_child(sub)

	var box := VBoxContainer.new()
	box.position = Vector2(160, 430)
	box.custom_minimum_size = Vector2(900, 0)
	box.add_theme_constant_override("separation", 12)
	add_child(box)
	_add(box, _t_drive, Callable(), _drive)
	_add(box, _t_car, _adj_car, _drive)
	_add(box, _t_const.bind("IMPORT CUSTOM CAR"), Callable(), _import)
	_add(box, _t_env, _adj_env, Callable())
	_add(box, _t_const.bind("CAR PREP (optimize a model)"), Callable(), _prep)
	_add(box, _t_const.bind("PHONE CONTROLLER"), Callable(), _phone)
	_add(box, _t_delete, Callable(), _delete_car)
	_add(box, _t_const.bind("SCRIPT CHECK (diagnostics)"), Callable(), _diag)
	_add(box, _t_const.bind("EXIT"), Callable(), _exit)

	_msg = Label.new()
	_msg.position = Vector2(160, 1000)
	_msg.add_theme_font_size_override("font_size", 24)
	add_child(_msg)
	_refresh()
	_buttons[0].grab_focus()
	GameInput.back_pressed.connect(_exit)


func _exit_tree() -> void:
	if GameInput.back_pressed.is_connected(_exit):
		GameInput.back_pressed.disconnect(_exit)


func _add(box: VBoxContainer, text_fn: Callable, adjust_fn: Callable, press_fn: Callable) -> void:
	var b := Button.new()
	b.custom_minimum_size = Vector2(0, 84)
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.add_theme_font_size_override("font_size", 38)
	b.set_meta("text_fn", text_fn)
	b.set_meta("adjust", adjust_fn)
	b.set_meta("press", press_fn)
	b.pressed.connect(_on_pressed.bind(b))
	b.gui_input.connect(_on_input.bind(b))
	box.add_child(b)
	_buttons.append(b)


func _on_pressed(b: Button) -> void:
	var f: Callable = b.get_meta("press")
	if f.is_valid():
		f.call()


func _on_input(ev: InputEvent, b: Button) -> void:
	var d := 0
	if ev.is_action_pressed("ui_left", true):
		d = -1
	elif ev.is_action_pressed("ui_right", true):
		d = 1
	var f: Callable = b.get_meta("adjust")
	if d != 0 and f.is_valid():
		f.call(d)
		b.accept_event()
		_refresh()


func _refresh() -> void:
	for b in _buttons:
		b.text = (b.get_meta("text_fn") as Callable).call()


func _t_const(s: String) -> String:
	return s

func _t_drive() -> String:
	return "DRIVE NOW"

func _t_car() -> String:
	return "CAR      <  %s  >" % _names[_car_idx]

func _adj_car(d: int) -> void:
	_car_idx = wrapi(_car_idx + d, 0, _cars.size())

func _t_env() -> String:
	return "ENVIRONMENT      <  %s  >" % RoadWorld.BIOMES[GameState.biome]["name"]

func _adj_env(d: int) -> void:
	GameState.biome = wrapi(GameState.biome + d, 0, RoadWorld.BIOMES.size())

func _t_delete() -> String:
	return "DELETE SELECTED CUSTOM CAR" if _cars[_car_idx] != "" else "(select a custom car to delete it)"


func _drive() -> void:
	GameState.car_id = _cars[_car_idx]
	GameState.goto("res://scenes/main.tscn")


func _diag() -> void:
	GameState.goto("res://scenes/diag.tscn")


func _prep() -> void:
	GameState.goto("res://scenes/prep.tscn")


func _phone() -> void:
	GameState.goto("res://scenes/phone.tscn")


func _import() -> void:
	GameState.goto("res://scenes/importer.tscn")


func _delete_car() -> void:
	if _cars[_car_idx] == "":
		return
	CarSpec.delete(_cars[_car_idx])
	_msg.text = "Deleted %s" % _names[_car_idx]
	_cars.remove_at(_car_idx)
	_names.remove_at(_car_idx)
	_car_idx = 0
	_refresh()


func _exit() -> void:
	get_tree().quit()
