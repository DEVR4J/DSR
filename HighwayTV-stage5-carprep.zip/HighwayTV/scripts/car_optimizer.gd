class_name CarOptimizer
extends RefCounted
## Makes an arbitrary downloaded car model light enough for a TV and gives it
## sensible handling:
##  - removes cameras/lights/hidden parts
##  - reduces triangles with vertex clustering (Godot export builds do not ship
##    a mesh simplifier, so this is our own; wheels keep extra detail, meshes stay
##    separate so wheels can still spin)
##  - downsizes textures (and drops normal maps on LOW/BALANCED)
##  - picks a handling preset (compact/sedan/SUV/sports/truck) from the model's size
## run() is safe to call from a worker thread (it only touches the detached scene).

const PROFILES := [
	{"name": "LOW (weak TV)", "tris": 30000, "tex": 512, "normal_maps": false},
	{"name": "BALANCED", "tris": 70000, "tex": 1024, "normal_maps": false},
	{"name": "HIGH", "tris": 140000, "tex": 2048, "normal_maps": true},
]
const MIN_TRIS := 200

## Handling presets. Keys match CarSpec / the importer (see CarSpec.defaults()).
const PRESETS := {
	"COMPACT": {"mass": 1050.0, "peak_torque": 220.0, "redline": 6500.0, "susp_stiffness": 26.0,
		"damp_comp": 0.45, "damp_rel": 0.65, "max_steer": 34.0, "brake_per_kg": 0.03, "gears": 5.0,
		"final_drive": 4.1, "grip_front": 1.25, "grip_rear": 1.15, "drag_cd_a": 0.65},
	"SEDAN": {"mass": 1400.0, "peak_torque": 340.0, "redline": 6800.0, "susp_stiffness": 28.0,
		"damp_comp": 0.45, "damp_rel": 0.65, "max_steer": 30.0, "brake_per_kg": 0.03, "gears": 6.0,
		"final_drive": 3.9, "grip_front": 1.3, "grip_rear": 1.2, "drag_cd_a": 0.7},
	"SUV": {"mass": 1900.0, "peak_torque": 420.0, "redline": 6200.0, "susp_stiffness": 24.0,
		"damp_comp": 0.5, "damp_rel": 0.7, "max_steer": 28.0, "brake_per_kg": 0.032, "gears": 6.0,
		"final_drive": 4.0, "grip_front": 1.2, "grip_rear": 1.1, "drag_cd_a": 0.95},
	"SPORTS": {"mass": 1300.0, "peak_torque": 480.0, "redline": 7600.0, "susp_stiffness": 34.0,
		"damp_comp": 0.5, "damp_rel": 0.7, "max_steer": 28.0, "brake_per_kg": 0.036, "gears": 6.0,
		"final_drive": 3.7, "grip_front": 1.45, "grip_rear": 1.35, "drag_cd_a": 0.6},
	"TRUCK / VAN": {"mass": 2600.0, "peak_torque": 650.0, "redline": 5000.0, "susp_stiffness": 22.0,
		"damp_comp": 0.55, "damp_rel": 0.75, "max_steer": 26.0, "brake_per_kg": 0.035, "gears": 6.0,
		"final_drive": 4.3, "grip_front": 1.15, "grip_rear": 1.05, "drag_cd_a": 1.3},
}

static var progress := 0.0
static var progress_text := ""


static func _p(v: float, t: String) -> void:
	progress = v
	progress_text = t


# -------------------------------------------------------------------- stats
static func _surface_tris(m: Mesh, s: int) -> int:
	var n := m.surface_get_array_index_len(s)
	if n == 0:
		n = m.surface_get_array_len(s)
	return n / 3


static func _mesh_tris(m: Mesh) -> int:
	var n := 0
	if m == null:
		return 0
	for s in m.get_surface_count():
		n += _surface_tris(m, s)
	return n


static func stats(root: Node) -> Dictionary:
	var tris := 0
	var tex_bytes := 0
	var seen := {}
	var meshes := CarImporter.mesh_nodes(root)
	for mi in meshes:
		var m := (mi as MeshInstance3D).mesh
		if m == null:
			continue
		tris += _mesh_tris(m)
		for s in m.get_surface_count():
			var mat := m.surface_get_material(s)
			if mat is BaseMaterial3D:
				for p in BaseMaterial3D.TEXTURE_MAX:
					var t: Texture2D = (mat as BaseMaterial3D).get_texture(p)
					if t != null and not seen.has(t):
						seen[t] = true
						tex_bytes += t.get_width() * t.get_height() * 4
	return {"tris": tris, "meshes": meshes.size(), "textures": seen.size(), "tex_mb": tex_bytes / 1048576.0}


# ----------------------------------------------------------------- optimize
static func run(root: Node3D, prof: Dictionary) -> Dictionary:
	var before := stats(root)
	_p(0.03, "Cleaning scene")
	_clean(root)
	var meshes := CarImporter.mesh_nodes(root)
	var total := 0
	for mi in meshes:
		total += _mesh_tris((mi as MeshInstance3D).mesh)
	var budget: int = prof["tris"]
	var seen := {}
	var done := 0
	for mi in meshes:
		var node := mi as MeshInstance3D
		var m := node.mesh
		var mt := _mesh_tris(m)
		var share := maxi(int(float(budget) * mt / maxf(total, 1.0)), MIN_TRIS)
		if CarImporter._is_wheel_name(str(node.name)):
			share = maxi(share, 1500)
		if m is ArrayMesh and total > budget and mt > int(share * 1.15):
			if seen.has(m):
				node.mesh = seen[m]
			else:
				var nm := _decimate_mesh(m as ArrayMesh, share, bool(prof["normal_maps"]))
				seen[m] = nm
				node.mesh = nm
		done += mt
		_p(0.05 + 0.6 * float(done) / maxf(total, 1.0), "Simplifying %s" % node.name)

	_p(0.7, "Shrinking textures")
	var cache := {}
	var max_px: int = prof["tex"]
	for mi in CarImporter.mesh_nodes(root):
		var m := (mi as MeshInstance3D).mesh
		if m == null or not (m is ArrayMesh):
			continue
		for s in m.get_surface_count():
			var mat := m.surface_get_material(s)
			if mat is BaseMaterial3D:
				_opt_material(mat, max_px, bool(prof["normal_maps"]), cache)
	_p(0.9, "Optimized")
	return {"before": before, "after": stats(root)}


static func _clean(root: Node3D) -> void:
	for cls in ["Camera3D", "Light3D", "AudioStreamPlayer3D", "WorldEnvironment"]:
		for n in root.find_children("*", cls, true, false):
			(n as Node).get_parent().remove_child(n)
			(n as Node).free()
	for mi in CarImporter.mesh_nodes(root):
		var node := mi as MeshInstance3D
		if node != root and not node.visible:
			node.get_parent().remove_child(node)
			node.free()


static func _opt_material(mat: BaseMaterial3D, max_px: int, keep_normal: bool, cache: Dictionary) -> void:
	if cache.has(mat):
		return
	cache[mat] = true
	for p in BaseMaterial3D.TEXTURE_MAX:
		var t: Texture2D = mat.get_texture(p)
		if t == null:
			continue
		if p == BaseMaterial3D.TEXTURE_NORMAL and not keep_normal:
			mat.normal_enabled = false
			mat.set_texture(p, null)
			continue
		if not cache.has(t):
			cache[t] = _shrink(t, max_px)
		mat.set_texture(p, cache[t])


static func _shrink(t: Texture2D, max_px: int) -> Texture2D:
	var img := t.get_image()
	if img == null:
		return t
	var big := maxi(img.get_width(), img.get_height())
	if big <= max_px:
		return t
	if img.is_compressed():
		img.decompress()
	var sc := float(max_px) / float(big)
	img.resize(maxi(1, int(img.get_width() * sc)), maxi(1, int(img.get_height() * sc)), Image.INTERPOLATE_LANCZOS)
	return ImageTexture.create_from_image(img)


static func _decimate_mesh(m: ArrayMesh, target: int, keep_tangents: bool) -> ArrayMesh:
	var out := ArrayMesh.new()
	var total := maxi(_mesh_tris(m), 1)
	for s in m.get_surface_count():
		var prim := m.surface_get_primitive_type(s)
		var arr := m.surface_get_arrays(s)
		var mat := m.surface_get_material(s)
		var tris := _surface_tris(m, s)
		var share := maxi(int(float(target) * tris / total), 100)
		if prim == Mesh.PRIMITIVE_TRIANGLES and arr[Mesh.ARRAY_BONES] == null \
				and arr[Mesh.ARRAY_VERTEX] != null and tris > int(share * 1.15):
			arr = cluster(arr, share, keep_tangents)
		out.add_surface_from_arrays(prim, arr)
		out.surface_set_material(out.get_surface_count() - 1, mat)
	return out


static func _keys(V: PackedVector3Array, uvq: PackedInt32Array, mn: Vector3, cell: float, has_uv: bool) -> PackedInt64Array:
	var k := PackedInt64Array()
	k.resize(V.size())
	var inv := 1.0 / cell
	for i in V.size():
		var v := V[i]
		var key := int((v.x - mn.x) * inv) + int((v.y - mn.y) * inv) * 4096 + int((v.z - mn.z) * inv) * 16777216
		if has_uv:
			key = key * 1024 + uvq[i]
		k[i] = key
	return k


static func _count(keys: PackedInt64Array, I: PackedInt32Array) -> int:
	var n := 0
	for t in range(0, I.size() - 2, 3):
		var a := keys[I[t]]
		var b := keys[I[t + 1]]
		var c := keys[I[t + 2]]
		if a != b and b != c and a != c:
			n += 1
	return n


## Vertex-clustering simplification of one triangle surface to about `target`
## triangles. Vertices are merged per grid cell (and per coarse UV cell so
## texture seams survive); the cell size is searched to hit the target.
static func cluster(arr: Array, target: int, keep_tangents: bool) -> Array:
	var V: PackedVector3Array = arr[Mesh.ARRAY_VERTEX]
	if V.is_empty():
		return arr
	var has_n: bool = arr[Mesh.ARRAY_NORMAL] != null
	var has_uv: bool = arr[Mesh.ARRAY_TEX_UV] != null
	var N := PackedVector3Array()
	if has_n:
		N = arr[Mesh.ARRAY_NORMAL]
	var UV := PackedVector2Array()
	if has_uv:
		UV = arr[Mesh.ARRAY_TEX_UV]
	var I := PackedInt32Array()
	if arr[Mesh.ARRAY_INDEX] != null:
		I = arr[Mesh.ARRAY_INDEX]
	else:
		I.resize(V.size())
		for i in V.size():
			I[i] = i
	var mn := V[0]
	var mx := V[0]
	for v in V:
		mn = mn.min(v)
		mx = mx.max(v)
	var ext := maxf(mx.x - mn.x, maxf(mx.y - mn.y, mx.z - mn.z))
	if ext <= 0.0:
		return arr
	var uvq := PackedInt32Array()
	if has_uv:
		uvq.resize(V.size())
		for i in V.size():
			uvq[i] = ((int(UV[i].x * 32.0)) & 31) * 32 + ((int(UV[i].y * 32.0)) & 31)

	var cell := ext / 600.0
	var keys := PackedInt64Array()
	var best_keys := PackedInt64Array()
	var best_n := -1
	var accepted := false
	for it in 7:
		keys = _keys(V, uvq, mn, cell, has_uv)
		var n := _count(keys, I)
		if n <= int(target * 1.2) and n >= int(target * 0.6):
			accepted = true
			break
		if n <= int(target * 1.2) and n > best_n:
			best_n = n
			best_keys = keys
		cell = clampf(cell * clampf(sqrt(float(n) / maxf(target, 1.0)), 0.5, 2.5), ext / 4000.0, ext)
	if not accepted and best_n >= 0:
		keys = best_keys

	var map := {}
	var nv := PackedVector3Array()
	var cnt := PackedInt32Array()
	var nn := PackedVector3Array()
	var nuv := PackedVector2Array()
	var remap := PackedInt32Array()
	remap.resize(V.size())
	for i in V.size():
		var k := keys[i]
		var idx: int = map.get(k, -1)
		if idx < 0:
			idx = nv.size()
			map[k] = idx
			nv.append(V[i])
			cnt.append(1)
			if has_n:
				nn.append(N[i])
			if has_uv:
				nuv.append(UV[i])
		else:
			nv[idx] += V[i]
			cnt[idx] += 1
			if has_n:
				nn[idx] += N[i]
		remap[i] = idx
	var ni := PackedInt32Array()
	var used := PackedByteArray()
	used.resize(nv.size())
	for t in range(0, I.size() - 2, 3):
		var a := remap[I[t]]
		var b := remap[I[t + 1]]
		var c := remap[I[t + 2]]
		if a != b and b != c and a != c:
			ni.append(a)
			ni.append(b)
			ni.append(c)
			used[a] = 1
			used[b] = 1
			used[c] = 1
	if ni.is_empty():
		return arr                       # never destroy a mesh
	var cmap := PackedInt32Array()
	cmap.resize(nv.size())
	var fv := PackedVector3Array()
	var fn := PackedVector3Array()
	var fuv := PackedVector2Array()
	for j in nv.size():
		if used[j] == 1:
			cmap[j] = fv.size()
			fv.append(nv[j] / float(cnt[j]))
			if has_n:
				fn.append(nn[j].normalized())
			if has_uv:
				fuv.append(nuv[j])
	for q in ni.size():
		ni[q] = cmap[ni[q]]
	var out := []
	out.resize(Mesh.ARRAY_MAX)
	out[Mesh.ARRAY_VERTEX] = fv
	if has_n:
		out[Mesh.ARRAY_NORMAL] = fn
	if has_uv:
		out[Mesh.ARRAY_TEX_UV] = fuv
	out[Mesh.ARRAY_INDEX] = ni
	if not has_n or (keep_tangents and has_uv):
		var st := SurfaceTool.new()
		st.create_from_arrays(out)
		if not has_n:
			st.generate_normals()
		if keep_tangents and has_uv:
			st.generate_tangents()
		out = st.commit_to_arrays()
	return out


# ------------------------------------------------------------------ balance
## Picks a handling preset from the analysed model (CarImporter.analyze report).
static func balance(rep: Dictionary) -> Dictionary:
	var bs := CarSpec.v3(rep["body_size"])
	var length := maxf(float(rep.get("length", bs.z)), 0.1)
	var ratio := bs.y / length
	var cls := "SEDAN"
	if length < 3.9:
		cls = "COMPACT"
	elif length > 5.3:
		cls = "TRUCK / VAN"
	elif ratio > 0.33:
		cls = "SUV"
	elif ratio < 0.28 and length > 4.0:
		cls = "SPORTS"
	var p: Dictionary = (PRESETS[cls] as Dictionary).duplicate()
	p["mass"] = lerpf(float(p["mass"]), float(rep.get("mass", p["mass"])), 0.25)
	return {"class": cls, "params": p}
