class_name CarImporter
extends RefCounted
## Imports a user 3D model and turns it into a drivable-car description.
##  1. stage_files(): copies picked files (SAF content:// URIs or normal paths)
##     into user://cars/<id>/ so later loads never need the picker again.
##  2. load_model(): GLB/GLTF via GLTFDocument, OBJ via ObjLoader.
##  3. analyze(): detects up axis, forward direction, scale, wheels, dimensions.
##  4. finalize(): derives wheel positions/radius/wheelbase/track/body bounds.
## Model space convention after analysis: car faces -Z, Y up, origin at the
## middle of the wheelbase at hub height, so wheel bottoms sit at y = -radius.

const MAX_BYTES := 64 * 1024 * 1024
const MODEL_EXT := ["glb", "gltf", "obj"]
const AUX_EXT := ["bin", "png", "jpg", "jpeg", "webp", "mtl", "tga", "bmp", "zip", "json"]
const MAX_UNZIPPED := 192 * 1024 * 1024
const CORNERS := ["fl", "fr", "rl", "rr"]
const FRONT_NAMES := ["headl", "headlamp", "hood", "bonnet", "grille", "foglight"]
const REAR_NAMES := ["taill", "tail_", "brakelight", "trunk", "boot", "exhaust", "spoiler"]

static var last_error := ""


# ------------------------------------------------------------------ staging
## Name of a file from a content:// URI or path ("" if it cannot be told).
static func uri_name(uri: String) -> String:
	var d := uri.uri_decode()
	var i := maxi(d.rfind("/"), d.rfind(":"))
	return d.substr(i + 1) if i >= 0 else d


static func sniff(b: PackedByteArray) -> String:
	if b.size() < 8:
		return ""
	if b.slice(0, 4).get_string_from_ascii() == "glTF":
		return "glb"
	if b[0] == 0x89 and b.slice(1, 4).get_string_from_ascii() == "PNG":
		return "png"
	if b[0] == 0xFF and b[1] == 0xD8:
		return "jpg"
	if b[0] == 0x50 and b[1] == 0x4B and b[2] == 0x03 and b[3] == 0x04:
		return "zip"
	var head := b.slice(0, mini(b.size(), 4096)).get_string_from_utf8()
	if head.strip_edges().begins_with("{") and head.contains("\"asset\""):
		return "gltf"
	if head.contains("newmtl "):
		return "mtl"
	if head.contains("\nv ") or head.begins_with("v ") or head.contains("\nf "):
		return "obj"
	return ""


## Copies the picked files into a fresh user://cars/<id>/ folder.
## Returns {ok, error, id, model, name}.
static func stage_files(paths: PackedStringArray, root := CarSpec.ROOT) -> Dictionary:
	var id := "car_%d" % int(Time.get_unix_time_from_system())
	var dir := "%s/%s" % [root, id]
	DirAccess.make_dir_recursive_absolute(dir)
	var total := 0
	var model := ""
	var n_unnamed := 0
	for p in paths:
		var bytes := FileAccess.get_file_as_bytes(p)
		if bytes.is_empty():
			continue
		total += bytes.size()
		if total > MAX_BYTES:
			CarSpec.remove_dir(dir)
			return {"ok": false, "error": "Files are larger than %d MB" % (MAX_BYTES / 1048576)}
		var nm := uri_name(p)
		var ext := nm.get_extension().to_lower()
		if ext == "zip" or (not (ext in MODEL_EXT or ext in AUX_EXT) and sniff(bytes) == "zip"):
			var z := _stage_zip(bytes, dir)
			if not z["ok"]:
				CarSpec.remove_dir(dir)
				return z
			if model == "":
				model = z["model"]
			continue
		if not (ext in MODEL_EXT or ext in AUX_EXT):
			ext = sniff(bytes)
			if ext == "":
				continue                         # unsupported file: ignore it
			n_unnamed += 1
			nm = "file_%d.%s" % [n_unnamed, ext]
		var f := FileAccess.open("%s/%s" % [dir, nm], FileAccess.WRITE)
		if f == null:
			continue
		f.store_buffer(bytes)
		f.close()
		if ext in MODEL_EXT and (model == "" or (ext == "glb" and not model.ends_with(".glb"))):
			model = "%s/%s" % [dir, nm]
	if model == "":
		CarSpec.remove_dir(dir)
		return {"ok": false, "error": "No readable GLB, GLTF, OBJ or ZIP file in the selection"}
	return {"ok": true, "id": id, "model": model, "name": model.get_file().get_basename()}


## Extracts a ZIP (kept folder structure, so glTF/OBJ texture paths still resolve)
## into dir and returns {ok, error, model}. Picks the best model file inside:
## GLB first, then GLTF, then OBJ (largest one if several).
static func _stage_zip(bytes: PackedByteArray, dir: String) -> Dictionary:
	var tmp := dir + "/_pack.zip"
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		return {"ok": false, "error": "Storage error while reading the ZIP"}
	f.store_buffer(bytes)
	f.close()
	var zr := ZIPReader.new()
	if zr.open(tmp) != OK:
		DirAccess.remove_absolute(tmp)
		return {"ok": false, "error": "Could not read the ZIP file (damaged or not a ZIP)"}
	var best := ""
	var best_rank := 99
	var best_size := -1
	var total := 0
	for entry in zr.get_files():
		var e := str(entry).replace("\\", "/").lstrip("/")
		if e.ends_with("/") or e == "":
			continue
		var skip := false
		for part in e.split("/"):
			if part == ".." or part.begins_with(".") or part == "__MACOSX":
				skip = true
		var ext := e.get_extension().to_lower()
		if skip or ext == "zip" or not (ext in MODEL_EXT or ext in AUX_EXT):
			continue
		var data := zr.read_file(entry)
		total += data.size()
		if data.size() > MAX_BYTES or total > MAX_UNZIPPED:
			zr.close()
			DirAccess.remove_absolute(tmp)
			return {"ok": false, "error": "ZIP contents are too large (limit %d MB)" % (MAX_UNZIPPED / 1048576)}
		var out := dir + "/" + e
		DirAccess.make_dir_recursive_absolute(out.get_base_dir())
		var w := FileAccess.open(out, FileAccess.WRITE)
		if w == null:
			continue
		w.store_buffer(data)
		w.close()
		if ext in MODEL_EXT:
			var rank := MODEL_EXT.find(ext)
			if rank < best_rank or (rank == best_rank and data.size() > best_size):
				best = out
				best_rank = rank
				best_size = data.size()
	zr.close()
	DirAccess.remove_absolute(tmp)
	if best == "":
		return {"ok": false, "error": "The ZIP has no .glb, .gltf or .obj file inside"}
	return {"ok": true, "model": best}


# ------------------------------------------------------------------ loading
static func load_model(path: String) -> Node3D:
	last_error = ""
	if not FileAccess.file_exists(path):
		last_error = "File not found"
		return null
	var ext := path.get_extension().to_lower()
	if ext == "obj":
		var n := ObjLoader.load_obj(path)
		if n == null:
			last_error = "Could not read OBJ (empty or invalid)"
		return n
	if ext == "glb" or ext == "gltf":
		var doc := GLTFDocument.new()
		var st := GLTFState.new()
		var err := doc.append_from_file(path, st)
		if err != OK:
			last_error = "Invalid or unsupported %s file (error %d). GLTF files that reference external .bin/texture files need those files selected too." % [ext.to_upper(), err]
			return null
		var node := doc.generate_scene(st)
		if node is Node3D:
			return node
		last_error = "Model has no 3D scene"
		return null
	last_error = "Unsupported file type"
	return null


# ----------------------------------------------------------------- geometry
static func mesh_nodes(root: Node) -> Array[MeshInstance3D]:
	var out: Array[MeshInstance3D] = []
	if root is MeshInstance3D:
		out.append(root)
	for n in root.find_children("*", "MeshInstance3D", true, false):
		out.append(n)
	return out


static func rel_path(node: Node, root: Node) -> String:
	var parts: Array[String] = []
	var n := node
	while n != null and n != root:
		parts.push_front(str(n.name))
		n = n.get_parent()
	return "/".join(parts)


static func xform_to_root(node: Node, root: Node) -> Transform3D:
	var t := Transform3D.IDENTITY
	var n := node
	while n != null:
		if n is Node3D:
			t = (n as Node3D).transform * t
		if n == root:
			break
		n = n.get_parent()
	return t


static func mesh_aabb(mi: MeshInstance3D, root: Node) -> AABB:
	return xform_to_root(mi, root) * mi.get_aabb()


## Union AABB of a list of meshes; returns AABB() (zero size) when empty.
static func _union(meshes: Array, root: Node) -> AABB:
	var u := AABB()
	var first := true
	for mi in meshes:
		if (mi as MeshInstance3D).mesh == null:
			continue
		var a := mesh_aabb(mi, root)
		u = a if first else u.merge(a)
		first = false
	return u


static func _node_meshes(nd: Node) -> Array[MeshInstance3D]:
	return mesh_nodes(nd)


static func _set_xform(root: Node3D, rot: Vector3, scale: float, offset: Vector3) -> void:
	var b := Basis.from_euler(Vector3(deg_to_rad(rot.x), deg_to_rad(rot.y), deg_to_rad(rot.z)))
	root.transform = Transform3D(b.scaled(Vector3.ONE * scale), offset)


static func apply_transform(root: Node3D, spec: Dictionary) -> void:
	_set_xform(root, CarSpec.v3(spec["rot"]), float(spec["scale"]), CarSpec.v3(spec["offset"]))


# ----------------------------------------------------------------- analysis
## Auto-detects orientation, scale and wheels. Pass manual_rot (degrees) to keep
## a user-chosen orientation. Returns a report dictionary (see finalize()).
static func analyze(root: Node3D, manual_rot: Variant = null) -> Dictionary:
	var rep := {"ok": false, "error": "", "method": "manual"}
	var meshes := mesh_nodes(root)
	_set_xform(root, Vector3.ZERO, 1.0, Vector3.ZERO)
	var all := _union(meshes, root)
	if meshes.is_empty() or all.size.length() < 0.001:
		rep["error"] = "Model contains no visible geometry"
		return rep
	var rot := Vector3.ZERO
	if manual_rot == null:
		if all.size.y >= maxf(all.size.x, all.size.z):
			rot.x = -90.0                         # Z-up export: length along Y
		_set_xform(root, rot, 1.0, Vector3.ZERO)
		all = _union(meshes, root)
		if all.size.x > all.size.z * 1.05:
			rot.y += 90.0                         # long axis was X
	else:
		rot = manual_rot
	_set_xform(root, rot, 1.0, Vector3.ZERO)
	all = _union(meshes, root)
	var length := all.size.z
	var scale := 1.0
	if length < 2.5 or length > 8.0:
		scale = 4.5 / maxf(length, 0.0001)
	_set_xform(root, rot, scale, Vector3.ZERO)
	all = _union(meshes, root)
	if manual_rot == null:
		var fr := _front_check(meshes, root, all)
		rep["method"] = fr[1]
		if fr[0]:
			rot.y += 180.0
			_set_xform(root, rot, scale, Vector3.ZERO)
	rep["rot"] = CarSpec.a3(rot)
	rep["scale"] = scale
	rep["wheels"] = _detect_wheels(meshes, root)
	rep["mesh_paths"] = []
	for mi in meshes:
		rep["mesh_paths"].append(rel_path(mi, root))
	finalize(rep, root)
	rep["ok"] = true
	return rep


## Splits a node name into lower-case word tokens ("WheelFL" -> wheel, fl;
## "wheel_wheel.1_0" -> wheel, wheel). Digits and punctuation separate words.
static func _tokens(nm: String) -> PackedStringArray:
	var out := PackedStringArray()
	var cur := ""
	var prev_lower := false
	for ch in nm:
		var is_letter := ch.to_lower() != ch.to_upper()
		if not is_letter:
			if cur != "":
				out.append(cur.to_lower())
				cur = ""
			prev_lower = false
			continue
		var is_upper := ch == ch.to_upper()
		if is_upper and prev_lower and cur != "":
			out.append(cur.to_lower())
			cur = ""
		cur += ch
		prev_lower = not is_upper
	if cur != "":
		out.append(cur.to_lower())
	return out


## Whole-word match, so "primary" (contains "rim") or "trim" are NOT wheels.
static func _is_wheel_name(nm: String) -> bool:
	var found := false
	for t in _tokens(nm):
		if t.begins_with("steer") or t.begins_with("spare") or t == "trim":
			return false
		if t.begins_with("wheel") or t.begins_with("tire") or t.begins_with("tyre") \
				or t == "rim" or t == "rims" or t == "whl":
			found = true
	return found


## Returns [needs_180_flip: bool, method: String]. Car faces -Z when no flip.
static func _front_check(meshes: Array, root: Node3D, all: AABB) -> Array:
	var cz := all.get_center().z
	var f_sum := 0.0
	var f_n := 0
	var r_sum := 0.0
	var r_n := 0
	for mi in meshes:
		var nm := str(mi.name).to_lower()
		var z := mesh_aabb(mi, root).get_center().z - cz
		for k in FRONT_NAMES:
			if nm.contains(k):
				f_sum += z
				f_n += 1
				break
		for k in REAR_NAMES:
			if nm.contains(k):
				r_sum += z
				r_n += 1
				break
	if f_n > 0 and r_n > 0 and absf(f_sum / f_n - r_sum / r_n) > 0.2:
		return [f_sum / f_n > r_sum / r_n, "part names"]
	if f_n > 0 and absf(f_sum / f_n) > 0.2:
		return [f_sum / f_n > 0.0, "part names"]
	if r_n > 0 and absf(r_sum / r_n) > 0.2:
		return [r_sum / r_n < 0.0, "part names"]
	# Roof shape: on most cars the highest point (cabin) sits behind the middle.
	var ys := PackedFloat32Array()
	var zs := PackedFloat32Array()
	var y_max := -INF
	for mi in meshes:
		var m := (mi as MeshInstance3D).mesh
		if m == null:
			continue
		var t := xform_to_root(mi, root)
		for s in m.get_surface_count():
			var arr := m.surface_get_arrays(s)
			if arr.is_empty() or arr[Mesh.ARRAY_VERTEX] == null:
				continue
			var verts: PackedVector3Array = arr[Mesh.ARRAY_VERTEX]
			var stride := maxi(1, verts.size() / 3000)
			for i in range(0, verts.size(), stride):
				var w := t * verts[i]
				ys.append(w.y)
				zs.append(w.z - cz)
				y_max = maxf(y_max, w.y)
	var y_thr := all.position.y + 0.85 * (y_max - all.position.y)
	var sum := 0.0
	var cnt := 0
	for i in ys.size():
		if ys[i] >= y_thr:
			sum += zs[i]
			cnt += 1
	if cnt == 0:
		return [false, "default"]
	return [sum / cnt < 0.0, "roof shape"]


## Groups wheel-like meshes into the four corners. Returns {fl:[paths], ...}.
static func _detect_wheels(meshes: Array, root: Node3D) -> Dictionary:
	var all := _union(meshes, root)
	var c0 := all.get_center()
	var out := {"fl": [], "fr": [], "rl": [], "rr": []}
	var cands: Array = []
	for pass_n in 2:
		for mi in meshes:
			var a := mesh_aabb(mi, root)
			var c := a.get_center()
			if c.y > all.position.y + 0.5 * all.size.y or (mi as MeshInstance3D).mesh == null:
				continue
			var s := a.size
			var named := _is_wheel_name(str(mi.name))
			# a real wheel part is small, narrow and low (rejects bumpers, panels, underbody)
			if named and not (maxf(s.y, s.z) <= 1.3 and s.x <= 0.6 * all.size.x \
					and c.y <= all.position.y + 0.45 * all.size.y):
				continue
			var round_ := absf(s.y - s.z) < 0.3 * maxf(s.y, s.z) and s.x < 0.8 * s.y and s.y > 0.3 and s.y < 1.3
			if (pass_n == 0 and named) or (pass_n == 1 and round_ and not named):
				cands.append(mi)
		# after pass 0 check coverage; if all corners covered skip geometric pass
		var covered := {}
		for mi in cands:
			var c := mesh_aabb(mi, root).get_center()
			covered[("f" if c.z < c0.z else "r") + ("l" if c.x < c0.x else "r")] = true
		if covered.size() == 4:
			break
	for mi in cands:
		var c := mesh_aabb(mi, root).get_center()
		var key := ("f" if c.z < c0.z else "r") + ("l" if c.x < c0.x else "r")
		out[key].append(rel_path(mi, root))
	return out


## Recomputes wheel positions, radius, wheelbase, track, body bounds and the
## model offset from rep["wheels"], rep["rot"], rep["scale"].
static func finalize(rep: Dictionary, root: Node3D) -> void:
	var rot := CarSpec.v3(rep["rot"])
	var scale := float(rep["scale"])
	_set_xform(root, rot, scale, Vector3.ZERO)
	var meshes := mesh_nodes(root)
	var all := _union(meshes, root)
	var wheels: Dictionary = rep["wheels"]
	var centers: Array = []
	var radii: Array[float] = []
	var widths: Array[float] = []
	var in_wheel := {}
	var found := 0
	var cc := all.get_center()
	for i in 4:
		var key: String = CORNERS[i]
		var u := AABB()
		var has := false
		for pth in wheels.get(key, []):
			var nd := root.get_node_or_null(NodePath(str(pth)))
			if nd == null:
				continue
			for mi in _node_meshes(nd):
				if mi.mesh == null:
					continue
				in_wheel[mi] = true
				var a := mesh_aabb(mi, root)
				u = a if not has else u.merge(a)
				has = true
		if has:
			found += 1
			centers.append(u.get_center())
			radii.append(maxf(u.size.y, u.size.z) * 0.5)
			widths.append(u.size.x)
		else:
			centers.append(null)
	var r_est := clampf(all.size.y * 0.24, 0.25, 0.45)
	var radius := r_est
	var wwidth := 0.25
	if found > 0:
		radius = 0.0
		wwidth = 0.0
		for r in radii:
			radius += r
		for w in widths:
			wwidth += w
		radius /= radii.size()
		wwidth /= widths.size()
	radius = clampf(radius, 0.15, 0.8)
	for i in 4:
		if centers[i] == null:
			var sx := -1.0 if i % 2 == 0 else 1.0
			var sz := -1.0 if i < 2 else 1.0
			centers[i] = Vector3(cc.x + sx * 0.43 * all.size.x, all.position.y + radius, cc.z + sz * 0.32 * all.size.z)
	var avg := Vector3.ZERO
	for c in centers:
		avg += c
	avg /= 4.0
	var offset := -avg
	var front_z := ((centers[0] as Vector3).z + (centers[1] as Vector3).z) * 0.5
	var rear_z := ((centers[2] as Vector3).z + (centers[3] as Vector3).z) * 0.5
	var left_x := ((centers[0] as Vector3).x + (centers[2] as Vector3).x) * 0.5
	var right_x := ((centers[1] as Vector3).x + (centers[3] as Vector3).x) * 0.5
	var body: Array[MeshInstance3D] = []
	for mi in meshes:
		if not in_wheel.has(mi):
			body.append(mi)
	var b := _union(body, root) if not body.is_empty() else all
	# Driver eye position: behind the steering wheel (works for left- and right-hand drive).
	var eye := Vector3(cc.x - 0.32, b.position.y + b.size.y * 0.72, cc.z + 0.05 * all.size.z)
	var driver_found := false
	var best_vol := 0.0
	for mi in meshes:
		if mi.mesh == null:
			continue
		var is_steer := false
		for t in _tokens(str(mi.name)):
			if t.begins_with("steer"):
				is_steer = true
		if is_steer:
			var sa := mesh_aabb(mi, root)
			var vol := sa.size.x * sa.size.y * sa.size.z
			if vol > best_vol:
				best_vol = vol
				eye = sa.get_center() + Vector3(0, 0.22, 0.5)
				driver_found = true
	var vis: Array = []
	for c in centers:
		vis.append(CarSpec.a3((c as Vector3) + offset))
	rep["cockpit"] = CarSpec.a3(eye + offset)
	rep["driver_found"] = driver_found
	rep["radius"] = radius
	rep["wheel_width"] = wwidth
	rep["wheelbase"] = maxf(rear_z - front_z, 1.2)
	rep["track"] = maxf(right_x - left_x, 0.9)
	rep["offset"] = CarSpec.a3(offset)
	rep["wheel_vis_pos"] = vis
	rep["body_pos"] = CarSpec.a3(b.position + offset)
	rep["body_size"] = CarSpec.a3(b.size)
	rep["wheels_found"] = found
	rep["mass"] = clampf(all.size.x * all.size.y * all.size.z * 120.0, 700.0, 2600.0)
	rep["length"] = all.size.z
	_set_xform(root, rot, scale, offset)
