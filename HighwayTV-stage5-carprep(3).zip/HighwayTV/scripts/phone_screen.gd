extends Control
## PHONE CONTROLLER screen: server status, TV address, port, pairing code, QR code,
## connection status and connected phone name.

var _info: Label
var _qr: TextureRect
var _hint: Label
var _url: Label
var _btn_toggle: Button
var _shown_url := ""
var _t := 0.0
var _diag: Label
var _ps: Node


func _ready() -> void:
	var bg := ColorRect.new()
	bg.color = Color(0.04, 0.05, 0.07)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var title := Label.new()
	title.text = "PHONE CONTROLLER"
	title.add_theme_font_size_override("font_size", 56)
	title.position = Vector2(100, 60)
	add_child(title)

	_info = Label.new()
	_info.position = Vector2(100, 170)
	_info.add_theme_font_size_override("font_size", 34)
	add_child(_info)

	_url = Label.new()
	_url.position = Vector2(100, 500)
	_url.size = Vector2(1000, 130)
	_url.autowrap_mode = TextServer.AUTOWRAP_ARBITRARY
	_url.add_theme_font_size_override("font_size", 40)
	_url.add_theme_color_override("font_color", Color(0.3, 0.85, 1.0))
	add_child(_url)

	_hint = Label.new()
	_hint.position = Vector2(100, 640)
	_hint.size = Vector2(900, 300)
	_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_hint.add_theme_font_size_override("font_size", 26)
	_hint.modulate = Color(1, 1, 1, 0.75)
	_hint.text = "1. Connect your phone to the same Wi-Fi as this TV.\n2. Scan the QR code with the phone camera and open the link.\n"\
		+ "3. Or type the address above in the phone browser (same Wi-Fi). No code needed.\n4. MODE 1 PLAYER: one phone. MODE 2 PLAYERS: two phones (first = P1, second = P2). Change MODE in the main menu.\n5. Steer with the on-screen wheel (or tilt), use the pedals and buttons.\n(No app needed. Phone settings has car upload and tilt steering.)"
	add_child(_hint)

	_qr = TextureRect.new()
	_qr.position = Vector2(1140, 120)
	_qr.custom_minimum_size = Vector2(620, 620)
	_qr.size = Vector2(620, 620)
	_qr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_qr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	_qr.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	add_child(_qr)

	var box := VBoxContainer.new()
	box.position = Vector2(100, 880)
	box.add_theme_constant_override("separation", 10)
	add_child(box)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 20)
	box.add_child(row)
	var b1 := _button("DISCONNECT PHONES", _new_code)
	_btn_toggle = _button("", _toggle)
	var b3 := _button("BACK", _back)
	row.add_child(b1)
	row.add_child(_btn_toggle)
	row.add_child(b3)
	b1.grab_focus()
	_diag = Label.new()
	_diag.position = Vector2(1140, 770)
	_diag.size = Vector2(700, 200)
	_diag.autowrap_mode = TextServer.AUTOWRAP_ARBITRARY
	_diag.add_theme_font_size_override("font_size", 20)
	_diag.modulate = Color(1, 1, 1, 0.6)
	add_child(_diag)
	_ps = get_node_or_null("/root/PhoneServer")
	if _ps != null:
		if _ps.status == 0:
			_ps.start()                  # open the server automatically
		_ps.allow_uploads = true         # car upload from a phone is allowed while this screen is open
		_ps.changed.connect(_update)
	GameInput.back_pressed.connect(_back)
	_update()


func _exit_tree() -> void:
	if _ps != null:
		_ps.allow_uploads = false
	if _ps != null and _ps.changed.is_connected(_update):
		_ps.changed.disconnect(_update)
	if GameInput.back_pressed.is_connected(_back):
		GameInput.back_pressed.disconnect(_back)


func _button(text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(380, 80)
	b.add_theme_font_size_override("font_size", 30)
	b.pressed.connect(cb)
	return b


func _process(delta: float) -> void:
	_t += delta
	if _t > 0.5:
		_t = 0.0
		_update()


func _update() -> void:
	if _ps == null:
		_info.text = "PHONE SERVER FAILED TO LOAD\n\nThe script scripts/phone_server.gd has an error.\nSend the error text from the build/log to the developer."
		_url.text = ""
		return
	var s := _ps
	var running: bool = s.status != 0
	var p1 := "waiting..."
	var p2 := "waiting..."
	if s.slots[0] != null:
		p1 = s.slots[0].pname
	if s.slots[1] != null:
		p2 = s.slots[1].pname
	_info.text = "SERVER:        %s\nTV ADDRESS:   %s\nPORT:             %s\nPLAYER 1:        %s\nPLAYER 2:        %s\n\n%s" % [
		"RUNNING" if running else "STOPPED", s.ip if running else "-",
		str(s.http_port) if running else "-", p1, p2, s.last_message]
	_btn_toggle.text = "STOP SERVER" if running else "START SERVER"
	if running:
		_url.text = "OPEN ON PHONE BROWSER:\n%s" % s.url()
	else:
		_url.text = ""
	_diag.text = "Network addresses found: %s\nPlatform: %s" % [", ".join(s.all_ips), OS.get_name()]
	if running and s.ip != "unknown":
		if s.url() != _shown_url:
			_shown_url = s.url()
			var qr_script: Script = load("res://scripts/qr_code.gd")
			var img: Image = qr_script.make_image(_shown_url, 10, 3)
			_qr.texture = ImageTexture.create_from_image(img) if img != null else null
	else:
		_shown_url = ""
		_qr.texture = null
		if running:
			_info.text += "\nNo Wi-Fi/LAN address found. Connect the TV to your network."


func _new_code() -> void:
	if _ps != null:
		_ps.disconnect_all()


func _toggle() -> void:
	if _ps == null:
		return
	if _ps.status == 0:
		_ps.start()
	else:
		_ps.stop()


func _back() -> void:
	GameState.goto("res://scenes/menu.tscn")
