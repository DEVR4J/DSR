class_name ChaseCamera
extends Camera3D
## Chase / close-rear / hood / COCKPIT (driver's eyes) and a 360 degree FREE VIEW.
## Sliders (GameState.cam_*): distance, angle, rotate-360 and zoom.
##  - orbit modes: distance scales the orbit radius, angle tilts it, rotate swings it round the car
##  - FREE VIEW orbits the driver's seat; distance 0 puts the camera inside the cabin
##    so you can look around the dashboard and seats
##  - HOOD / COCKPIT: angle and rotate turn your head, zoom narrows the field of view

enum Mode { CHASE, CLOSE, HOOD, COCKPIT, FREE }
const MODE_NAMES := ["CHASE", "CLOSE REAR", "HOOD", "COCKPIT (driver)", "FREE VIEW 360"]
const BASE_DIST := [7.5, 4.6, 0.0, 0.0, 8.0]
const BASE_PITCH := [12.0, 10.0, 0.0, 0.0, 22.0]

var target: HighwayCar
var mode: int = Mode.CHASE
var distance_scale := 1.0     # set from the car's length
var _yaw := 0.0
var _snap := true
var _y := 0.0
## 2-player race: the camera sits on the road centre line (lane 2) behind the pair.
var two_player := false
var targets: Array[HighwayCar] = []
var world: RoadWorld
var gap := 0.0                # distance between the cars along the road (m)
var _gap_s := 0.0


func _ready() -> void:
	near = 0.05
	far = 1500.0
	process_mode = Node.PROCESS_MODE_ALWAYS    # keeps updating while paused (live slider preview)


func next_mode() -> void:
	mode = (mode + 1) % (2 if two_player else MODE_NAMES.size())
	_snap = true


func reset_view() -> void:
	GameState.cam_dist = 1.0
	GameState.cam_pitch = 0.0
	GameState.cam_yaw = 0.0
	GameState.cam_zoom = 1.0


func snap() -> void:
	_snap = true


func _physics_process(delta: float) -> void:
	if not get_tree().paused:
		_update(delta)


func _process(delta: float) -> void:
	if get_tree().paused:
		_update(delta)


func _update_lane(delta: float) -> void:
	if targets.size() < 2 or world == null:
		return
	var mid := (targets[0].global_position + targets[1].global_position) * 0.5
	var f := world.road_frame(mid)
	var yaw_t: float = f["yaw"]
	_yaw = yaw_t if _snap else lerp_angle(_yaw, yaw_t, 1.0 - exp(-6.0 * delta))
	var back := Vector3(sin(_yaw), 0.0, cos(_yaw))
	var chase := mode == Mode.CHASE
	_gap_s = lerpf(_gap_s, gap, 1.0 - exp(-3.0 * delta))
	# pull back (and up) as the cars drift apart so both stay in view
	var dist := (9.0 if chase else 5.5) * maxf(GameState.cam_dist, 0.3) + _gap_s * 0.6
	var height := (3.4 if chase else 2.3) + GameState.cam_pitch * 0.12 + _gap_s * 0.12
	var center: Vector3 = f["center"]
	look_at_from_position(center + back * dist + Vector3.UP * height, center - back * 4.0 + Vector3.UP * 1.0, Vector3.UP)
	fov = clampf(66.0 / clampf(GameState.cam_zoom, 0.5, 4.0), 15.0, 110.0)
	h_offset = 0.0
	v_offset = 0.0
	_snap = false


func _update(delta: float) -> void:
	if target == null:
		return
	if two_player:
		_update_lane(delta)
		return
	if not get_tree().paused:
		var yaw_in := clampf(Input.get_axis("cam_left", "cam_right") + GameState.look_x, -1.0, 1.0)
		var pitch_in := clampf(Input.get_axis("cam_down", "cam_up") + GameState.look_y, -1.0, 1.0)
		var zoom_in := Input.get_axis("cam_in", "cam_out")
		if mode == Mode.FREE or absf(yaw_in) + absf(pitch_in) + absf(zoom_in) > 0.0:
			GameState.cam_yaw = wrapf(GameState.cam_yaw + yaw_in * 120.0 * delta, -180.0, 180.0)
			GameState.cam_pitch = clampf(GameState.cam_pitch + pitch_in * 60.0 * delta, -20.0, 70.0)
			GameState.cam_dist = clampf(GameState.cam_dist + zoom_in * 1.2 * delta, 0.0, 2.5)

	var t := target.global_transform
	var f := -t.basis.z
	f.y = 0.0
	var heading := _yaw
	if f.length() > 0.01:
		f = f.normalized()
		heading = atan2(-f.x, -f.z)
	if _snap:
		_yaw = heading
	else:
		_yaw = lerp_angle(_yaw, heading, 1.0 - exp(-4.0 * delta))

	var k := clampf(target.speed_kmh / 200.0, 0.0, 1.0)
	var yaw_off := deg_to_rad(GameState.cam_yaw)
	var zoom := clampf(GameState.cam_zoom, 0.5, 4.0)

	if mode == Mode.HOOD or mode == Mode.COCKPIT:
		var look := Basis(Vector3.UP, -yaw_off) * Basis(Vector3.RIGHT, deg_to_rad(-GameState.cam_pitch * 0.5))
		var pos := target.hood_cam_pos if mode == Mode.HOOD else target.cockpit_cam_pos
		global_transform = t * Transform3D(look, pos)
		fov = clampf(lerpf(72.0, 90.0, k) / zoom, 15.0, 110.0)
		h_offset = 0.0
		v_offset = 0.0
		_snap = false
		return

	var base_d: float = BASE_DIST[mode]
	var base_p: float = BASE_PITCH[mode]
	var is_free := mode == Mode.FREE
	var dist := base_d * distance_scale * GameState.cam_dist
	if not is_free:
		dist = maxf(dist, 1.0)
	# the built-in downward tilt fades out as the camera moves into the cabin
	var pitch := deg_to_rad(clampf(base_p * clampf(GameState.cam_dist, 0.0, 1.0) + GameState.cam_pitch, -30.0, 85.0))
	var yaw := _yaw + yaw_off
	var back := Vector3(sin(yaw), 0.0, cos(yaw))        # direction from the car to the camera (flat)
	var offset_dir := back * cos(pitch) + Vector3.UP * sin(pitch)

	var center: Vector3
	if is_free:
		center = t * target.cockpit_cam_pos             # orbit the driver's seat
	else:
		if _snap:
			_y = t.origin.y
		else:
			_y = lerpf(_y, t.origin.y, 1.0 - exp(-6.0 * delta))
		center = Vector3(t.origin.x, _y, t.origin.z) + Vector3.UP * 1.0
	var desired := center + offset_dir * dist
	var focus := desired - offset_dir                    # same line of sight, works at distance 0
	if not is_free:
		focus = center - back * 3.0                      # look a little ahead of the car

	# Collision avoidance (skipped when the camera is inside / very near the car)
	if dist > 1.0:
		var space := get_world_3d().direct_space_state
		var q := PhysicsRayQueryParameters3D.create(center, desired)
		q.exclude = [target.get_rid()]
		var hit := space.intersect_ray(q)
		if not hit.is_empty():
			desired = hit.position + hit.normal * 0.3
			if is_free:
				focus = desired - offset_dir

	look_at_from_position(desired, focus, Vector3.UP)
	fov = clampf(lerpf(62.0, 88.0, k) / zoom, 15.0, 110.0)
	var shake := 0.02 * k
	h_offset = randf_range(-shake, shake)
	v_offset = randf_range(-shake, shake)
	_snap = false
