class_name PlayerState
extends RefCounted
## Everything that belongs to ONE driver: controls, lights and telemetry.
## Player 1 = the local controls (keyboard / gamepad / TV remote) or the first phone;
## player 2 = the second phone. Cars, lights and the phone page read/write this.

signal gear_up_pressed
signal gear_down_pressed
signal gearbox_toggle_pressed
signal reset_pressed
signal horn_changed(on: bool)
signal light_action(name: String)

var steer := 0.0          # -1 .. 1
var throttle := 0.0       # 0 .. 1
var brake := 0.0
var handbrake := 0.0
var remote := false       # true while a phone is driving this player
var locked := false       # race countdown: car held still (handbrake on)

var light_mode := 0       # 0 off, 1 low, 2 high, 3 low+high
var hazard := false
var ind_left := false
var ind_right := false
var cabin_light := false
var blink := false

var speed_kmh := 0.0
var gear_text := ""
var phone_name := ""


func set_remote(s: float, t: float, b: float, h: float) -> void:
	remote = true
	steer = clampf(s, -1.0, 1.0)
	throttle = clampf(t, 0.0, 1.0)
	brake = clampf(b, 0.0, 1.0)
	handbrake = clampf(h, 0.0, 1.0)


## Phone gone: controls neutralise immediately.
func clear_remote() -> void:
	remote = false
	steer = 0.0
	throttle = 0.0
	brake = 0.0
	handbrake = 0.0


func reset_lights() -> void:
	light_mode = 0
	hazard = false
	ind_left = false
	ind_right = false
	cabin_light = false
