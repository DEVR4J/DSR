extends Node
## Autoload "GameState": selections that survive scene changes.

var car_id := ""        # "" = built-in car, otherwise a saved custom car id
var biome := 0
var mode := 1            # 1 = one player, 2 = two players (race)
var car_id2 := ""       # player 2's car in 2-player mode

# camera sliders (player 1's camera: pause menu, phone page, right stick)
var cam_dist := 1.0      # orbit distance multiplier 0 .. 2.5 (0 = inside the car in FREE VIEW)
var cam_zoom := 1.0      # field-of-view zoom 0.5 .. 4
var cam_pitch := 0.0     # extra angle up/down in degrees -20 .. 70
var cam_yaw := 0.0       # rotation around the car -180 .. 180 (0 = behind)
var cluster_mode := 0    # 0 standard gauge, 1 instrument cluster, 2 off
var look_x := 0.0        # phone joystick (camera look)
var look_y := 0.0

## Two drivers at most. players[0] = local controls / first phone, players[1] = second phone.
var players: Array[PlayerState] = [PlayerState.new(), PlayerState.new()]


func goto(path: String) -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file(path)
