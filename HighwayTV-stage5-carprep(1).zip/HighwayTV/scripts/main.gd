extends Node3D
## Highway TV - Stage 1 entry point. Builds world, car, camera, HUD and wires input.

enum Quality { LOW, MEDIUM, HIGH, ULTRA }
const QUALITY_NAMES := ["LOW", "MEDIUM", "HIGH", "ULTRA"]

var quality: int = Quality.MEDIUM
var car: HighwayCar
var world: RoadWorld
var cam: ChaseCamera
var hud: HUD
var sun: DirectionalLight3D
var _env: Environment
var _sky_mat: ProceduralSkyMaterial
var biome := 0
var paused := false


func _ready() -> void:
	quality = _recommend_quality()
	_setup_environment()

	world = RoadWorld.new()
	add_child(world)

	car = HighwayCar.new()
	car.position = Vector3(0, 1.0, -8)
	if GameState.car_id != "":
		car.spec = CarSpec.load_spec(GameState.car_id)
	add_child(car)

	cam = ChaseCamera.new()
	cam.target = car
	cam.distance_scale = clampf(car.car_length / 4.3, 0.8, 1.7)
	add_child(cam)
	cam.current = true

	hud = HUD.new()
	hud.car = car
	hud.cam = cam
	hud.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(hud)
	hud.resume_requested.connect(_toggle_pause)
	hud.menu_requested.connect(_to_menu)

	world.update_for(car.position)
	_apply_quality()
	_set_biome(GameState.biome)

	GameInput.back_pressed.connect(_on_back)
	GameInput.accept_pressed.connect(_on_accept)
	GameInput.pause_pressed.connect(_toggle_pause)
	GameInput.camera_pressed.connect(_on_camera)
	GameInput.reset_pressed.connect(_on_reset)
	_update_hud_text()


func _physics_process(_delta: float) -> void:
	world.update_for(car.global_position)
	var off := world.rebase_if_needed(car.global_position)
	if off != Vector3.ZERO:
		car.global_position += off
		cam.snap()


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_F1:
		quality = (quality + 1) % 4
		_apply_quality()
	elif event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_F3:
		GameState.cluster_mode = (GameState.cluster_mode + 1) % 3
	elif event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_F2:
		_set_biome(biome + 1)


# ------------------------------------------------------------------- input
func _on_back() -> void:
	_toggle_pause()          # BACK pauses / resumes (MAIN MENU is a button in the pause screen)

func _on_accept() -> void:
	if not paused:           # while paused, OK presses the focused button instead
		cam.next_mode()

func _on_camera() -> void:
	if not paused:
		cam.next_mode()

func _on_reset() -> void:
	if not paused:
		car.reset_upright()

func _to_menu() -> void:
	GameState.goto("res://scenes/menu.tscn")


func _toggle_pause() -> void:
	paused = not paused
	get_tree().paused = paused
	hud.set_paused(paused)


# ---------------------------------------------------------------- graphics
func _recommend_quality() -> int:
	var cores := OS.get_processor_count()
	if cores >= 8:
		return Quality.HIGH
	if cores >= 4:
		return Quality.MEDIUM
	return Quality.LOW


func _apply_quality() -> void:
	sun.shadow_enabled = quality >= Quality.MEDIUM
	sun.directional_shadow_max_distance = [0.0, 60.0, 90.0, 130.0][quality]
	var msaa := [Viewport.MSAA_DISABLED, Viewport.MSAA_DISABLED, Viewport.MSAA_2X, Viewport.MSAA_4X]
	get_viewport().msaa_3d = msaa[quality]
	world.set_tree_count([6, 12, 18, 24][quality])
	world.set_view_segments([7, 9, 11, 13][quality])
	_update_hud_text()


func _update_hud_text() -> void:
	if hud != null:
		hud.extra_text = "%s (F2)\nQUALITY %s (F1)" % [world.biome["name"], QUALITY_NAMES[quality]]
		if car.custom_failed:
			hud.extra_text += "\nCUSTOM CAR FAILED TO LOAD - using built-in car"


func _set_biome(b: int) -> void:
	biome = wrapi(b, 0, RoadWorld.BIOMES.size())
	world.set_biome(biome)
	var d: Dictionary = world.biome
	_sky_mat.sky_top_color = d["sky_top"]
	_sky_mat.sky_horizon_color = d["sky_hor"]
	_sky_mat.ground_horizon_color = d["sky_hor"]
	_sky_mat.ground_bottom_color = d["ground"]
	_env.fog_light_color = d["fog"]
	_env.fog_density = d["fog_d"]
	world.update_for(car.global_position)
	_update_hud_text()


func _setup_environment() -> void:
	var sm := ProceduralSkyMaterial.new()
	_sky_mat = sm
	sm.sky_top_color = Color(0.25, 0.45, 0.8)
	sm.sky_horizon_color = Color(0.7, 0.8, 0.9)
	sm.ground_horizon_color = Color(0.6, 0.68, 0.6)
	sm.ground_bottom_color = Color(0.3, 0.4, 0.3)
	var sky := Sky.new()
	sky.sky_material = sm
	var env := Environment.new()
	_env = env
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.9
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_light_color = Color(0.72, 0.8, 0.9)
	env.fog_density = 0.0012
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -35, 0)
	sun.light_energy = 1.3
	sun.shadow_enabled = true
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	add_child(sun)


func _exit_tree() -> void:
	for pair in [[GameInput.back_pressed, _on_back], [GameInput.accept_pressed, _on_accept],
			[GameInput.pause_pressed, _toggle_pause], [GameInput.camera_pressed, _on_camera],
			[GameInput.reset_pressed, _on_reset]]:
		if pair[0].is_connected(pair[1]):
			pair[0].disconnect(pair[1])
